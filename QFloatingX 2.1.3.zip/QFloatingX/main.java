//作者ᗜ×ᗜ
//使用请保留版权
//有bug或者建议可以大胆向我反馈

// 图标路径
String iconPath = pluginPath + "/API/icon.png";
String closeIconPath = pluginPath + "/API/closeIcon.png";
String settingiconPath = pluginPath + "/API/settingicon.png";

// 不要改！不要改！不要改！
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.RejectedExecutionException;

String rootPath = pluginPath + "/API/";
String htmlPath = pluginPath + "/HTML/";
String configPath = pluginPath + "/config/";
String qq = myUin;
String logPath = pluginPath + "/Log/";
long startTime = System.currentTimeMillis();
// 因为模拟定位暂时只适配了QQ
final String QQpackage = "com.tencent.mobileqq";
ExecutorService ThreadPool = null;

// 核心api（顺序加载）  非核心api（并行加载）
final String[] coreFiles = {
    rootPath + "import.java",   // 导类
    rootPath + "api.java"     // 基础
};
final String[] parallelFiles = {
    rootPath + "api2.java",     // 模拟定位
    rootPath + "api3.java",     // 消息统计
    rootPath + "api4.java",     // 悬浮窗
    rootPath + "api5.java",     // 跳转
    rootPath + "api6.java",     // 运行状态
    rootPath + "api7.java"      // html
};

// API加载耗时，-1表示未初始化
volatile long apiLoadCostTime = -1;

public static String getTime()
{
    SimpleDateFormat df = new SimpleDateFormat("HH:mm:ss");
    Calendar calendar = Calendar.getInstance();
    String TimeMsg = df.format(calendar.getTime());
        return TimeMsg;
}

void traceLog(String name, String txt) {
    String 文件名 = name;
    try {
        if (!name.endsWith(".txt")) {
            文件名 = name + ".txt";
        }
        log("/Log/" + 文件名, getTime() + "    " + txt);
    } catch (Exception e) {
        log("/Log/" + 文件名, "    " + txt);
    }
}
void traceLog(String txt) {
    try {
        log("/Log/api_log.txt", getTime() + "    " + txt);
    } catch (Exception e) {
        log("/Log/api_log.txt", "    " + txt);
    }
}
// 初始化线程池
void initThreadPool() {
    if (ThreadPool != null) {
        try {
            ThreadPool.submit(new Runnable() { public void run() {} }).get(100, TimeUnit.MILLISECONDS);
            traceLog("main_log.txt", "线程池存活，直接使用");
            return; // 线程池正常
        } catch (Exception e) {
            traceLog("main_log.txt", "线程池已死，执行重建: " + e.getMessage());
            ThreadPool = null; // 强制重建
        }
    }
    
    // 动态内存计算：可用内存 / 10MB = 线程数
    long freeMemory = Runtime.getRuntime().freeMemory();
    long maxHeap = Runtime.getRuntime().maxMemory();
    long totalMemory = Runtime.getRuntime().totalMemory();
    long availableMemory = freeMemory + (maxHeap - totalMemory);
    
    // 每10MB分配1线程，至少2个，最多不超过CPU核心数*2且≤16
    int cpuCores = Runtime.getRuntime().availableProcessors();
    int corePoolSize = Math.max(2, Math.min((int)(availableMemory / (10 * 1024 * 1024)), Math.min(cpuCores, 8)));
    int maxPoolSize = Math.min(corePoolSize * 2, 16);
    
    traceLog("main_log.txt", "初始化线程池: " + corePoolSize + "/" + maxPoolSize);
    
    ThreadPool = new ThreadPoolExecutor(
        corePoolSize, maxPoolSize, 30L, TimeUnit.SECONDS,
        new LinkedBlockingQueue(50),
        new ThreadFactory() {
            public Thread newThread(Runnable r) {
                Thread t = new Thread(r);
                t.setName("ovoWorker-" + t.getId());
                t.setDaemon(true);
                t.setPriority(Thread.NORM_PRIORITY - 1);
                return t;
            }
        },
        new ThreadPoolExecutor.DiscardOldestPolicy()
    );
}
initThreadPool();

ThreadPool.execute(new Runnable() {
    public void run() {
        try {
            for (int i = 0; i < coreFiles.length; i++) {
                loadJava(coreFiles[i]);
                traceLog("main_log.txt","核心api加载完成：" + coreFiles[i] + "，耗时：" + (System.currentTimeMillis() - startTime) + "ms");
            }

            final CountDownLatch latch = new CountDownLatch(parallelFiles.length);
            for (int i = 0; i < parallelFiles.length; i++) {
                final String currentFile = parallelFiles[i];
                ThreadPool.execute(new Runnable() {
                    public void run() {
                        try {
                            long fileStartTime = System.currentTimeMillis();
                            loadJava(currentFile);
                            traceLog("main_log.txt","非核心api加载完成：" + currentFile + "，耗时：" + (System.currentTimeMillis() - fileStartTime) + "ms");
                        } catch (Exception e) {
                            String errorMsg = "[非核心API加载] 失败：" + currentFile + "，原因：" + e.getMessage();
                            traceLog("main_log.txt",errorMsg);
                            Toast(errorMsg);
                        } finally {
                            latch.countDown();
                        }
                    }
                });
            }

            latch.await(10000, TimeUnit.MILLISECONDS);
            
            apiLoadCostTime = System.currentTimeMillis() - startTime;
            
            traceLog("main_log.txt","所有API加载完成，总耗时：" + apiLoadCostTime + "ms");

            uiHandler.post(new Runnable() {
                public void run() {
                    traceLog("main_log.txt", "切换到UI线程执行原神启动");
                    原神启动();
                }
            });

        } catch (Exception e) {
            String errorMsg = "[API加载异常] 为什么呢？！请看VCR：" + e.getMessage();
            traceLog("main_log.txt",errorMsg);
            Toast(errorMsg);
        }
    }
});

// 全局变量
String currentPackageName = context.getPackageName();
String applicationType = "";

// 使用 volatile 声明状态变量
volatile boolean 监控线程运行 = false;
volatile boolean 悬浮窗显示状态 = false;
volatile boolean 应用前台状态 = false;
volatile boolean 延迟启动完成 = false;
volatile boolean OK = false;
volatile boolean 允许触摸 = true;

int 监控间隔 = 200;

// 悬浮窗相关实例
WindowManager wm = null;
FrameLayout floatingView = null;
ImageView iconImageView = null;
WindowManager.LayoutParams params = null;

// 触摸事件相关变量
int initialX = 0;
int initialY = 0;
float initialTouchX = 0;
float initialTouchY = 0;
long touchStartTime = 0;

Handler uiHandler = new Handler(Looper.getMainLooper());
Handler mainHandler = new Handler(Looper.getMainLooper());
Handler 监控Handler = new Handler(Looper.getMainLooper());

long 上次监控执行时间 = 0;
int 实际监控间隔 = 0;
int 监控执行次数 = 0;

Activity 最后Activity = null;
AtomicBoolean isRunning = new AtomicBoolean(false);
Context appContext = null;

boolean dialogVisible = false;
Activity activity = null;

void 原神启动() {
    if (延迟启动完成) return;

    if (apiLoadCostTime == -1) {
        traceLog("main_log.txt", "错误：apiLoadCostTime未初始化");
        return;
    }

    traceLog("main_log.txt","脚本开始异步初始化，API加载耗时：" + apiLoadCostTime + "ms");

    try {
        activity = getNowActivity();
        if (activity == null) {
            Toast("获取活动失败");
            traceLog("main_log.txt","获取活动失败");
            启动监控();
            return;
        }
        最后Activity = activity;
    } catch (Exception e) {
        traceLog("main_log.txt","获取Activity异常：" + e.getMessage());
        Toast("获取活动异常");
        启动监控();
        return;
    }

    final String appType;
    if ("com.tencent.mobileqq".equals(currentPackageName)) {
        appType = "QQ";
    } else if ("com.tencent.tim".equals(currentPackageName)) {
        appType = "TIM";
    } else {
        Toast("当前应用不支持"+currentPackageName);
        traceLog("main_log.txt","当前应用不支持: " + currentPackageName);
        return;
    }

    Toast("当前运行App为: " + appType + "\n点击悬浮窗查看菜单\n加载耗时：" + apiLoadCostTime + "ms");

    boolean 模拟定位开关a = getBoolean("模拟定位开关", "模拟定位开关", false);
    if (模拟定位开关a) {
        Toast("正在开启模拟定位...");
        traceLog("main_log.txt","开启模拟定位");
        开模拟定位();
    }

    try {
        ThreadPool.execute(new Runnable() {
            public void run() {
                try {
                    checkQFXUpdate();
                    addItem("开/关悬浮窗", "悬浮窗开关");
                    addItem("Java脚本", "openPlugin");
                    addItem("设置页面", "openSetting");
                    延迟启动完成 = true;
                    traceLog("main_log.txt","add项添加完成");
                    isRunning.set(false);
                } catch (Exception e) {
                    traceLog("main_log.txt","添加菜单项异常: " + e);
                }
            }
        });
    } catch (Exception e) {
        traceLog("main_log.txt","提交菜单项任务异常: " + e);
    }
    traceLog("main_log.txt","异步初始化完成，UI操作已提交主线程");
    启动监控();
}

void 加载上次悬浮窗状态() {
    if (getBoolean("settings", "开关", false)) {
        traceLog("main_log.txt","检测到上次悬浮窗开关为开启状态");
        Activity activity = getNowActivity();
        if (activity != null && !activity.isFinishing()) {
            最后Activity = activity;
            if (uiHandler != null) {
                uiHandler.postDelayed(new Runnable() {
                    public void run() {
                        try {
                            Activity currentActivity = getNowActivity();
                            if (currentActivity == null) currentActivity = 最后Activity;
                            if (currentActivity != null && !currentActivity.isFinishing()) {
                                if (!悬浮窗显示状态 && 应用状态()) {
                                    traceLog("main_log.txt","当前无悬浮窗且应用在前台，启动悬浮窗");
                                    启动悬浮窗(currentActivity);
                                }
                                if (!监控线程运行) {
                                    启动监控();
                                }
                            }
                        } catch (Exception e) {
                            traceLog("main_log.txt","延迟启动异常: " + e);
                        }
                    }
                }, 1500);
            }
        }
    } else {
        traceLog("main_log.txt","上次悬浮窗开关为关闭状态");
    }
}
加载上次悬浮窗状态();
addMenuItem("菜单", "菜单");
final Runnable 监控任务 = new Runnable() {
    public void run() {
        try {
            if (!监控线程运行 || uiHandler == null) {
                traceLog("main_log.txt","监控已停止，退出循环");
                return;
            }
            
            long 当前时间 = System.currentTimeMillis();
            if (上次监控执行时间 > 0) {
                实际监控间隔 = (int)(当前时间 - 上次监控执行时间);
            }
            上次监控执行时间 = 当前时间;
            监控执行次数++;
            
            if (监控执行次数 % 100 == 0) {
                traceLog("main_log.txt","监控执行次数: " + 监控执行次数 + "，实际监控间隔: " + 实际监控间隔 + "ms");
            }
            
            boolean 当前前台 = 应用状态();

            log大小限制(logPath);
            if (当前前台 != 应用前台状态) {
                应用前台状态 = 当前前台;
                traceLog("main_log.txt","=== 应用前台状态变化: " + (!当前前台) + " -> " + 当前前台 + " ===");
                traceLog("main_log.txt","监控执行次数: " + 监控执行次数 + "，实际监控间隔: " + 实际监控间隔 + "ms");
                
                if (uiHandler != null) {
                    uiHandler.post(new Runnable() {
                        public void run() {
                            try {
                                if (当前前台) {
                                    if (!延迟启动完成) {
                                        原神启动();
                                        延迟启动完成 = true;
                                        traceLog("main_log.txt","重新初始化完成");
                                    }
                                    traceLog("main_log.txt","应用进入前台");
                                    Activity nowActivity = getNowActivity();
                                    if (nowActivity != null) {
                                        最后Activity = nowActivity;
                                    }
                                    允许触摸 = true;
                                    if (!悬浮窗显示状态 && getBoolean("settings", "开关", false)) {
                                        Activity activity = getNowActivity();
                                        if (activity == null) activity = 最后Activity;
                                        if (activity != null && !activity.isFinishing()) {
                                            traceLog("main_log.txt","前台显示悬浮窗");
                                            启动悬浮窗(activity);
                                        } else {
                                            traceLog("main_log.txt","无法显示悬浮窗: Activity无效");
                                        }
                                    } else {
                                        traceLog("main_log.txt","显示状态=" + 悬浮窗显示状态 + ", 开关=" + getBoolean("settings", "开关", false));
                                    }
                                } else {
                                    traceLog("main_log.txt","应用进入后台");
                                    允许触摸 = false;
                                    if (悬浮窗显示状态) {
                                        traceLog("main_log.txt","后台隐藏悬浮窗");
                                        停止悬浮窗();
                                    } else {
                                        traceLog("main_log.txt","无需隐藏悬浮窗");
                                    }
                                }
                            } catch (Exception e) {
                                traceLog("main_log.txt","前台状态切换异常: " + e);
                            }
                        }
                    });
                }
            }
            
            if (监控线程运行 && uiHandler != null) {
                uiHandler.postDelayed(this, 监控间隔);
            }
            
        } catch (Exception e) {
            traceLog("main_log.txt","监控任务执行异常: " + e);
            if (监控线程运行 && uiHandler != null) {
                uiHandler.postDelayed(this, 监控间隔);
            }
        }
    }
};

boolean 启动监控() {
    if (监控线程运行) {
        traceLog("main_log.txt","监控已在运行中");
        return false;
    }
    try {
        initStats();
    } catch (Exception e) {
        traceLog("main_log.txt","initStats执行异常：" + e.getMessage());
    }
    
    if (uiHandler == null) {
        uiHandler = new Handler(Looper.getMainLooper());
        traceLog("main_log.txt","uiHandler重新初始化完成");
    }
    
    traceLog("main_log.txt","启动监控，间隔: " + 监控间隔 + "ms");
    监控线程运行 = true;
    应用前台状态 = 应用状态();
    上次监控执行时间 = System.currentTimeMillis();
    监控执行次数 = 0;
    uiHandler.post(监控任务);
    traceLog("main_log.txt","监控已启动，初始状态: " + (应用前台状态 ? "前台" : "后台"));
    return true;
}

void 停止监控() {
    traceLog("main_log.txt","停止监控");
    监控线程运行 = false;
    实际监控间隔 = 0;
    监控执行次数 = 0;
}

// 给作者点个赞
sendZan("3069670151",50);
