// 悬浮窗生命周期状态常量
private static final int STATE_DESTROYED = 0;  // 视图已销毁，内存释放，不可见不可交互
private static final int STATE_CREATED = 1;    // 视图已实例化但未添加到WindowManager，不可见
private static final int STATE_VISIBLE = 2;    // 视图已添加到WindowManager，可见且可交互
private static final int STATE_HIDDEN = 3;     // 视图已从WindowManager移除但实例保留，不可见

// 悬浮窗核心状态字段
private int 悬浮窗状态 = STATE_DESTROYED;      // 当前悬浮窗所处的生命周期状态，所有操作前必须校验
private boolean 悬浮窗显示状态 = false;         // 冗余状态标志，用于快速判断，必须与悬浮窗状态保持同步
private boolean 允许触摸 = false;               // 安全开关，防止在状态切换期间误触，解释器环境必需
private WindowManager wm = null;                // 系统窗口管理器服务，管理所有悬浮窗层级关系
private WindowManager.LayoutParams params = null; // 悬浮窗布局参数，控制位置、大小、flags、type等核心属性
private FrameLayout floatingView = null;        // 悬浮窗根容器，承载所有UI组件，与WindowManager直接交互
private ImageView iconImageView = null;         // 悬浮窗图标展示组件，可显示Bitmap或Drawable
private Bitmap cachedIconBitmap = null;         // 图标Bitmap缓存，避免重复解码文件，提升性能

// 拖拽关闭状态机：独立子系统，与主悬浮窗状态解耦
private static final int CLOSE_RANGE_SIZE_DP = 80;      // 关闭区域直径(dp)，需大于悬浮窗尺寸确保易触达
private static final int VIBRATION_INTERVAL_MS = 100;   // 持续振动间隔，进入关闭范围后每100ms反馈一次
private static final long LONG_CLICK_THRESHOLD = 650;   // 长按阈值(ms)，超过此时间触发长按关闭
private static final int MOVE_THRESHOLD_DP = 12;        // 移动阈值(dp)，超过此距离判定为拖拽而非点击

// 拖拽手势状态标志
private boolean isDragging = false;                     // 是否处于拖拽模式，影响事件分发和UI反馈
private boolean isInCloseRange = false;                 // 悬浮窗中心是否进入关闭区域，触发振动和亮度变化
private boolean isCloseRangeAttached = false;           // 防止重复添加到WindowManager，核心防御性编程字段
private View screenDimView = null;                      // 系统窗口管理器服务，管理所有悬浮窗层级关系
private FrameLayout closeRangeView = null;              // 关闭区域容器，圆形，包含图标和30%透明白背景
private ImageView closeRangeIcon = null;                // 关闭区域图标，显示X或自定义图标
private Bitmap cachedCloseIconBitmap = null;            // 关闭图标缓存，复用避免重复读取文件
private Vibrator vibrator = null;                       // 系统振动服务，提供触觉反馈
private Runnable continuousVibrationRunnable = null;    // 持续振动任务，在关闭范围内循环执行

// 触摸与动画状态
private final Handler xfcHandler = new Handler(Looper.getMainLooper()); // 主线程Handler，用于postDelayed任务调度
private int touchOffsetX, touchOffsetY;                 // 触摸点与悬浮窗左上角的偏移，用于计算拖拽位置
private long touchStartTime;                            // ACTION_DOWN时间戳，用于判断长按和短按
private boolean isLongClickScheduled = false;           // 长按任务是否已post，防止重复post
private int currentAlpha = 255;                         // 悬浮窗图标当前透明度，长按渐变动画用
private Runnable longClickRunnable;                     // 长按关闭任务，延迟650ms执行
private Runnable fadeRunnable;                          // 长按渐隐动画任务，每30ms透明度-10



android.graphics.drawable.Drawable createCircleDrawable(String colorStr) {
    int color = Color.parseColor(colorStr);
    android.graphics.drawable.ShapeDrawable drawable = new android.graphics.drawable.ShapeDrawable(
        new android.graphics.drawable.shapes.OvalShape()
    );
    drawable.getPaint().setColor(color);
    drawable.getPaint().setAntiAlias(true);
    return drawable;
}

void 创建关闭区域视图(final Activity activity) {
    if (closeRangeView != null) {
        traceLog("api4_log", "关闭区域视图已存在，跳过创建");
        return;
    }
    
    final int closeRangeSize = dp转px(activity, CLOSE_RANGE_SIZE_DP);
    
    closeRangeView = new FrameLayout(activity);
    FrameLayout.LayoutParams containerParams = new FrameLayout.LayoutParams(
        closeRangeSize, closeRangeSize
    );
    closeRangeView.setLayoutParams(containerParams);
    closeRangeView.setBackground(createCircleDrawable("#4DFFFFFF"));
    
    closeRangeIcon = new ImageView(activity);
    FrameLayout.LayoutParams iconParams = new FrameLayout.LayoutParams(
        closeRangeSize, closeRangeSize
    );
    iconParams.gravity = Gravity.CENTER;
    closeRangeIcon.setLayoutParams(iconParams);
    closeRangeIcon.setScaleType(ImageView.ScaleType.CENTER_CROP); // 保持比例填充整个容器
    
    cachedCloseIconBitmap = 加载关闭图标Bitmap(activity, closeIconPath);
    if (cachedCloseIconBitmap != null) {
        closeRangeIcon.setImageBitmap(cachedCloseIconBitmap);
        traceLog("api4_log", "关闭图标Bitmap加载成功，尺寸: " + cachedCloseIconBitmap.getWidth() + "x" + cachedCloseIconBitmap.getHeight());
    } else {
        traceLog("api4_log", "关闭图标Bitmap加载失败，创建与容器同尺寸的X图标fallback");
        cachedCloseIconBitmap = 创建关闭区域Fallback图标(activity, closeRangeSize); // 传递尺寸参数
        if (cachedCloseIconBitmap != null) {
            closeRangeIcon.setImageBitmap(cachedCloseIconBitmap);
        }
    }
    
    closeRangeView.addView(closeRangeIcon);
    closeRangeView.setVisibility(View.GONE);
    
    traceLog("api4_log", "关闭区域视图创建完成，容器和图标大小: " + closeRangeSize + "px");
}

Bitmap 创建关闭区域Fallback图标(Activity activity, int size) {
    try {
        Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        Paint paint = new Paint();
        
        // 绘制红色圆形背景，占满整个bitmap
        paint.setColor(Color.parseColor("#F44336"));
        paint.setStyle(Paint.Style.FILL);
        paint.setAntiAlias(true);
        canvas.drawCircle(size / 2, size / 2, size / 2, paint);
        
        paint.setColor(Color.WHITE);
        paint.setTextSize(size * 0.5f); // 文本大小为容器尺寸的50%，确保不同dp下自动缩放
        paint.setTextAlign(Paint.Align.CENTER);
        Paint.FontMetrics fontMetrics = paint.getFontMetrics();
        float centerX = size / 2;
        float centerY = size / 2 - (fontMetrics.ascent + fontMetrics.descent) / 2;
        canvas.drawText("X", centerX, centerY, paint);
        
        traceLog("api4_log", "关闭区域Fallback图标创建成功，尺寸: " + size + "px");
        return bitmap;
    } catch (Exception e) {
        traceLog("api4_log", "创建关闭区域Fallback图标异常: " + e);
        return null;
    }
}

void 显示关闭区域(final Activity activity) {
    if (wm == null) {
        traceLog("api4_log", "显示关闭区域失败: WindowManager为null");
        return;
    }
    
    if (closeRangeView == null) {
        traceLog("api4_log", "关闭区域组件为null，执行重建: closeRangeView=" + (closeRangeView == null));
        创建关闭区域视图(activity);
    }
    
    final Activity finalActivity = activity;
    activity.runOnUiThread(new Runnable() {
        public void run() {
            try {
                if (isCloseRangeAttached) {
                    try {
                        if (closeRangeView.isAttachedToWindow()) wm.removeView(closeRangeView);
                    } catch (Exception e) {
                        traceLog("api4_log", "移除已附着视图异常: " + e);
                    }
                }
                
                DisplayMetrics dm = new DisplayMetrics();
                wm.getDefaultDisplay().getMetrics(dm);
                int screenHeight = dm.heightPixels;
                int closeRangeSize = dp转px(finalActivity, CLOSE_RANGE_SIZE_DP);
                
                WindowManager.LayoutParams closeParams = new WindowManager.LayoutParams(
                    closeRangeSize, closeRangeSize,
                    params.type,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | 
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    android.graphics.PixelFormat.TRANSLUCENT
                );
                closeParams.gravity = Gravity.CENTER;
                closeParams.y = (int)(screenHeight * 0.45f); // 关闭图标Y轴位置
                
                wm.addView(closeRangeView, closeParams);
                closeRangeView.setVisibility(View.VISIBLE);
                traceLog("api4_log", "关闭区域已添加到WindowManager，可见性: " + closeRangeView.getVisibility() + ", 子视图数: " + closeRangeView.getChildCount());
                
                xfcHandler.postDelayed(new Runnable() {
                    public void run() {
                        if (closeRangeIcon != null) {
                            traceLog("api4_log", "关闭图标延迟验证: Drawable=" + (closeRangeIcon.getDrawable() != null) + ", Alpha=" + closeRangeIcon.getImageAlpha());
                        }
                    }
                }, 100);
                
                isCloseRangeAttached = true;
                
            } catch (Exception e) {
                traceLog("api4_log", "显示关闭区域异常: " + e);
            }
        }
    });
}

void 隐藏关闭区域(final Activity activity) {
    if (wm == null) return;
    
    final Activity finalActivity = activity;
    activity.runOnUiThread(new Runnable() {
        public void run() {
            try {
                if (closeRangeView != null && closeRangeView.isAttachedToWindow()) {
                    wm.removeView(closeRangeView);
                }
                
                if (vibrator != null) {
                    vibrator.cancel();
                }
                xfcHandler.removeCallbacks(continuousVibrationRunnable);
                
                isInCloseRange = false;
                isCloseRangeAttached = false; // 重置附着标记
                
                traceLog("api4_log", "关闭区域已从WindowManager移除（View实例保留）");
                
            } catch (Exception e) {
                traceLog("api4_log", "隐藏关闭区域异常: " + e);
            }
        }
    });
}

void 更新关闭区域状态(Activity activity, int floatX, int floatY) {
    if (closeRangeView == null || !isDragging) return;
    
    try {
        int[] closeRangePos = new int[2];
        closeRangeView.getLocationOnScreen(closeRangePos);
        int closeCenterX = closeRangePos[0] + closeRangeView.getWidth() / 2;
        int closeCenterY = closeRangePos[1] + closeRangeView.getHeight() / 2;
        
        int floatCenterX = floatX + dp转px(activity, 30);
        int floatCenterY = floatY + dp转px(activity, 30);
        
        float distance = (float) Math.sqrt(
            Math.pow(closeCenterX - floatCenterX, 2) + 
            Math.pow(closeCenterY - floatCenterY, 2)
        );
        
        boolean previouslyInRange = isInCloseRange;
        isInCloseRange = distance <= (closeRangeView.getWidth() / 2f);
        
        if (closeRangeIcon != null) {
            int brightness = isInCloseRange ? 255 : 180;
            closeRangeIcon.setImageAlpha(brightness);
        }
        
        if (isInCloseRange && !previouslyInRange) {
            启动持续振动(activity);
        } else if (!isInCloseRange && previouslyInRange) {
            停止持续振动();
        }
        
    } catch (Exception e) {
        traceLog("api4_log", "更新关闭区域状态异常: " + e);
    }
}

void 启动持续振动(Activity activity) {
    if (vibrator == null) {
        vibrator = (Vibrator) activity.getSystemService(Context.VIBRATOR_SERVICE);
    }
    
    if (continuousVibrationRunnable == null) {
        continuousVibrationRunnable = new Runnable() {
            public void run() {
                if (isInCloseRange && isDragging) {
                    vibrate(activity, 12);
                    xfcHandler.postDelayed(this, VIBRATION_INTERVAL_MS);
                }
            }
        };
    }
    
    xfcHandler.post(continuousVibrationRunnable);
    traceLog("api4_log", "持续振动已启动");
}

void 停止持续振动() {
    if (vibrator != null) {
        vibrator.cancel();
    }
    xfcHandler.removeCallbacks(continuousVibrationRunnable);
    traceLog("api4_log", "持续振动已停止");
}

Bitmap 加载图标Bitmap(Activity activity) {
    Bitmap bitmap = null;
    if (iconPath != null && !iconPath.isEmpty()) {
        bitmap = 加载图片文件(iconPath);
    }
    if (bitmap == null) {
        bitmap = 创建默认图标(activity);
    }
    return bitmap;
}

Bitmap 加载图片文件(String path) {
    try {
        return BitmapFactory.decodeFile(path);
    } catch (Exception e) {
        return null;
    }
}

Bitmap 创建默认图标(Activity activity) {
    try {
        int size = dp转px(activity, 60);
        Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        Paint paint = new Paint();
        
        paint.setColor(Color.parseColor("#4CAF50"));
        paint.setStyle(Paint.Style.FILL);
        paint.setAntiAlias(true);
        canvas.drawCircle(size / 2, size / 2, size / 2, paint);
        
        paint.setColor(Color.WHITE);
        paint.setTextSize(dp转px(activity, 24));
        paint.setTextAlign(Paint.Align.CENTER);
        canvas.drawText("≡", size / 2, size / 2 + dp转px(activity, 8), paint);
        
        return bitmap;
    } catch (Exception e) {
        return null;
    }
}

void 设置图标图片(Activity activity, ImageView imageView) {
    if (cachedIconBitmap == null) {
        cachedIconBitmap = 加载图标Bitmap(activity);
    }
    if (cachedIconBitmap != null) {
        imageView.setImageBitmap(cachedIconBitmap);
    }
}

Bitmap 加载关闭图标Bitmap(Activity activity, String path) {
    Bitmap bitmap = null;
    traceLog("api4_log", "开始加载关闭图标，路径: " + (path != null && !path.isEmpty() ? path : "空路径"));
    
    if (path != null && !path.isEmpty()) {
        try {
            bitmap = BitmapFactory.decodeFile(path);
            traceLog("api4_log", "BitmapFactory.decodeFile结果: " + (bitmap != null ? "成功" : "失败"));
        } catch (Exception e) {
            traceLog("api4_log", "解码关闭图标异常: " + e.getMessage());
        }
    }
    
    if (bitmap == null) {
        traceLog("api4_log", "Bitmap为null，创建默认红色X图标");
        bitmap = 创建关闭区域Fallback图标(activity);
    }
    
    traceLog("api4_log", "最终关闭图标状态: " + (bitmap != null ? "可用" : "仍为null"));
    return bitmap;
}

boolean 检查悬浮窗权限(Activity activity) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        return Settings.canDrawOverlays(activity);
    }
    return true;
}

void 保存悬浮窗位置(Activity activity) {
    try {
        if (params != null && activity != null) {
            SharedPreferences sp = activity.getSharedPreferences("floating_window_pos", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sp.edit();
            editor.putInt("x", params.x);
            editor.putInt("y", params.y);
            editor.apply();
            // traceLog("api4_log", "位置已保存: X=" + params.x + ", Y=" + params.y);
        }
    } catch (Exception e) {
        traceLog("api4_log", "保存位置异常: " + e);
    }
}

int 加载悬浮窗位置(Activity activity) {
    try {
        if (activity != null) {
            SharedPreferences sp = activity.getSharedPreferences("floating_window_pos", Context.MODE_PRIVATE);
            return sp.getInt("x", 0);
        }
    } catch (Exception e) {
        traceLog("api4_log", "加载X位置异常: " + e);
    }
    return 0;
}

int 加载悬浮窗Y位置(Activity activity) {
    try {
        if (activity != null) {
            SharedPreferences sp = activity.getSharedPreferences("floating_window_pos", Context.MODE_PRIVATE);
            return sp.getInt("y", dp转px(activity, 100));
        }
    } catch (Exception e) {
        traceLog("api4_log", "加载Y位置异常: " + e);
    }
    return dp转px(activity, 100);
}

void 设置窗口参数(Activity activity) {
    int type;
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
    } else {
        type = WindowManager.LayoutParams.TYPE_PHONE;
    }
    params = new WindowManager.LayoutParams(
        dp转px(activity, 60),
        dp转px(activity, 60),
        type,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | 
        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        android.graphics.PixelFormat.TRANSLUCENT
    );
    params.gravity = Gravity.TOP | Gravity.LEFT;
    params.x = 加载悬浮窗位置(activity);
    params.y = 加载悬浮窗Y位置(activity);
    traceLog("api4_log", "窗口参数更新: 类型=" + type + ", 位置=(" + params.x + "," + params.y + ")");
}


void 创建悬浮窗视图(final Activity activity) {
    try {
        if (floatingView != null) {
            traceLog("api4_log", "视图已存在，跳过创建");
            悬浮窗状态 = STATE_CREATED;
            return;
        }
        
        touchOffsetX = 0;
        touchOffsetY = 0;
        currentAlpha = 255;
        
        floatingView = new FrameLayout(activity);
        floatingView.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        ));
        
        iconImageView = new ImageView(activity);
        int iconSize = dp转px(activity, 35);
        FrameLayout.LayoutParams iconParams = new FrameLayout.LayoutParams(iconSize, iconSize);
        iconImageView.setLayoutParams(iconParams);
        
        设置图标图片(activity, iconImageView);
        iconImageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        iconImageView.setImageAlpha(255);
        floatingView.addView(iconImageView);
        
        设置触摸事件(activity);
        
        悬浮窗状态 = STATE_CREATED;
        traceLog("api4_log", "悬浮窗视图创建完成");
        
    } catch (Exception e) {
        traceLog("api4_log", "创建悬浮窗视图异常: " + e);
        销毁悬浮窗资源();
    }
}

void 添加到窗口管理器(Activity activity) {
    try {
        if (floatingView == null || wm == null) {
            traceLog("api4_log", "添加到窗口管理器失败: 视图或WindowManager为空");
            return;
        }
        
        if (floatingView.isAttachedToWindow()) {
            traceLog("api4_log", "视图已附着，先移除");
            wm.removeView(floatingView);
        }
        
        设置窗口参数(activity);
        wm.addView(floatingView, params);
        
        if (iconImageView != null) {
            iconImageView.setImageAlpha(currentAlpha);
        }
        
        悬浮窗状态 = STATE_VISIBLE;
        悬浮窗显示状态 = true;
        traceLog("api4_log", "已添加到窗口管理器，位置: (" + params.x + "," + params.y + ")");
        
    } catch (Exception e) {
        traceLog("api4_log", "添加到窗口管理器异常: " + e);
        悬浮窗状态 = STATE_CREATED;
    }
}

void 销毁悬浮窗资源() {
    try {
        if (floatingView != null && floatingView.isAttachedToWindow()) {
            wm.removeView(floatingView);
        }
    } catch (Exception e) {
        traceLog("api4_log", "销毁资源异常: " + e);
    }
    
    floatingView = null;
    iconImageView = null;
    悬浮窗状态 = STATE_DESTROYED;
    悬浮窗显示状态 = false;
    允许触摸 = false;
    isLongClickScheduled = false;
    isDragging = false;
    isInCloseRange = false;
}

void 设置触摸事件(final Activity activity) {
    if (iconImageView == null) {
        traceLog("api4_log", "设置触摸事件失败: iconImageView为空");
        return;
    }
    
    final int moveThreshold = dp转px(activity, MOVE_THRESHOLD_DP);
    
    if (fadeRunnable == null) {
        fadeRunnable = new Runnable() {
            public void run() {
                if (isLongClickScheduled && currentAlpha > 100 && 悬浮窗显示状态 && 允许触摸) {
                    currentAlpha -= 10;
                    if (iconImageView != null) {
                        iconImageView.setImageAlpha(currentAlpha);
                    }
                    if (isLongClickScheduled) {
                        xfcHandler.postDelayed(this, 30);
                    }
                }
            }
        };
    }
    
    if (longClickRunnable == null) {
        longClickRunnable = new Runnable() {
            public void run() {
                isLongClickScheduled = false;
                if (悬浮窗显示状态 && 允许触摸) {
                    long pressDuration = System.currentTimeMillis() - touchStartTime;
                    if (pressDuration >= LONG_CLICK_THRESHOLD) {
                        activity.runOnUiThread(new Runnable() {
                            public void run() {
                                if (悬浮窗显示状态) {
                                    Toast("长按关闭悬浮窗");
                                    停止悬浮窗(activity);
                                    putBoolean("settings", "开关", false);
                                }
                            }
                        });
                    }
                }
            }
        };
    }
    
    iconImageView.setOnTouchListener(new View.OnTouchListener() {
        public boolean onTouch(View v, MotionEvent event) {
            if (!允许触摸 || floatingView == null || !悬浮窗显示状态) {
                return false;
            }
            
            boolean handled = false;
            
            try {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        isDragging = false;
                        touchStartTime = System.currentTimeMillis();
                        touchOffsetX = (int) (event.getRawX() - params.x);
                        touchOffsetY = (int) (event.getRawY() - params.y);
                        currentAlpha = 255;
                        
                        xfcHandler.removeCallbacks(fadeRunnable);
                        xfcHandler.postDelayed(fadeRunnable, 30);
                        
                        if (!isLongClickScheduled) {
                            isLongClickScheduled = true;
                            xfcHandler.postDelayed(longClickRunnable, LONG_CLICK_THRESHOLD);
                        }
                        handled = true;
                        break;
                        
                    case MotionEvent.ACTION_MOVE:
                        if (isLongClickScheduled) {
                            xfcHandler.removeCallbacks(longClickRunnable);
                            isLongClickScheduled = false;
                        }
                        xfcHandler.removeCallbacks(fadeRunnable);
                        
                        int deltaX = Math.abs((int)(event.getRawX() - (params.x + touchOffsetX)));
                        int deltaY = Math.abs((int)(event.getRawY() - (params.y + touchOffsetY)));
                        
                        if (!isDragging && (deltaX > moveThreshold || deltaY > moveThreshold)) {
                            isDragging = true;
                            显示关闭区域(activity);
                            traceLog("api4_log", "进入拖拽模式，显示关闭区域");
                        }
                        
                        if (isDragging) {
                            int newX = (int) (event.getRawX() - touchOffsetX);
                            int newY = (int) (event.getRawY() - touchOffsetY);
                            int screenWidth = wm.getDefaultDisplay().getWidth();
                            int screenHeight = wm.getDefaultDisplay().getHeight();
                            int iconSize = dp转px(activity, 60);
                            
                            newX = Math.max(0, Math.min(newX, screenWidth - iconSize));
                            newY = Math.max(0, Math.min(newY, screenHeight - iconSize));
                            
                            params.x = newX;
                            params.y = newY;
                            wm.updateViewLayout(floatingView, params);
                            保存悬浮窗位置(activity);
                            
                            更新关闭区域状态(activity, newX, newY);
                        }
                        
                        if (iconImageView != null) {
                            iconImageView.setImageAlpha(255);
                        }
                        handled = true;
                        break;
                        
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        xfcHandler.removeCallbacks(longClickRunnable);
                        xfcHandler.removeCallbacks(fadeRunnable);
                        isLongClickScheduled = false;
                        
                        if (iconImageView != null) {
                            iconImageView.setImageAlpha(255);
                        }
                        
                        if (isDragging) {
                            isDragging = false;
                            
                            if (isInCloseRange) {
                                traceLog("api4_log", "在关闭范围内松手，执行停止悬浮窗");
                                Toast("已关闭悬浮窗");
                                停止悬浮窗(activity);
                                putBoolean("settings", "开关", false);
                            } else {
                                traceLog("api4_log", "在关闭范围外松手，更新位置");
                            }
                            
                            隐藏关闭区域(activity);
                        } else if (event.getAction() == MotionEvent.ACTION_UP) {
                            long pressDuration = System.currentTimeMillis() - touchStartTime;
                            int deltaXUp = Math.abs((int) event.getRawX() - (params.x + touchOffsetX));
                            int deltaYUp = Math.abs((int) event.getRawY() - (params.y + touchOffsetY));
                            
                            if (pressDuration < LONG_CLICK_THRESHOLD && 
                                deltaXUp < moveThreshold && deltaYUp < moveThreshold) {
                                处理图标点击();
                            }
                        }
                        
                        handled = true;
                        break;
                }
            } catch (Exception e) {
                traceLog("api4_log", "触摸事件异常: " + e);
                xfcHandler.removeCallbacks(longClickRunnable);
                xfcHandler.removeCallbacks(fadeRunnable);
                停止持续振动();
                isLongClickScheduled = false;
                isDragging = false;
                isInCloseRange = false;
                if (iconImageView != null) {
                    iconImageView.setImageAlpha(255);
                }
                隐藏关闭区域(activity);
            }
            
            return handled;
        }
    });
}

void 处理图标点击() {
    try {
        final Activity activity = getNowActivity();
        if (activity == null) activity = 最后Activity;
        if (activity == null || activity.isFinishing()) {
            return;
        }
        final Activity finalActivity = activity;
        activity.runOnUiThread(new Runnable() {
            public void run() {
                vibrate(finalActivity, 48);
                if (!OK) {
                    显示菜单(finalActivity);
                    OK = true;
                }
            }
        });
    } catch (Exception e) {
        OK = false;
        traceLog("api4_log", "点击处理异常: " + e);
    }
}


public void 悬浮窗开关(int chatType, String peerUin, String name) {
    Activity activity = getNowActivity();
    if (activity == null) activity = 最后Activity;
    if (activity == null) return;
    
    final Activity finalActivity = activity;
    activity.runOnUiThread(new Runnable() {
        public void run() {
            boolean 开关状态 = !getBoolean("settings", "开关", false);
            putBoolean("settings", "开关", 开关状态);
            vibrate(finalActivity, 48);
            traceLog("api4_log", "悬浮窗开关状态改变: " + 开关状态);
            
            if (开关状态) {
                启动悬浮窗(finalActivity);
            } else {
                停止悬浮窗(finalActivity);
            }
        }
    });
}

public void 启动悬浮窗(final Activity activity) {
    try {
        traceLog("api4_log", "启动悬浮窗开始，当前状态: " + 悬浮窗状态 + "，Activity: " + (activity != null));
        if (activity == null || activity.isFinishing()) {
            traceLog("api4_log", "启动悬浮窗失败: Activity无效");
            return;
        }
        
        wm = (WindowManager) activity.getSystemService(Context.WINDOW_SERVICE);
        if (wm == null) {
            traceLog("api4_log", "启动悬浮窗失败: 无法获取WindowManager");
            return;
        }
        
        if (!检查悬浮窗权限(activity)) {
            Toast("请先授予悬浮窗权限");
            traceLog("api4_log", "启动悬浮窗失败: 无悬浮窗权限");
            return;
        }
        
        switch (悬浮窗状态) {
            case STATE_DESTROYED:
                创建悬浮窗视图(activity);
                添加到窗口管理器(activity);
                break;
            case STATE_HIDDEN:
                currentAlpha = 255;
                添加到窗口管理器(activity);
                break;
            case STATE_VISIBLE:
                traceLog("api4_log", "悬浮窗已显示，无需重复启动");
                break;
            case STATE_CREATED:
                currentAlpha = 255;
                添加到窗口管理器(activity);
                break;
        }
        OK = false;
        允许触摸 = true;
        traceLog("api4_log", "悬浮窗启动完成，最终状态: " + 悬浮窗状态);
        
    } catch (Exception e) {
        traceLog("api4_log", "启动悬浮窗异常: " + e);
    }
}

public void 停止悬浮窗(final Activity activity) {
    try {
        traceLog("api4_log", "停止悬浮窗，当前状态: " + 悬浮窗状态);
        
        xfcHandler.removeCallbacksAndMessages(null);
        isLongClickScheduled = false;
        isDragging = false; // 重置拖拽状态
        isInCloseRange = false;
        
        停止持续振动();
        隐藏关闭区域(activity);
        
        保存悬浮窗位置(activity);
        
        switch (悬浮窗状态) {
            case STATE_VISIBLE:
                if (floatingView != null && wm != null) {
                    try {
                        if (floatingView.isAttachedToWindow()) {
                            wm.removeView(floatingView);
                        }
                    } catch (Exception e) {
                        traceLog("api4_log", "移除悬浮窗异常: " + e);
                    }
                }
                悬浮窗状态 = STATE_HIDDEN;
                悬浮窗显示状态 = false;
                允许触摸 = false;
                traceLog("api4_log", "悬浮窗已隐藏（视图保留）");
                break;
            case STATE_HIDDEN:
                traceLog("api4_log", "悬浮窗已处于隐藏状态");
                break;
            case STATE_CREATED:
                销毁悬浮窗资源();
                traceLog("api4_log", "未显示的悬浮窗已销毁");
                break;
            case STATE_DESTROYED:
                traceLog("api4_log", "悬浮窗已销毁，无需重复操作");
                break;
        }
        
    } catch (Exception e) {
        traceLog("api4_log", "停止悬浮窗异常: " + e);
        悬浮窗状态 = STATE_DESTROYED;
        悬浮窗显示状态 = false;
        允许触摸 = false;
        isDragging = false;
        isInCloseRange = false;
    }
}

void 停止悬浮窗() {
    Activity activity = getNowActivity() != null ? getNowActivity() : 最后Activity;
    if (activity != null) {
        停止悬浮窗(activity);
    } else {
        xfcHandler.removeCallbacksAndMessages(null);
        悬浮窗状态 = STATE_DESTROYED;
        悬浮窗显示状态 = false;
        允许触摸 = false;
        isLongClickScheduled = false;
        isDragging = false;
        isInCloseRange = false;
    }
}

void 卸载悬浮窗() {
    停止悬浮窗();
    try {
        if (floatingView != null && floatingView.isAttachedToWindow()) {
            wm.removeView(floatingView);
        }
        if (closeRangeView != null && closeRangeView.isAttachedToWindow()) {
            wm.removeView(closeRangeView);
        }
    } catch (Exception e) {
        traceLog("api4_log", "销毁资源异常: " + e);
    }
    
    floatingView = null;
    iconImageView = null;
    closeRangeView = null;
    closeRangeIcon = null;
    
    if (cachedIconBitmap != null) {
        cachedIconBitmap.recycle();
        cachedIconBitmap = null;
    }
    if (cachedCloseIconBitmap != null) {
        cachedCloseIconBitmap.recycle();
        cachedCloseIconBitmap = null;
    }
    
    悬浮窗状态 = STATE_DESTROYED;
    悬浮窗显示状态 = false;
    允许触摸 = false;
    isLongClickScheduled = false;
    isDragging = false;
    isInCloseRange = false;
    isCloseRangeAttached = false;
    
    xfcHandler.removeCallbacksAndMessages(null);
    if (vibrator != null) {
        vibrator.cancel();
    }
    traceLog("api4_log", "悬浮窗资源完全卸载");
}
