
public void openPlugin(int functionType, String groupId, String userName) {
    跳转到页面("me.yxp.qfun.activity.PluginActivity");
}

public void openSetting(int functionType, String groupId, String userName) {
    跳转到页面("me.yxp.qfun.activity.SettingActivity");
}

void 跳转到页面(String className) {
    Activity activity = getNowActivity();
    if (activity == null) activity = 最后Activity;
    if (activity == null) return;
    
    vibrate(activity, 48);
    Intent intent = new Intent();
    intent.setAction(Intent.ACTION_MAIN);
    intent.setComponent(new ComponentName(currentPackageName, className));
    try {
        activity.startActivity(intent);
        traceLog("api5_log.txt","跳转到页面: " + className);
    } catch (Exception e) {
        traceLog("api5_log.txt","跳转页面失败: " + e);
    }
}