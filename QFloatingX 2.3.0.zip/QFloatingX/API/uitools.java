//UI工具类

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ClipboardManager;
import android.content.ClipData;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.renderscript.Allocation;
import android.renderscript.Element;
import android.renderscript.RenderScript;
import android.renderscript.ScriptIntrinsicBlur;
import android.view.*;
import android.widget.*;
import android.util.TypedValue;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import java.util.WeakHashMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;

/**
 * 根据 MIME 类型获取文件扩展名
 * @param mimeType MIME 类型字符串
 * @return 文件扩展名，默认返回 .png
 */
String getExtensionFromMimeType(String mimeType) {
    if (mimeType == null) return ".png";
    if (mimeType.equals("image/gif") || mimeType.equals("webp/gif")) return ".gif";
    return ".png";
}

/**
 * 从 Uri 加载 Bitmap
 * @param activity 当前 Activity
 * @param uri 图片 URI
 * @return 解码后的 Bitmap，失败返回 null
 */
Bitmap loadBitmapFromUri(Activity activity, Uri uri) {
    try {
        return BitmapFactory.decodeStream(activity.getContentResolver().openInputStream(uri));
    } catch (Throwable e) {
        return null;
    }
}

/**
 * 获取压缩预览图
 * @param src 源图片
 * @param quality 压缩质量 (0-100)
 * @return 压缩后的 Bitmap
 */
Bitmap getCompressedPreview(Bitmap src, int quality) {
    if (quality >= 100 || src == null) return src;
    try {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        src.compress(Bitmap.CompressFormat.JPEG, quality, baos);
        byte[] bytes = baos.toByteArray();
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
    } catch (Throwable e) { return src; }
}

/**
 * 创建棋盘格背景 Drawable（用于透明图片展示）
 * @param context 上下文
 * @return 棋盘格 BitmapDrawable
 */
BitmapDrawable getCheckerboardDrawable(Context context) {
    int size = dp(context, 20); // 格子大小
    Bitmap b = Bitmap.createBitmap(size * 2, size * 2, Bitmap.Config.ARGB_8888);
    Canvas c = new Canvas(b);
    Paint p = new Paint();
    p.setColor(Color.parseColor("#FFCCCCCC"));
    c.drawRect(0, 0, size, size, p);
    c.drawRect(size, size, size * 2, size * 2, p);
    p.setColor(Color.parseColor("#FFEEEEEE"));
    c.drawRect(size, 0, size * 2, size, p);
    c.drawRect(0, size, size, size * 2, p);
    BitmapDrawable drawable = new BitmapDrawable(context.getResources(), b);
    drawable.setTileModeXY(Shader.TileMode.REPEAT, Shader.TileMode.REPEAT);
    return drawable;
}

// =============== 核心组件：手动缩放与背景切换视图 ===============

/**
 * 支持手势缩放和点击切换背景的 ImageView
 */
class ZoomImageView extends ImageView {
    public Matrix matrix = new Matrix();
    private Matrix savedMatrix = new Matrix();
    private float startDistance = 0f;
    private float midX = 0f, midY = 0f;
    private float lastX = 0f, lastY = 0f;
    private int mode = 0; // 模式：1=拖拽，2=缩放
    private View rootLayout; // 根布局
    private int bgIndex = 0; // 背景索引

    public ZoomImageView(Context context, View root) {
        super(context);
        this.rootLayout = root;
        setScaleType(ImageView.ScaleType.MATRIX);
    }

    public boolean onTouchEvent(MotionEvent event) {
        float x = event.getX();
        float y = event.getY();
        switch (event.getAction() & MotionEvent.ACTION_MASK) {
            case MotionEvent.ACTION_DOWN:
                savedMatrix.set(matrix);
                lastX = x; lastY = y;
                mode = 1;
                break;
            case MotionEvent.ACTION_POINTER_DOWN:
                startDistance = calculateDistance(event);
                if (startDistance > 10f) {
                    savedMatrix.set(matrix);
                    midX = (event.getX(0) + event.getX(1)) / 2;
                    midY = (event.getY(0) + event.getY(1)) / 2;
                    mode = 2;
                }
                break;
            case MotionEvent.ACTION_MOVE:
                if (mode == 1) {
                    matrix.set(savedMatrix);
                    matrix.postTranslate(x - lastX, y - lastY);
                } else if (mode == 2) {
                    float newDist = calculateDistance(event);
                    if (newDist > 10f) {
                        matrix.set(savedMatrix);
                        float scale = newDist / startDistance;
                        matrix.postScale(scale, scale, midX, midY);
                    }
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
                if (mode == 1 && Math.abs(x - lastX) < 10 && Math.abs(y - lastY) < 10) {
                    if (!isInside(x, y)) {
                        bgIndex = (bgIndex + 1) % 3;
                        if (bgIndex == 0) rootLayout.setBackgroundColor(Color.parseColor("#FF000000"));
                        else if (bgIndex == 1) rootLayout.setBackgroundColor(Color.parseColor("#FFFFFFFF"));
                        else rootLayout.setBackground(getCheckerboardDrawable(getContext()));
                        vibrate(getContext(), 30);
                    }
                }
                mode = 0;
                break;
        }
        setImageMatrix(matrix);
        return true;
    }

    /** 计算两点距离 */
    private float calculateDistance(MotionEvent event) {
        float dx = event.getX(0) - event.getX(1);
        float dy = event.getY(0) - event.getY(1);
        return (float) Math.sqrt(dx * dx + dy * dy);
    }

    /** 判断点击点是否在图片内部 */
    private boolean isInside(float x, float y) {
        if (getDrawable() == null) return false;
        RectF r = new RectF(0, 0, getDrawable().getIntrinsicWidth(), getDrawable().getIntrinsicHeight());
        matrix.mapRect(r);
        return r.contains(x, y);
    }
}

// =============== 裁剪组件 ===============

/**
 * 裁剪覆盖视图
 */
class CropOverlayView extends View {
    public Rect cropRect = new Rect();
    private Paint pBorder, pCorner, pMask;
    private int tMode = 0; // 触摸模式
    private float lastX, lastY;

    public CropOverlayView(Context context) {
        super(context);
        pBorder = new Paint(1); pBorder.setColor(Color.parseColor("#FF00FF00")); pBorder.setStyle(Paint.Style.STROKE); pBorder.setStrokeWidth(4);
        pCorner = new Paint(1); pCorner.setColor(Color.parseColor("#FF00FF00")); pCorner.setStrokeWidth(16);
        pMask = new Paint(); pMask.setColor(Color.parseColor("#99000000"));
    }

    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        int side = Math.min(w, h) * 4 / 5;
        cropRect.set((w - side) / 2, (h - side) / 2, (w + side) / 2, (h + side) / 2);
    }

    protected void onDraw(Canvas canvas) {
        canvas.drawRect(0, 0, getWidth(), cropRect.top, pMask);
        canvas.drawRect(0, cropRect.bottom, getWidth(), getHeight(), pMask);
        canvas.drawRect(0, cropRect.top, cropRect.left, cropRect.bottom, pMask);
        canvas.drawRect(cropRect.right, cropRect.top, getWidth(), cropRect.bottom, pMask);
        canvas.drawRect(cropRect, pBorder);
        int l = 50;
        canvas.drawLine(cropRect.left, cropRect.top, cropRect.left + l, cropRect.top, pCorner);
        canvas.drawLine(cropRect.left, cropRect.top, cropRect.left, cropRect.top + l, pCorner);
        canvas.drawLine(cropRect.right - l, cropRect.top, cropRect.right, cropRect.top, pCorner);
        canvas.drawLine(cropRect.right, cropRect.top, cropRect.right, cropRect.top + l, pCorner);
        canvas.drawLine(cropRect.left, cropRect.bottom - l, cropRect.left, cropRect.bottom, pCorner);
        canvas.drawLine(cropRect.left, cropRect.bottom, cropRect.left + l, cropRect.bottom, pCorner);
        canvas.drawLine(cropRect.right - l, cropRect.bottom, cropRect.right, cropRect.bottom, pCorner);
        canvas.drawLine(cropRect.right, cropRect.bottom - l, cropRect.right, cropRect.bottom, pCorner);
    }

    public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX(), y = e.getY();
        if (e.getAction() == MotionEvent.ACTION_DOWN) {
            lastX = x; lastY = y;
            if (Math.abs(x - cropRect.left) < 80 && Math.abs(y - cropRect.top) < 80) tMode = 2;
            else if (Math.abs(x - cropRect.right) < 80 && Math.abs(y - cropRect.top) < 80) tMode = 3;
            else if (Math.abs(x - cropRect.left) < 80 && Math.abs(y - cropRect.bottom) < 80) tMode = 4;
            else if (Math.abs(x - cropRect.right) < 80 && Math.abs(y - cropRect.bottom) < 80) tMode = 5;
            else if (cropRect.contains((int)x, (int)y)) tMode = 1;
            else tMode = 0;
            return tMode != 0;
        } else if (e.getAction() == MotionEvent.ACTION_MOVE && tMode != 0) {
            float dx = x - lastX, dy = y - lastY;
            if (tMode == 1) cropRect.offset((int)dx, (int)dy);
            else {
                if (tMode == 2 || tMode == 4) cropRect.left = (int)Math.max(0, Math.min(x, cropRect.right - 100));
                if (tMode == 3 || tMode == 5) cropRect.right = (int)Math.min(getWidth(), Math.max(x, cropRect.left + 100));
                if (tMode == 2 || tMode == 3) cropRect.top = (int)Math.max(0, Math.min(y, cropRect.bottom - 100));
                if (tMode == 4 || tMode == 5) cropRect.bottom = (int)Math.min(getHeight(), Math.max(y, cropRect.top + 100));
            }
            lastX = x; lastY = y; invalidate(); return true;
        }
        return false;
    }

    /** 获取实际裁剪矩形 */
    public Rect getRealRect(Bitmap b, Matrix m) {
        float[] v = new float[9]; m.getValues(v);
        float s = v[0], tx = v[2], ty = v[5];
        return new Rect(
            (int)((cropRect.left - tx) / s), (int)((cropRect.top - ty) / s),
            (int)((cropRect.right - tx) / s), (int)((cropRect.bottom - ty) / s)
        );
    }
}

// =============== 主编辑器逻辑 ===============

/**
 * 显示图片编辑对话框
 * @param activity 当前 Activity
 * @param origin 原始图片
 * @param savePath 保存路径
 * @param requestCode 请求码
 */
void showEditDialog(final Activity activity, final Bitmap origin, final String savePath, final int requestCode) {
    try {
        final List history = new ArrayList(); history.add(origin);
        final int[] idx = {0}, quality = {100};

        final Dialog dialog = new Dialog(activity, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        final FrameLayout root = new FrameLayout(activity);
        root.setBackgroundColor(Color.parseColor("#FF000000"));

        final ZoomImageView preview = new ZoomImageView(activity, root);
        preview.setImageBitmap(origin);
        
        // 自动居中
        preview.post(new Runnable() {
            public void run() {
                float vw = preview.getWidth(), vh = preview.getHeight();
                float iw = origin.getWidth(), ih = origin.getHeight();
                float avH = vh - dp(activity, 120);
                float s = Math.min(vw / iw, avH / ih) * 0.9f;
                preview.matrix.setScale(s, s);
                preview.matrix.postTranslate((vw - iw * s) / 2f, (avH - ih * s) / 2f);
                preview.setImageMatrix(preview.matrix);
            }
        });

        final FrameLayout container = new FrameLayout(activity);
        FrameLayout.LayoutParams cLp = new FrameLayout.LayoutParams(-1, -1);
        cLp.bottomMargin = dp(activity, 120);
        container.addView(preview, new FrameLayout.LayoutParams(-1, -1));

        final CropOverlayView crop = new CropOverlayView(activity);
        crop.setVisibility(View.GONE);
        container.addView(crop, new FrameLayout.LayoutParams(-1, -1));
        root.addView(container, cLp);

        HorizontalScrollView scroll = new HorizontalScrollView(activity);
        scroll.setHorizontalScrollBarEnabled(false);
        LinearLayout toolBar = new LinearLayout(activity);
        toolBar.setPadding(dp(activity, 12), dp(activity, 12), dp(activity, 12), dp(activity, 12));

        String[] toolNames = {"取消", "撤销", "重做", "旋转", "裁剪", "质量: 原画", "保存"};
        for (int i = 0; i < toolNames.length; i++) {
            final Button btn = new Button(activity);
            btn.setText(toolNames[i]); btn.setTextColor(Color.parseColor("#FFFFFFFF")); btn.setAllCaps(false);
            GradientDrawable gd = new GradientDrawable(); gd.setColor(Color.parseColor("#FF333333")); gd.setCornerRadius(dp(activity, 10));
            btn.setBackground(gd);
            LinearLayout.LayoutParams bLp = new LinearLayout.LayoutParams(dp(activity, 90), dp(activity, 48));
            bLp.setMargins(dp(activity, 6), 0, dp(activity, 6), 0);

            btn.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    vibrate(activity, 40);
                    String action = btn.getText().toString();
                    if (action.equals("取消")) {
                        dialog.dismiss();
                    } else if (action.equals("撤销")) {
                        if (idx[0] > 0) {
                            idx[0]--; preview.setImageBitmap(getCompressedPreview((Bitmap)history.get(idx[0]), quality[0]));
                        }
                    } else if (action.equals("重做")) {
                        if (idx[0] < history.size() - 1) {
                            idx[0]++; preview.setImageBitmap(getCompressedPreview((Bitmap)history.get(idx[0]), quality[0]));
                        }
                    } else if (action.equals("旋转")) {
                        Matrix m = new Matrix(); m.postRotate(90);
                        Bitmap cur = (Bitmap)history.get(idx[0]);
                        Bitmap next = Bitmap.createBitmap(cur, 0, 0, cur.getWidth(), cur.getHeight(), m, true);
                        while (history.size() > idx[0] + 1) history.remove(history.size() - 1);
                        history.add(next); idx[0]++; preview.setImageBitmap(getCompressedPreview(next, quality[0]));
                    } else if (action.equals("裁剪")) {
                        crop.setVisibility(crop.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
                    } else if (action.startsWith("质量")) {
                        if (quality[0] == 100) { quality[0] = 85; btn.setText("质量: 高"); }
                        else if (quality[0] == 85) { quality[0] = 60; btn.setText("质量: 中"); }
                        else { quality[0] = 100; btn.setText("质量: 原画"); }
                        preview.setImageBitmap(getCompressedPreview((Bitmap)history.get(idx[0]), quality[0]));
                    } else if (action.equals("保存")) {
                        Bitmap res = (Bitmap)history.get(idx[0]);
                        if (crop.getVisibility() == View.VISIBLE) {
                            Rect r = crop.getRealRect(res, preview.matrix);
                            int nx = Math.max(0, r.left), ny = Math.max(0, r.top);
                            int nw = Math.min(res.getWidth() - nx, r.width());
                            int nh = Math.min(res.getHeight() - ny, r.height());
                            if (nw > 10 && nh > 10) res = Bitmap.createBitmap(res, nx, ny, nw, nh);
                        }
                        performSave(activity, res, savePath, quality[0]);
                        dialog.dismiss();
                    }
                }
            });
            toolBar.addView(btn, bLp);
        }
        scroll.addView(toolBar);
        FrameLayout.LayoutParams sLp = new FrameLayout.LayoutParams(-1, -2);
        sLp.gravity = Gravity.BOTTOM; sLp.bottomMargin = dp(activity, 30);
        root.addView(scroll, sLp);

        // 内存回收监听
        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            public void onDismiss(DialogInterface d) {
                for (int i = 0; i < history.size(); i++) {
                    Bitmap b = (Bitmap) history.get(i);
                    if (b != null && !b.isRecycled()) b.recycle();
                }
                history.clear();
            }
        });

        dialog.setContentView(root);
        dialog.show();
    } catch (Throwable e) {
        Toast("启动失败: " + e.getMessage());
    }
}

/** 执行保存操作 */
void performSave(final Activity activity, final Bitmap b, final String p, final int q) {
    ThreadPool.execute(new Runnable() {
        public void run() {
            try {
                File f = new File(p); if (!f.getParentFile().exists()) f.getParentFile().mkdirs();
                FileOutputStream o = new FileOutputStream(f);
                b.compress(Bitmap.CompressFormat.JPEG, q, o);
                o.flush(); o.close();
                activity.runOnUiThread(new Runnable() { public void run() { Toast("保存成功 (" + q + "%)"); 刷新悬浮窗(); } });
            } catch (Throwable e) {}
        }
    });
}

/** 编辑并保存图片入口 */
void editAndSaveImage(final Activity activity, final Uri uri, final String p, final int c) {
    // GIF判定
    if (p.toLowerCase().endsWith(".gif")) {
        ThreadPool.execute(new Runnable() {
            public void run() {
                try {
                    InputStream is = activity.getContentResolver().openInputStream(uri);
                    File f = new File(p); if (!f.getParentFile().exists()) f.getParentFile().mkdirs();
                    FileOutputStream os = new FileOutputStream(f);
                    byte[] buf = new byte[8192]; int len;
                    while ((len = is.read(buf)) != -1) os.write(buf, 0, len);
                    os.flush(); os.close(); is.close();
                    activity.runOnUiThread(new Runnable() { public void run() { Toast("GIF动图已保存"); 刷新悬浮窗(); } });
                } catch (Exception e) {}
            }
        });
        return;
    }

    ThreadPool.execute(new Runnable() {
        public void run() {
            final Bitmap b = loadBitmapFromUri(activity, uri);
            if (b == null) return;
            activity.runOnUiThread(new Runnable() { public void run() { showEditDialog(activity, b, p, c); } });
        }
    });
}

// =============== Hook 集成部分 ===============

static boolean isFilePickerHooked = false;
/** Hook 文件选择器结果 */
void hookFilePicker(final Activity activity, final int requestCode, final String savePath) {
    if (isFilePickerHooked) return;
    try {
        isFilePickerHooked = true;
        XposedBridge.hookMethod(Activity.class.getDeclaredMethod("onActivityResult", int.class, int.class, Intent.class), new XC_MethodHook() {
            protected void afterHookedMethod(XC_MethodHook.MethodHookParam param) {
                ThreadPool.execute(new Runnable() {
                    public void run() {
                        try {
                            Activity act = (Activity) param.thisObject;
                            if (act.equals(activity) && (Integer)param.args[1] == Activity.RESULT_OK && (Integer)param.args[0] == requestCode) {
                                Intent d = (Intent)param.args[2]; if (d == null) return;
                                Uri u = d.getData(); if (u == null) return;
                                String type = act.getContentResolver().getType(u);
                                String ext = getExtensionFromMimeType(type);
                                String path = savePath.contains("{ext}") ? savePath.replace("{ext}", ext) : (savePath.lastIndexOf('.') > 0 ? savePath.substring(0, savePath.lastIndexOf('.')) + ext : savePath + ext);
                                if (requestCode == 1005) {
                                putString("settings", "iconPath", path);
                                }
                                act.runOnUiThread(new Runnable() { public void run() { editAndSaveImage(act, u, path, requestCode); } });
                            }
                        } catch (Throwable e) {}
                    }
                });
            }
        });
    } catch (Throwable e) {}
}

/** 判断颜色是否为深色 */
public boolean isColorDark(int color) {
    double darkness = 1 - (0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color)) / 255;
    return darkness >= 0.5; 
}

// =============== 图片处理工具类 ===============

/**
 * RenderScript模糊 (支持原图修改和输出Bitmap两种模式)
 * @param activity 上下文
 * @param bitmap 源 Bitmap
 * @param outBitmap 输出 Bitmap (可为空，则修改原图)
 * @param radius 模糊半径
 * @return 模糊后的 Bitmap
 */
public Bitmap blurBitmap(Activity activity, Bitmap bitmap, Bitmap outBitmap, float radius) {
    if (radius <= 0 || bitmap == null || bitmap.isRecycled()) return bitmap;
    if (radius > 25) radius = 25;
    
    if (outBitmap == null) {
        outBitmap = bitmap;
    }
    
    RenderScript rs = null;
    try {
        rs = RenderScript.create(activity);
        ScriptIntrinsicBlur blurScript = ScriptIntrinsicBlur.create(rs, Element.U8_4(rs));
        
        Allocation allIn = Allocation.createFromBitmap(rs, bitmap);
        Allocation allOut = Allocation.createFromBitmap(rs, outBitmap);
        
        blurScript.setRadius(radius);
        blurScript.setInput(allIn);
        blurScript.forEach(allOut);
        allOut.copyTo(outBitmap);
        
        return outBitmap;
    } catch (Throwable e) {
        try {
            return fastblur(bitmap, (int) Math.min(7, radius));
        } catch (Exception ex) {
            return bitmap;
        }
    } finally {
        if (rs != null) {
            try { rs.destroy(); } catch (Exception e) {}
        }
    }
}

/**
 * 快速模糊 (StackBlur算法的简化版)
 * @param bmp 源图片
 * @param radius 模糊半径
 * @return 模糊后的图片
 */
public Bitmap fastblur(Bitmap bmp, int radius) {
    if (bmp == null || radius <= 0) return bmp;
    
    int w = bmp.getWidth();
    int h = bmp.getHeight();
    
    if (radius > w / 2) radius = w / 2;
    if (radius > h / 2) radius = h / 2;
    
    int smallW = Math.max(1, w / (radius + 1));
    int smallH = Math.max(1, h / (radius + 1));
    Bitmap small = Bitmap.createScaledBitmap(bmp, smallW, smallH, true);
    
    int[] pixels = new int[smallW * smallH];
    small.getPixels(pixels, 0, smallW, 0, 0, smallW, smallH);
    
    for (int i = 0; i < 3; i++) {
        for (int y = 0; y < smallH; y++) {
            for (int x = 0; x < smallW; x++) {
                int r = 0, g = 0, b = 0, a = 0, count = 0;
                for (int dy = -radius; dy <= radius; dy++) {
                    for (int dx = -radius; dx <= radius; dx++) {
                        int ny = y + dy;
                        int nx = x + dx;
                        if (ny >= 0 && ny < smallH && nx >= 0 && nx < smallW) {
                            int pixel = pixels[ny * smallW + nx];
                            r += Color.red(pixel);
                            g += Color.green(pixel);
                            b += Color.blue(pixel);
                            a += Color.alpha(pixel);
                            count++;
                        }
                    }
                }
                pixels[y * smallW + x] = Color.argb(a / count, r / count, g / count, b / count);
            }
        }
    }
    
    small.setPixels(pixels, 0, smallW, 0, 0, smallW, smallH);
    
    Bitmap result = Bitmap.createScaledBitmap(small, w, h, true);
    if (small != result && !small.isRecycled()) {
        small.recycle();
    }
    
    return result;
}

/**
 * 调整Bitmap大小，最大边不超过maxSize，保持比例
 * @param original 原图
 * @param maxSize 最大边长
 * @return 调整后的图
 */
public Bitmap resizeBitmap(Bitmap original, int maxSize) {
    if (original == null || original.isRecycled()) return null;
    
    int width = original.getWidth();
    int height = original.getHeight();
    
    if (width <= maxSize && height <= maxSize) {
        return original;
    }
    
    float scale = Math.min((float) maxSize / width, (float) maxSize / height);
    int newWidth = Math.round(width * scale);
    int newHeight = Math.round(height * scale);
    
    return Bitmap.createScaledBitmap(original, newWidth, newHeight, true);
}

/**
 * 居中裁剪Bitmap到目标尺寸 (CenterCrop)
 * @param source 源图
 * @param targetWidth 目标宽
 * @param targetHeight 目标高
 * @return 裁剪后的图
 */
public Bitmap centerCropBitmap(Bitmap source, int targetWidth, int targetHeight) {
    if (source == null || source.isRecycled()) return null;
    
    int sourceW = source.getWidth();
    int sourceH = source.getHeight();
    
    if (sourceW == targetWidth && sourceH == targetHeight) {
        return source;
    }
    
    float scale = Math.max((float) targetWidth / sourceW, (float) targetHeight / sourceH);
    float scaledW = sourceW * scale;
    float scaledH = sourceH * scale;
    
    float left = (targetWidth - scaledW) / 2;
    float top = (targetHeight - scaledH) / 2;
    
    Bitmap dest = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888);
    Canvas canvas = new Canvas(dest);
    
    RectF sourceRect = new RectF(0, 0, sourceW, sourceH);
    RectF targetRect = new RectF(left, top, left + scaledW, top + scaledH);
    
    Matrix matrix = new Matrix();
    matrix.setRectToRect(sourceRect, targetRect, Matrix.ScaleToFit.FILL);
    
    Paint paint = new Paint();
    paint.setAntiAlias(true);
    paint.setFilterBitmap(true);
    canvas.drawBitmap(source, matrix, paint);
    
    return dest;
}

/**
 * 优化智能缩放算法（CenterCrop确保填满目标区域，不拉伸）
 * @param source 源图
 * @param targetW 目标宽
 * @param targetH 目标高
 * @return 缩放裁剪后的图
 */
Bitmap smartScaleBitmap(Bitmap source, int targetW, int targetH) {
    if (source == null || source.isRecycled()) return null;
    if (targetW <= 0 || targetH <= 0) return null;
    
    try {
        int sourceW = source.getWidth();
        int sourceH = source.getHeight();
        if (sourceW == 0 || sourceH == 0) return null;
        
        float sourceRatio = (float) sourceW / sourceH;
        float targetRatio = (float) targetW / targetH;
        
        Bitmap cropped;
        if (sourceRatio > targetRatio) {
            int cropW = (int) (sourceH * targetRatio);
            int cropX = (sourceW - cropW) / 2;
            cropped = Bitmap.createBitmap(source, cropX, 0, cropW, sourceH);
        } else {
            int cropH = (int) (sourceW / targetRatio);
            int cropY = (sourceH - cropH) / 2;
            cropped = Bitmap.createBitmap(source, 0, cropY, sourceW, cropH);
        }
        
        if (cropped.getWidth() != targetW || cropped.getHeight() != targetH) {
            Bitmap scaled = Bitmap.createScaledBitmap(cropped, targetW, targetH, true);
            if (cropped != source) {
                cropped.recycle();
            }
            return scaled;
        }
        
        return cropped;
        
    } catch (OutOfMemoryError e) {
        return null;
    } catch (Exception e) {
        return null;
    }
}

Bitmap scaleToFitBitmap(Bitmap source, int targetW, int targetH) {
    if (source == null || source.isRecycled()) return null;
    
    try {
        int sourceW = source.getWidth();
        int sourceH = source.getHeight();
        
        float scale = Math.min((float) targetW / sourceW, (float) targetH / sourceH);
        int scaledW = Math.round(sourceW * scale);
        int scaledH = Math.round(sourceH * scale);
        
        Bitmap result = Bitmap.createScaledBitmap(source, scaledW, scaledH, true);
        return result;
        
    } catch (Exception e) {
        return source;
    }
}

Bitmap smartCenterCropBitmap(Bitmap source, int targetW, int targetH) {
    return smartScaleBitmap(source, targetW, targetH);
}

// =============== 优化的缓存系统（带尺寸容差）===============

/** 生成缓存键 */
String generateCacheKey(String imgPath, int blurRadius, int overlayAlpha, boolean isDark, int targetW, int targetH) {
    File f = new File(imgPath);
    long lastMod = f.exists() ? f.lastModified() : 0;
    long size = f.exists() ? f.length() : 0;
    int widthGroup = (targetW / 20) * 20;
    int heightGroup = (targetH / 20) * 20;
    return imgPath.hashCode() + "_" + lastMod + "_" + size + "_" + blurRadius + "_" + 
           overlayAlpha + "_" + (isDark ? "1" : "0") + "_" + widthGroup + "_" + heightGroup;
}

String generateBaseCacheKey(String imgPath, int blurRadius, int overlayAlpha, boolean isDark) {
    File f = new File(imgPath);
    long lastMod = f.exists() ? f.lastModified() : 0;
    return imgPath.hashCode() + "_" + lastMod + "_" + blurRadius + "_" + overlayAlpha + "_" + (isDark ? "1" : "0");
}

Drawable findSimilarCache(String baseKey, int targetW, int targetH) {
    Iterator iterator = cacheOrder.keySet().iterator();
    while (iterator.hasNext()) {
        String key = (String) iterator.next();
        if (key.startsWith(baseKey + "_")) {
            try {
                String[] parts = key.split("_");
                int cachedW = Integer.parseInt(parts[parts.length - 2]);
                int cachedH = Integer.parseInt(parts[parts.length - 1]);
                
                float widthDiff = Math.abs(cachedW - targetW) / (float) targetW;
                float heightDiff = Math.abs(cachedH - targetH) / (float) targetH;
                
                if (widthDiff <= 0.2f && heightDiff <= 0.2f) {
                    CacheEntry entry = (CacheEntry) imageCache.get(key);
                    if (entry != null && entry.drawable != null) {
                        return entry.drawable;
                    }
                }
            } catch (Exception e) {}
        }
    }
    return null;
}

boolean checkAndCleanupMemoryIfNeeded() {
    Runtime runtime = Runtime.getRuntime();
    long maxMemory = runtime.maxMemory();
    long totalMemory = runtime.totalMemory();
    long freeMemory = runtime.freeMemory();
    long usedMemory = totalMemory - freeMemory;
    
    float usedRatio = (float) usedMemory / maxMemory;
    
    if (usedRatio > 0.85f) {
        if (!cacheOrder.isEmpty()) {
            String oldestKey = (String) cacheOrder.keySet().iterator().next();
            removeFromCache(oldestKey);
            return true;
        }
    }
    
    return false;
}

/** 缓存条目类 */
static class CacheEntry {
    Drawable drawable;
    long createdTime;
    long lastAccessTime;
    int width;
    int height;
    String cacheKey;
    int accessCount;
    
    CacheEntry(Drawable d, String key, int w, int h) {
        this.drawable = d;
        this.cacheKey = key;
        this.width = w;
        this.height = h;
        this.createdTime = System.currentTimeMillis();
        this.lastAccessTime = this.createdTime;
        this.accessCount = 0;
    }
    
    void updateAccess() {
        this.lastAccessTime = System.currentTimeMillis();
        this.accessCount++;
    }
}

static ConcurrentHashMap imageCache = new ConcurrentHashMap();
static LinkedHashMap cacheOrder = new LinkedHashMap(10, 0.75f, true);
static Drawable globalCachedDrawable = null;
static String globalCachedParams = "";
private static final Object BG_LOCK = new Object();
private static final Object CACHE_LOCK = new Object();
private static volatile boolean isBgLoading = false;
private static volatile boolean isDialogShowing = false;
static WeakHashMap scaledViews = new WeakHashMap();
static final int MAX_CACHE_SIZE = 10;

static int currentTextColor = Color.WHITE;
static boolean currentIsDark = true;

String md5(String input) {
    if (input == null || input.isEmpty()) return "";
    try {
        MessageDigest md = MessageDigest.getInstance("MD5");
        byte[] bytes = md.digest(input.getBytes());
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    } catch (Exception e) {
        return input;
    }
}

Drawable getCachedDrawable(String cacheKey) {
    if (cacheKey == null || cacheKey.isEmpty()) return null;
    
    CacheEntry entry = (CacheEntry) imageCache.get(cacheKey);
    if (entry != null && entry.drawable != null) {
        cacheOrder.remove(cacheKey);
        cacheOrder.put(cacheKey, entry);
        entry.updateAccess();
        return entry.drawable;
    }
    return null;
}

void putToCache(Drawable drawable, String cacheKey, int width, int height) {
    if (drawable == null || cacheKey == null || cacheKey.isEmpty()) return;
    
    CacheEntry existing = (CacheEntry) imageCache.get(cacheKey);
    if (existing != null) {
        existing.updateAccess();
        cacheOrder.remove(cacheKey);
        cacheOrder.put(cacheKey, existing);
        return;
    }
    
    while (imageCache.size() >= MAX_CACHE_SIZE && !cacheOrder.isEmpty()) {
        String oldestKey = (String) cacheOrder.keySet().iterator().next();
        removeFromCache(oldestKey);
    }
    
    CacheEntry entry = new CacheEntry(drawable, cacheKey, width, height);
    imageCache.put(cacheKey, entry);
    cacheOrder.put(cacheKey, entry);
}

void removeFromCache(String cacheKey) {
    if (cacheKey == null) return;
    
    cacheOrder.remove(cacheKey);
    
    CacheEntry entry = (CacheEntry) imageCache.remove(cacheKey);
    if (entry != null && entry.drawable != null) {
        try {
            if (entry.drawable instanceof BitmapDrawable) {
                BitmapDrawable bd = (BitmapDrawable) entry.drawable;
                Bitmap bitmap = bd.getBitmap();
                if (bitmap != null && !bitmap.isRecycled()) {
                    bitmap.recycle();
                }
            }
        } catch (Exception e) {}
    }
}

void unloadBackgroundCache() {
    imageCache.clear();
    cacheOrder.clear();
    scaledViews.clear();
    globalCachedDrawable = null;
    globalCachedParams = "";
}

void forceUnloadAllCache() {
    unloadBackgroundCache();
}

// =============== 挂起设置读取辅助方法 ===============

String getSetting(String table, String key, String defaultValue) {
    if (pendingSettingsChanges != null && pendingSettingsChanges.containsKey(key)) {
        Object val = pendingSettingsChanges.get(key);
        return val != null ? val.toString() : defaultValue;
    }
    return getString(table, key, defaultValue);
}

boolean getSettingBoolean(String table, String key, boolean defaultValue) {
    if (pendingSettingsChanges != null && pendingSettingsChanges.containsKey(key)) {
        Object val = pendingSettingsChanges.get(key);
        if (val != null) {
            String strVal = val.toString();
            if ("true".equalsIgnoreCase(strVal)) return true;
            if ("false".equalsIgnoreCase(strVal)) return false;
        }
    }
    return getBoolean(table, key, defaultValue);
}

/**
 * 创建手绘风格的开关控件（48dp × 28dp）
 * @param ctx       Context（通常传入 Activity）
 * @param initVal   初始状态（true = 开，false = 关）
 * @return Object[] { View 开关控件, boolean[] 当前状态数组（长度1，可修改） }
 */
public Object[] createSwitchViewWithState(Context ctx, boolean initVal) {
    FrameLayout swContainer = new FrameLayout(ctx);
    int swW = dp(ctx, 48);
    int swH = dp(ctx, 28);
    FrameLayout.LayoutParams containerLp = new FrameLayout.LayoutParams(swW, swH);
    swContainer.setLayoutParams(containerLp);

    // 简单按下涟漪效果
    ColorStateList rippleColor = ColorStateList.valueOf(Color.parseColor("#33000000"));
    RippleDrawable ripple = new RippleDrawable(rippleColor, null, null);
    swContainer.setBackground(ripple);

    swContainer.setClickable(true);
    swContainer.setFocusable(true);

    // 轨道
    View track = new View(ctx);
    FrameLayout.LayoutParams trackLp = new FrameLayout.LayoutParams(-1, -1);
    track.setLayoutParams(trackLp);
    GradientDrawable trackBg = new GradientDrawable();
    trackBg.setCornerRadius(dp(ctx, 14));
    track.setBackground(trackBg);
    swContainer.addView(track);

    // 滑块
    View thumb = new View(ctx);
    int thumbSize = dp(ctx, 24);
    int margin = dp(ctx, 2);
    FrameLayout.LayoutParams thumbLp = new FrameLayout.LayoutParams(thumbSize, thumbSize);
    thumbLp.gravity = Gravity.CENTER_VERTICAL | Gravity.LEFT;
    thumbLp.setMargins(margin, 0, margin, 0);
    thumb.setLayoutParams(thumbLp);

    GradientDrawable thumbBg = new GradientDrawable();
    thumbBg.setColor(Color.WHITE);
    thumbBg.setCornerRadius(dp(ctx, 12));
    thumb.setBackground(thumbBg);
    swContainer.addView(thumb);

    final boolean[] state = new boolean[]{initVal};
    final View finalThumb = thumb;
    final GradientDrawable finalTrackBg = trackBg;

    final Runnable updateUI = new Runnable() {
        public void run() {
            boolean isOn = state[0];
            finalTrackBg.setColor(isOn ? Color.parseColor("#34C759") : Color.parseColor("#E5E5E5"));
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) finalThumb.getLayoutParams();
            lp.gravity = Gravity.CENTER_VERTICAL | (isOn ? Gravity.RIGHT : Gravity.LEFT);
            finalThumb.setLayoutParams(lp);
            finalThumb.invalidate();
            track.invalidate();
        }
    };

    updateUI.run();

    swContainer.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
            state[0] = !state[0];
            updateUI.run();
            traceLog("qzone_log", "自定义开关点击，新状态: " + state[0]);
        }
    });

    return new Object[]{swContainer, state};
}

boolean isEffectiveDarkMode(Activity activity) {
    String mode = getSetting("settings", "ui_theme_mode", "default");
    if ("default".equals(mode)) {
        return getSettingBoolean("settings", "黑白", false);
    }
    if ("dark".equals(mode)) return true;
    if ("light".equals(mode)) return false;
    boolean manualDark = getSettingBoolean("settings", "黑白", false);
    if (manualDark) return true;
    try {
        int uiMode = activity.getResources().getConfiguration().uiMode;
        return (uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
    } catch (Exception e) { return false; }
}

boolean isValidHexColor(String colorCode) {
    if (colorCode == null || colorCode.trim().isEmpty()) return false;
    return Pattern.matches("^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{8})$", colorCode.trim());
}

boolean isValidGradientString(String gradientStr) {
    if (gradientStr == null || gradientStr.trim().isEmpty()) {
        return false;
    }
    
    String cleanStr = gradientStr.trim();
    String[] colors = cleanStr.split(",");
    
    if (colors.length < 2) {
        return false;
    }
    
    for (String color : colors) {
        String trimmedColor = color.trim();
        if (trimmedColor.isEmpty()) {
            return false;
        }
        
        boolean isValid = false;
        
        if (trimmedColor.startsWith("#")) {
            if (trimmedColor.length() == 7 || trimmedColor.length() == 9) {
                isValid = Pattern.matches("^#[A-Fa-f0-9]{6}$", trimmedColor) || 
                          Pattern.matches("^#[A-Fa-f0-9]{8}$", trimmedColor);
            } else if (trimmedColor.length() == 4) {
                isValid = Pattern.matches("^#[A-Fa-f0-9]{3}$", trimmedColor);
            }
        }
        
        if (!isValid) {
            return false;
        }
    }
    
    return true;
}

Typeface getCustomTypeface(String typeName) {
    if ("serif".equals(typeName)) return Typeface.SERIF;
    if ("sans".equals(typeName)) return Typeface.SANS_SERIF;
    if ("monospace".equals(typeName)) return Typeface.MONOSPACE;
    if ("bold".equals(typeName)) return Typeface.DEFAULT_BOLD;
    return Typeface.DEFAULT;
}

void applyUiTheme(final Activity activity, final AlertDialog dialog) {
    if (dialog == null) return;
    
    final Window window = dialog.getWindow();
    if (window == null) return;
    
    applyDialogSize(activity, window);
    
    final View decorView = window.getDecorView();
    int dialogW = decorView.getWidth();
    int dialogH = decorView.getHeight();
    
    if (dialogW <= 0 || dialogH <= 0) {
        float density = activity.getResources().getDisplayMetrics().density;
        int screenWidth = activity.getResources().getDisplayMetrics().widthPixels;
        dialogW = Math.min((int) (300 * density), screenWidth - (int) (48 * density));
        dialogH = (int) (800 * density);
    }
    
    executeApplyTheme(activity, dialog, dialogW, dialogH);
}

void executeApplyTheme(final Activity activity, final AlertDialog dialog, final int dialogW, final int dialogH) {
    if (dialog == null || dialog.getWindow() == null) {
        return;
    }
    
    final Window window = dialog.getWindow();
    final boolean isDark = isEffectiveDarkMode(activity);
    currentIsDark = isDark;
    
    try {
        final String bgType = getSetting("settings", "ui_bg_type", "color");
        final String bgColor = getSetting("settings", isDark ? "ui_bg_color_dark" : "ui_bg_color_light", 
            isDark ? "#FF1E1E1E" : "#FFFFFFFF");
        final String bgGradient = getSetting("settings", isDark ? "ui_bg_gradient_dark" : "ui_bg_gradient_light", 
            isDark ? "#FF2C2C2C,#FF121212,#FF2C2C2C" : "#FFFFFFFF,#FFF5F5F5,#FFFFFFFF");
        final String textColorUser = getSetting("settings", isDark ? "ui_text_color_dark" : "ui_text_color_light", "");
        final String fontType = getSetting("settings", "ui_font_type", "default");
        final String imgPath = pluginPath + "/API/background.png";
        
        float fSize = 1.0f;
        try { fSize = Float.parseFloat(getSetting("settings", "ui_font_size", "1.0")); } catch(Exception e){}
        final float fontSizeScale = fSize;
        final Typeface tf = getCustomTypeface(fontType);
        
        int blurR = 0, alpha = 100;
        try { blurR = Integer.parseInt(getSetting("settings", "ui_img_blur", "0")); } catch(Exception e){}
        try { alpha = Integer.parseInt(getSetting("settings", "ui_img_alpha", isDark ? "180" : "100")); } catch(Exception e){}
        final int blurRadius = Math.max(0, Math.min(25, blurR));
        final int overlayAlpha = Math.max(0, Math.min(255, alpha));
        
        String rawBgColor = getSetting("settings", isDark ? "ui_bg_color_dark" : "ui_bg_color_light", 
            isDark ? "#FF1E1E1E" : "#FFFFFFFF");
        String validFallbackColor = isValidHexColor(rawBgColor) ? rawBgColor : (isDark ? "#FF1E1E1E" : "#FFFFFFFF");
        
        if ("gradient".equals(bgType) && isValidGradientString(bgGradient)) {
            applyGradientBackground(activity, window, bgGradient, validFallbackColor, isDark);
        } else {
            applyFallbackBg(activity, window, validFallbackColor, isDark);
        }
        
        if ("image".equals(bgType)) {
            applyFallbackBg(activity, window, isDark ? "#FF1E1E1E" : "#FFFFFFFF", isDark);
            
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                public void run() {
                    ThreadPool.execute(new Runnable() {
                        public void run() {
                            try {
                                final View decorView = window.getDecorView();
                                int actualW = decorView.getWidth();
                                int actualH = decorView.getHeight();
                                if (actualW <= 0 || actualH <= 0) {
                                    actualW = dialogW;
                                    actualH = dialogH;
                                }
                                
                                String baseKey = generateBaseCacheKey(imgPath, blurRadius, overlayAlpha, isDark);
                                Drawable cached = findSimilarCache(baseKey, actualW, actualH);
                                
                                if (cached != null) {
                                    applyDrawableWithTransition(activity, window, cached);
                                    return;
                                }
                                
                                File f = new File(imgPath);
                                if (!f.exists()) return;
                                
                                BitmapFactory.Options opts = new BitmapFactory.Options();
                                opts.inSampleSize = 2;
                                opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
                                
                                Bitmap origin = BitmapFactory.decodeFile(imgPath, opts);
                                if (origin == null) throw new Exception("解码失败");
                                
                                Bitmap scaled = centerCropBitmap(origin, actualW, actualH);
                                if (scaled == null) scaled = smartScaleBitmap(origin, actualW, actualH);
                                if (scaled == null) scaled = Bitmap.createScaledBitmap(origin, actualW, actualH, true);
                                
                                Bitmap finalBitmap = scaled;
                                if (blurRadius > 0 && scaled.getWidth() > 200) {
                                    Bitmap outBmp = Bitmap.createBitmap(scaled.getWidth(), scaled.getHeight(), Bitmap.Config.ARGB_8888);
                                    finalBitmap = blurBitmap(activity, scaled, outBmp, blurRadius);
                                }
                                
                                int maskColor = isDark ? Color.BLACK : Color.WHITE;
                                ColorDrawable mask = new ColorDrawable(Color.argb(overlayAlpha, 
                                    Color.red(maskColor), Color.green(maskColor), Color.blue(maskColor)));
                                BitmapDrawable bd = new BitmapDrawable(activity.getResources(), finalBitmap);
                                final LayerDrawable ld = new LayerDrawable(new Drawable[]{bd, mask});
                                
                                String cacheKey = generateCacheKey(imgPath, blurRadius, overlayAlpha, isDark, actualW, actualH);
                                putToCache(ld, cacheKey, actualW, actualH);
                                
                                applyDrawableWithTransition(activity, window, ld);
                                
                                if (origin != scaled && !origin.isRecycled()) {
                                    origin.recycle();
                                }
                                
                            } catch (Throwable e) {}
                        }
                    });
                }
            }, 100);
        }
        
        String rawBgColor2 = getSetting("settings", isDark ? "ui_bg_color_dark" : "ui_bg_color_light", 
            isDark ? "#FF1E1E1E" : "#FFFFFFFF");
        String validBgColor = isValidHexColor(rawBgColor2) ? rawBgColor2 : (isDark ? "#FF1E1E1E" : "#FFFFFFFF");
        if ("gradient".equals(bgType)) {
            boolean isValidGrad = isValidGradientString(bgGradient);
            if (isValidGrad) {
                applyGradientBackground(activity, window, bgGradient, validBgColor, isDark);
            } else {
                applyFallbackBg(activity, window, validBgColor, isDark);
            }
        } else {
            applyFallbackBg(activity, window, validBgColor, isDark);
        }
        
        final int calculatedTextColor;
        boolean isBgDark = isDark;
        if ("color".equals(bgType) && isValidHexColor(bgColor)) {
            isBgDark = isColorDark(Color.parseColor(bgColor.trim()));
        }
        
        if (isValidHexColor(textColorUser)) {
            calculatedTextColor = Color.parseColor(textColorUser);
        } else {
            calculatedTextColor = isBgDark ? Color.parseColor("#FFEFEFEF") : Color.parseColor("#FF333333");
        }
        currentTextColor = calculatedTextColor;
        
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            public void run() {
                updateViewStylesRecursively(window.getDecorView(), calculatedTextColor, tf, fontSizeScale);
            }
        });
        
    } catch (Throwable e) {
        try { e.printStackTrace(); } catch (Exception ex) {}
    }
}

void applyDrawableWithTransition(final Activity activity, final Window window, final Drawable newDrawable) {
    activity.runOnUiThread(new Runnable() {
        public void run() {
            try {
                View decorView = window.getDecorView();
                Drawable currentBg = decorView.getBackground();
                
                TransitionDrawable transitionDrawable = new TransitionDrawable(new Drawable[]{
                    currentBg != null ? currentBg : new ColorDrawable(Color.TRANSPARENT),
                    newDrawable
                });
                
                window.setBackgroundDrawable(transitionDrawable);
                transitionDrawable.startTransition(300);
                
                clearInnerBackgrounds(decorView);
                applyWindowRadius(activity, window);
                
            } catch (Throwable e) {
                window.setBackgroundDrawable(newDrawable);
            }
        }
    });
}

void applyImageBackgroundFast(final Activity activity, final Window window, 
                             final String imgPath, final int blurRadius, 
                             final int overlayAlpha, final boolean isDark,
                             final int dialogW, final int dialogH) {
    try {
        File f = new File(imgPath);
        boolean exists = f.exists();
        
        if (!exists) {
            applyFallbackBg(activity, window, isDark ? "#FF1E1E1E" : "#FFFFFFFF", isDark);
            return;
        }
        
        applyFallbackBg(activity, window, isDark ? "#FF1E1E1E" : "#FFFFFFFF", isDark);
        
        final int finalW = dialogW > 0 ? dialogW : 814;
        final int finalH = dialogH > 0 ? dialogH : 806;
        
        ThreadPool.execute(new Runnable() {
            public void run() {
                loadImageOptimized(activity, window, imgPath, blurRadius, overlayAlpha, isDark, finalW, finalH);
            }
        });
        
    } catch (Throwable e) {
        applyFallbackBg(activity, window, isDark ? "#FF1E1E1E" : "#FFFFFFFF", isDark);
    }
}

void loadImageOptimized(final Activity activity, final Window window, 
                       final String imgPath, final int blurRadius, 
                       final int overlayAlpha, final boolean isDark,
                       final int preWidth, final int preHeight) {
    
    int targetW = preWidth;
    int targetH = preHeight;
    
    try {
        String baseKey = generateBaseCacheKey(imgPath, blurRadius, overlayAlpha, isDark);
        Drawable cached = findSimilarCache(baseKey, targetW, targetH);
        if (cached != null) {
            applyDrawableWithoutTextRecalc(activity, window, cached);
            synchronized (BG_LOCK) { isBgLoading = false; }
            return;
        }
        
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = 2;
        opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
        opts.inJustDecodeBounds = false;
        
        Bitmap origin = BitmapFactory.decodeFile(imgPath, opts);
        if (origin == null) {
            throw new Exception("图片解码失败");
        }
        
        int sourceW = origin.getWidth();
        int sourceH = origin.getHeight();
        
        if (origin.getConfig() != Bitmap.Config.ARGB_8888) {
            Bitmap argb8888 = origin.copy(Bitmap.Config.ARGB_8888, false);
            if (origin != argb8888) {
                origin.recycle();
            }
            origin = argb8888;
        }
        
        Bitmap scaled = centerCropBitmap(origin, targetW, targetH);
        
        if (scaled == null) {
            scaled = smartScaleBitmap(origin, targetW, targetH);
        }
        if (scaled == null) {
            scaled = Bitmap.createScaledBitmap(origin, targetW, targetH, true);
        }
        
        if (scaled != null) {
            if (scaled.getConfig() != Bitmap.Config.ARGB_8888) {
                Bitmap argb8888 = scaled.copy(Bitmap.Config.ARGB_8888, false);
                if (scaled != origin) {
                    scaled.recycle();
                }
                scaled = argb8888;
            }
        }
        
        Bitmap finalBitmap = scaled;
        if (blurRadius > 0 && scaled.getWidth() > 200) {
            Bitmap outBmp = Bitmap.createBitmap(scaled.getWidth(), scaled.getHeight(), Bitmap.Config.ARGB_8888);
            finalBitmap = blurBitmap(activity, scaled, outBmp, blurRadius);
            if (outBmp != finalBitmap && scaled != outBmp && !scaled.isRecycled()) {
                scaled.recycle();
            }
        }
        
        int maskColor = isDark ? Color.BLACK : Color.WHITE;
        ColorDrawable mask = new ColorDrawable(Color.argb(overlayAlpha, 
            Color.red(maskColor), Color.green(maskColor), Color.blue(maskColor)));
        BitmapDrawable bd = new BitmapDrawable(activity.getResources(), finalBitmap);
        LayerDrawable ld = new LayerDrawable(new Drawable[]{bd, mask});
        
        String cacheKey = generateCacheKey(imgPath, blurRadius, overlayAlpha, isDark, targetW, targetH);
        putToCache(ld, cacheKey, targetW, targetH);
        
        applyDrawableWithoutTextRecalc(activity, window, ld);
        
        if (origin != scaled && !origin.isRecycled()) {
            origin.recycle();
        }
        
    } catch (Throwable e) {}
    finally {
        synchronized (BG_LOCK) {
            isBgLoading = false;
        }
    }
}

void applyDrawableWithoutTextRecalc(final Activity activity, final Window window, final Drawable drawable) {
    final View decorView = window != null ? window.getDecorView() : null;
    
    activity.runOnUiThread(new Runnable() {
        public void run() {
            try {
                if (window == null || drawable == null) {
                    return;
                }
                
                int w = decorView != null ? decorView.getWidth() : 0;
                int h = decorView != null ? decorView.getHeight() : 0;
                
                if (w > 0 && h > 0) {
                    drawable.setBounds(0, 0, w, h);
                }
                
                window.setBackgroundDrawable(drawable);
                
                clearInnerBackgrounds(decorView);
                
                applyWindowRadius(activity, window);
                
            } catch (Throwable e) {
                e.printStackTrace();
            }
        }
    });
}

void finalizeTextStyle(final Activity activity, final View decorView, final boolean isDark, final boolean forceDark) {
    activity.runOnUiThread(new Runnable() {
        public void run() {
            try {
                int textColor = forceDark ? Color.parseColor("#FFEFEFEF") : Color.parseColor("#FF333333");
                currentTextColor = textColor;
                currentIsDark = forceDark;
                
                Typeface tf = getCustomTypeface(getString("settings", "ui_font_type", "default"));
                float fSize = 1.0f;
                try { fSize = Float.parseFloat(getString("settings", "ui_font_size", "1.0")); } catch(Exception e){}
                final float fontSizeScale = fSize;
                updateViewStylesRecursively(decorView, textColor, tf, fontSizeScale);
            } catch (Exception e) {}
        }
    });
}

void clearInnerBackgrounds(View view) {
    if (view == null) return;
    
    try {
        if (view instanceof ViewGroup) {
            String clsName = view.getClass().getSimpleName();
            if (clsName.contains("Decor") || clsName.contains("Content") || clsName.contains("Dialog")) {
                Drawable bg = view.getBackground();
                if (bg == null || isDrawableTransparent(bg)) {
                    view.setBackground(null);
                }
            }
            
            ViewGroup vg = (ViewGroup) view;
            for (int i = 0; i < vg.getChildCount(); i++) {
                clearInnerBackgrounds(vg.getChildAt(i));
            }
        }
    } catch (Exception e) {}
}

void applyDialogSize(final Activity activity, final Window window) {
    try {
        float scale = 1.0f;
        try {
            String scaleStr = getSetting("settings", "ui_dialog_scale", "1.0");
            scale = Float.parseFloat(scaleStr);
        } catch (Exception e) {}
        
        float density = activity.getResources().getDisplayMetrics().density;
        
        int customWidth = -1;
        try {
            String widthStr = getSetting("settings", "ui_dialog_width", "");
            if (!widthStr.isEmpty()) {
                customWidth = (int) (Float.parseFloat(widthStr) * density);
            }
        } catch (Exception e) {}
        
        int dialogWidth;
        if (customWidth > 0) {
            dialogWidth = customWidth;
        } else {
            int maxWidth = (int) (260 * density);
            int screenWidth = activity.getResources().getDisplayMetrics().widthPixels;
            dialogWidth = (int) (Math.min(maxWidth, screenWidth - (int) (48 * density)) * scale);
        }
        
        int dialogHeight = ViewGroup.LayoutParams.WRAP_CONTENT;
        
        WindowManager.LayoutParams params = window.getAttributes();
        params.width = dialogWidth;
        params.height = dialogHeight;
        window.setAttributes(params);
        
    } catch (Exception e) {}
}

boolean isDrawableTransparent(Drawable drawable) {
    if (drawable == null) return true;
    if (drawable instanceof ColorDrawable) {
        return ((ColorDrawable) drawable).getAlpha() < 10;
    }
    return false;
}

void applyWindowRadius(final Activity activity, final Window window) {
    try {
        final View decor = window != null ? window.getDecorView() : null;
        final float radius = 16 * activity.getResources().getDisplayMetrics().density;
        if (decor != null) {
            if (android.os.Build.VERSION.SDK_INT >= 21) {
                decor.setClipToOutline(true);
                decor.setOutlineProvider(new ViewOutlineProvider() {
                    public void getOutline(View view, Outline outline) {
                        try {
                            outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), radius);
                        } catch (Exception e) {}
                    }
                });
            }
        }
    } catch (Exception e) {}
}

void applyGradientBackground(Activity activity, Window window, String gradientStr, String fallbackColor, boolean isDark) {
    try {
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(activity, 16));
        
        if (gradientStr != null && !gradientStr.trim().isEmpty()) {
            String[] colors = gradientStr.split(",");
            if (colors.length >= 2) {
                int[] colorsInt = new int[colors.length];
                boolean valid = true;
                for (int i = 0; i < colors.length; i++) {
                    try {
                        String colorStr = colors[i].trim();
                        if (!colorStr.startsWith("#")) {
                            colorStr = "#" + colorStr;
                        }
                        colorsInt[i] = Color.parseColor(colorStr);
                    } catch (Exception e) {
                        valid = false;
                        break;
                    }
                }
                if (valid) {
                    bg.setColors(colorsInt);
                    bg.setOrientation(GradientDrawable.Orientation.TL_BR);
                    applyDrawableToWindow(window, bg, activity, isDark);
                    return;
                }
            }
        }
        
        applyFallbackBg(activity, window, fallbackColor, isDark);
        
    } catch (Throwable e) {
        applyFallbackBg(activity, window, fallbackColor, isDark);
    }
}

void applyFallbackBg(Activity activity, Window window, String colorStr, boolean isDark) {
    try {
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(activity, 16));
        bg.setColor(Color.parseColor(colorStr));
        applyDrawableToWindow(window, bg, activity, isDark);
    } catch(Exception e) { 
        try {
            GradientDrawable bg = new GradientDrawable();
            bg.setCornerRadius(dp(activity, 16));
            bg.setColor(isDark ? Color.parseColor("#FF1E1E1E") : Color.WHITE);
            applyDrawableToWindow(window, bg, activity, isDark);
        } catch (Exception ex) {}
    }
}

void applyDrawableToWindow(Window window, Drawable drawable, Activity activity, boolean isDark) {
    try {
        window.setBackgroundDrawable(drawable);
        applyWindowRadius(activity, window);
    } catch(Throwable e) {
        try {
            window.setBackgroundColor(isDark ? Color.parseColor("#FF1E1E1E") : Color.WHITE);
        } catch (Exception ex) {
            window.setBackgroundColor(Color.WHITE);
        }
    }
}

void updateViewStylesRecursively(View view, int textColor, Typeface tf, float fontSizeScale) {
    if (view == null) return;
    
    try {
        if (view instanceof TextView) {
            TextView tv = (TextView) view;
            
            String className = tv.getClass().getName();
            if (className.contains("Search") || className.contains("EditText") || 
                className.contains("AutoComplete") || className.contains("MultiAutoComplete")) {
                return;
            }
            
            if (tv.getId() == android.R.id.title || tv.getId() == android.R.id.alertTitle ||
                tv.getId() == android.R.id.text1 || tv.getId() == android.R.id.text2) {
                return;
            }
            
            if (tv.getParent() instanceof CheckBox) {
                return;
            }
            
            tv.setTextColor(textColor);
            
            if (fontSizeScale != 1.0f) {
                float originalSize = tv.getTextSize();
                tv.setTextSize(TypedValue.COMPLEX_UNIT_PX, originalSize * fontSizeScale);
            }
            
            if (tf != null) {
                int style = tv.getTypeface() != null ? tv.getTypeface().getStyle() : Typeface.NORMAL;
                tv.setTypeface(tf, style);
            }
            
            if (textColor == Color.parseColor("#FFEFEFEF")) {
                tv.setHintTextColor(Color.argb(100, 239, 239, 239));
            } else if (textColor == Color.parseColor("#FF333333")) {
                tv.setHintTextColor(Color.argb(100, 51, 51, 51));
            }
        }
        
        if (view instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) view;
            String className = vg.getClass().getName();
            if (!className.contains("Search") && !className.contains("AutoComplete")) {
                for (int i = 0; i < vg.getChildCount(); i++) {
                    updateViewStylesRecursively(vg.getChildAt(i), textColor, tf, fontSizeScale);
                }
            }
        }
        
    } catch (Exception e) {}
}

// =============== 设置界面UI ===============
interface OnChoiceSelected {
    void onSelect(String val);
}

// =============== 回调接口定义 ===============

/**
 * 颜色选择回调接口
 */
interface OnColorPickedListener {
    /**
     * 当用户选择颜色时回调
     * @param color 选中的颜色值
     */
    void onColorPicked(int color);
}

/**
 * 颜色变化回调接口
 */
interface OnColorChangedListener {
    /**
     * 当颜色值变化时回调
     * @param color 新的颜色值
     */
    void onColorChanged(int color);
}

// =============== 工具方法 ===============

/**
 * 将颜色值转换为十六进制字符串
 * @param color 颜色值
 * @return 十六进制字符串
 */
String colorToHex(int color) {
    try {
        return String.format("#%08X", color);
    } catch (Exception e) {
        return "#FF000000";
    }
}

/**
 * 将文本复制到剪贴板
 * @param activity 当前 Activity
 * @param text 要复制的文本
 */
void copyToClipboard(Activity activity, String text) {
    try {
        ClipboardManager clipboard = (ClipboardManager) activity.getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = ClipData.newPlainText("color", text);
        clipboard.setPrimaryClip(clip);
    } catch (Exception e) {}
}

/**
 * 创建圆角矩形背景
 * @param color 背景颜色
 * @param radius 圆角半径
 * @return GradientDrawable 对象
 */
GradientDrawable createRoundRectDrawable(int color, float radius) {
    try {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(color);
        gd.setCornerRadius(radius);
        return gd;
    } catch (Exception e) {
        return new GradientDrawable();
    }
}

/**
 * 创建可点击背景
 * @return StateListDrawable 对象
 */
android.graphics.drawable.StateListDrawable createSelectableBackground() {
    android.graphics.drawable.StateListDrawable drawable = new android.graphics.drawable.StateListDrawable();
    drawable.addState(new int[]{android.R.attr.state_pressed}, new ColorDrawable(Color.parseColor("#1A000000")));
    drawable.addState(new int[]{}, new ColorDrawable(Color.TRANSPARENT));
    return drawable;
}

// =============== 收藏夹数据管理 ===============

/**
 * 从存储中加载收藏的颜色列表
 * @param activity 当前 Activity
 * @return 包含颜色字符串的 ArrayList
 */
ArrayList loadFavoriteColors(Activity activity) {
    ArrayList list = new ArrayList();
    try {
        String favStr = getString("settings", "color_favorites", "");
        if (favStr != null && !favStr.isEmpty()) {
            String[] colors = favStr.split(",");
            for (int i = 0; i < colors.length; i++) {
                String c = colors[i].trim();
                if (!c.isEmpty() && !list.contains(c)) {
                    list.add(c);
                }
            }
        }
    } catch (Exception e) {}
    return list;
}

/**
 * 保存收藏的颜色列表到存储
 * @param activity 当前 Activity
 * @param favorites 包含颜色字符串的 ArrayList
 */
void saveFavoriteColors(Activity activity, ArrayList favorites) {
    try {
        StringBuilder sb = new StringBuilder();
        int count = Math.min(favorites.size(), 30);
        for (int i = 0; i < count; i++) {
            if (i > 0) sb.append(",");
            sb.append(favorites.get(i).toString());
        }
        putString("settings", "color_favorites", sb.toString());
    } catch (Exception e) {}
}

// =============== iOS 风格 SeekBar 包装器 ===============

/**
 * iOS 风格的 SeekBar 包装器类
 */
class IOSSeekBar extends LinearLayout {
    private SeekBar seekBar; // 滑块控件
    private TextView valueLabel; // 数值显示标签
    private OnColorChangedListener listener; // 颜色变化监听器
    private int index; // 索引

    /**
     * 构造函数
     * @param context 上下文
     * @param label 标签文本
     * @param color 主色调
     * @param initialValue 初始值
     * @param max 最大值
     */
    public IOSSeekBar(Context context, String label, int color, int initialValue, int max) {
        super(context);
        setOrientation(LinearLayout.HORIZONTAL);
        setGravity(Gravity.CENTER_VERTICAL);
        setPadding(0, dp(context, 8), 0, dp(context, 8));
        
        TextView labelView = new TextView(context);
        labelView.setText(label);
        labelView.setTextSize(16);
        labelView.setTextColor(color);
        labelView.setTypeface(null, Typeface.BOLD);
        labelView.setLayoutParams(new LinearLayout.LayoutParams(dp(context, 32), -2));
        addView(labelView);
        
        LinearLayout seekContainer = new LinearLayout(context);
        seekContainer.setOrientation(LinearLayout.VERTICAL);
        seekContainer.setGravity(Gravity.CENTER_VERTICAL);
        seekContainer.setPadding(dp(context, 8), 0, dp(context, 8), 0);
        seekContainer.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
        
        seekBar = new SeekBar(context);
        seekBar.setMax(max);
        seekBar.setProgress(initialValue);
        seekBar.setPadding(dp(context, 4), dp(context, 8), dp(context, 4), dp(context, 8));
        
        try {
            if (Build.VERSION.SDK_INT >= 16) {
                seekBar.getProgressDrawable().setColorFilter(color, android.graphics.PorterDuff.Mode.SRC_IN);
                seekBar.getThumb().setColorFilter(Color.WHITE, android.graphics.PorterDuff.Mode.SRC_IN);
            }
        } catch (Exception e) {}
        
        seekContainer.addView(seekBar);
        addView(seekContainer);
        
        valueLabel = new TextView(context);
        valueLabel.setText(String.valueOf(initialValue));
        valueLabel.setTextSize(14);
        valueLabel.setTextColor(Color.parseColor("#FF666666"));
        valueLabel.setTypeface(Typeface.MONOSPACE);
        valueLabel.setLayoutParams(new LinearLayout.LayoutParams(dp(context, 40), -2));
        valueLabel.setGravity(Gravity.RIGHT);
        addView(valueLabel);
        
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                valueLabel.setText(String.valueOf(progress));
                if (listener != null) {
                    listener.onColorChanged(progress);
                }
            }
            public void onStartTrackingTouch(SeekBar seekBar) {}
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });
    }
    
    /** 获取当前进度值 */
    public int getProgress() {
        return seekBar.getProgress();
    }
    
    /** 设置颜色变化监听器 */
    public void setOnColorChangedListener(OnColorChangedListener l) {
        listener = l;
    }
}

// =============== HSV 选择器视图 ===============

/**
 * HSV (色相, 饱和度, 亮度) 选择器视图类
 */
class HsvPickerView extends View {
    private Paint huePaint; // 色相条画笔
    private Paint svPaint; // SV 平面画笔
    private Paint cursorPaint; // 光标画笔
    private Paint borderPaint; // 边框画笔
    
    private int currentHue = 0; // 当前色相
    private float currentSat = 1.0f; // 当前饱和度
    private float currentVal = 1.0f; // 当前明度
    
    private OnColorChangedListener listener; // 颜色变化监听器
    private boolean trackingSV = false; // 是否正在跟踪 SV 操作
    private boolean trackingHue = false; // 是否正在跟踪 Hue 操作
    
    private int svLeft, svTop, svRight, svBottom; // SV 区域边界
    private int hueLeft, hueTop, hueRight, hueBottom; // Hue 区域边界
    private int hueWidth = 40; // 色相条宽度
    
    private boolean isSizeValid = false; // 尺寸是否有效
    private Shader hueShader; // 色相渐变着色器

    /**
     * 构造函数
     * @param context 上下文
     * @param initialColor 初始颜色
     */
    public HsvPickerView(Context context, int initialColor) {
        super(context);
        setWillNotDraw(false);
        
        huePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        svPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        cursorPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        
        cursorPaint.setStyle(Paint.Style.STROKE);
        cursorPaint.setStrokeWidth(4);
        cursorPaint.setColor(Color.WHITE);
        try {
            cursorPaint.setShadowLayer(2, 0, 0, Color.BLACK);
        } catch (Exception e) {}
        
        borderPaint.setColor(Color.parseColor("#40FFFFFF"));
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(1);
        
        setColor(initialColor);
    }
    
    /** 设置当前颜色 */
    public void setColor(int color) {
        try {
            float[] hsv = new float[3];
            Color.colorToHSV(color, hsv);
            currentHue = (int) hsv[0];
            currentSat = hsv[1];
            currentVal = hsv[2];
            invalidate();
        } catch (Exception e) {}
    }
    
    /** 设置颜色变化监听器 */
    public void setOnColorChangedListener(OnColorChangedListener l) {
        listener = l;
    }
	protected void onSizeChanged(int w, int h, int oldw, int oldh) {
	    super.onSizeChanged(w, h, oldw, oldh);
	    
	    try {
	        // 安全检查：防止宽高为0
	        if (w <= 0 || h <= 0) {
	            isSizeValid = false;
	            return;
	        }
	        
	        int padding = dp(getContext(), 8);
	        int gap = dp(getContext(), 16);
	        
	        hueWidth = dp(getContext(), 36);
	        hueLeft = w - padding - hueWidth;
	        hueTop = padding;
	        hueRight = w - padding;
	        hueBottom = h - padding;
	        
	        if (hueRight <= hueLeft || hueBottom <= hueTop || hueWidth <= 0) {
	            isSizeValid = false;
	            return;
	        }
	        
	        svLeft = padding;
	        svTop = padding;
	        svRight = hueLeft - gap;
	        svBottom = h - padding;
	        
	        if (svRight <= svLeft || svBottom <= svTop) {
	            isSizeValid = false;
	            return;
	        }
	        
	        // BeanShell防御性编程：显式声明int[]数组，使用Color.parseColor(#AARRGGBB)
	        int[] hueColors = new int[7];
	        hueColors[0] = Color.parseColor("#FFFF0000"); // 红
	        hueColors[1] = Color.parseColor("#FFFFFF00"); // 黄
	        hueColors[2] = Color.parseColor("#FF00FF00"); // 绿
	        hueColors[3] = Color.parseColor("#FF00FFFF"); // 青
	        hueColors[4] = Color.parseColor("#FF0000FF"); // 蓝
	        hueColors[5] = Color.parseColor("#FFFF00FF"); // 洋红
	        hueColors[6] = Color.parseColor("#FFFF0000"); // 红（闭合）
	        
	        // 关键：显式声明float[]变量，禁止直接传null字面量（解释器无法推断类型）
	        float[] positions = null;
	        
	        // 关键：显式float转换，防止解释器将整数解析为int导致签名不匹配
	        float x0 = 0.0f;
	        float y0 = (float)hueTop;
	        float x1 = 0.0f;
	        float y1 = (float)hueBottom;
	        
	        // 使用Object接收构造结果，绕过解释器重载解析歧义
	        Object shaderObj = new LinearGradient(
	            x0, 
	            y0, 
	            x1, 
	            y1, 
	            hueColors,      // 显式int[]类型变量
	            positions,      // 显式float[]类型变量（非null字面量）
	            Shader.TileMode.CLAMP
	        );
	        
	        hueShader = (android.graphics.Shader)shaderObj;
	        huePaint.setShader(hueShader);
	        
	        isSizeValid = true;
	        traceLog("hsv_picker", "[onSizeChanged] 渐变创建成功");
	        
	    } catch (Throwable e) { // 必须用Throwable捕获一切（宪章2.3.2）
	        traceLog("hsv_picker", "[onSizeChanged] 错误: " + e.getMessage());
	        isSizeValid = false;
	    }
	}
	
        protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        
        if (!isSizeValid) return;
        
        try {
            // 绘制SV平面背景 (白色到当前色相)
            int[] svColors = new int[]{
                Color.WHITE,
                Color.HSVToColor(new float[]{currentHue, 1.0f, 1.0f})
            };
            Shader svShader = new LinearGradient(svLeft, svTop, svRight, svTop, svColors, null, Shader.TileMode.CLAMP);
            svPaint.setShader(svShader);
            canvas.drawRect(svLeft, svTop, svRight, svBottom, svPaint);
            
            // 叠加明度渐变 (从上到下：透明到黑色)
            Shader valShader = new LinearGradient(svLeft, svTop, svLeft, svBottom, 
                Color.TRANSPARENT, Color.BLACK, Shader.TileMode.CLAMP);
            svPaint.setShader(valShader);
            canvas.drawRect(svLeft, svTop, svRight, svBottom, svPaint);
            
            // 绘制SV平面边框
            canvas.drawRect(svLeft, svTop, svRight, svBottom, borderPaint);
            
            // 绘制色相条 (右侧)
            canvas.drawRect(hueLeft, hueTop, hueRight, hueBottom, huePaint);
            canvas.drawRect(hueLeft, hueTop, hueRight, hueBottom, borderPaint);
            
            // 绘制SV选择器光标 (空心圆+中心点)
            float svX = svLeft + (svRight - svLeft) * currentSat;
            float svY = svTop + (svBottom - svTop) * (1 - currentVal);
            
            // 确保光标在区域内
            svX = Math.max(svLeft + 10, Math.min(svRight - 10, svX));
            svY = Math.max(svTop + 10, Math.min(svBottom - 10, svY));
            
            // 外圈 (黑色描边)
            cursorPaint.setColor(Color.BLACK);
            cursorPaint.setStrokeWidth(3);
            canvas.drawCircle(svX, svY, 10, cursorPaint);
            // 内圈 (白色)
            cursorPaint.setColor(Color.WHITE);
            cursorPaint.setStrokeWidth(2);
            canvas.drawCircle(svX, svY, 8, cursorPaint);
            
            // 绘制色相选择器 (右侧横线)
            float hueY = hueTop + (hueBottom - hueTop) * (currentHue / 360.0f);
            hueY = Math.max(hueTop + 5, Math.min(hueBottom - 5, hueY));
            
            Paint hueCursorPaint = new Paint();
            hueCursorPaint.setColor(Color.WHITE);
            hueCursorPaint.setStrokeWidth(4);
            try {
                hueCursorPaint.setShadowLayer(3, 0, 0, Color.BLACK);
            } catch (Exception e) {}
            canvas.drawLine(hueLeft - 6, hueY, hueRight + 6, hueY, hueCursorPaint);
            
        } catch (Exception e) {}
    }
        public boolean onTouchEvent(MotionEvent event) {
        if (!isSizeValid) return false;
        
        try {
            float x = event.getX();
            float y = event.getY();
            
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    if (x >= svLeft && x <= svRight && y >= svTop && y <= svBottom) {
                        trackingSV = true;
                        updateSV(x, y);
                        return true;
                    } else if (x >= hueLeft && x <= hueRight && y >= hueTop && y <= hueBottom) {
                        trackingHue = true;
                        updateHue(y);
                        return true;
                    }
                    break;
                case MotionEvent.ACTION_MOVE:
                    if (trackingSV) {
                        updateSV(x, y);
                        return true;
                    } else if (trackingHue) {
                        updateHue(y);
                        return true;
                    }
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    trackingSV = false;
                    trackingHue = false;
                    break;
            }
        } catch (Exception e) {
            trackingSV = false;
            trackingHue = false;
        }
        return super.onTouchEvent(event);
    }
    
    /** 更新饱和度和明度 */
    private void updateSV(float x, float y) {
        try {
            currentSat = Math.max(0, Math.min(1, (x - svLeft) / (svRight - svLeft)));
            currentVal = Math.max(0, Math.min(1, 1 - (y - svTop) / (svBottom - svTop)));
            if (listener != null) {
                listener.onColorChanged(Color.HSVToColor(new float[]{currentHue, currentSat, currentVal}));
            }
            invalidate();
        } catch (Exception e) {}
    }
    
    /** 更新色相 */
    private void updateHue(float y) {
        try {
            currentHue = (int) (Math.max(0, Math.min(1, (y - hueTop) / (hueBottom - hueTop))) * 360);
            if (listener != null) {
                listener.onColorChanged(Color.HSVToColor(new float[]{currentHue, currentSat, currentVal}));
            }
            invalidate();
        } catch (Exception e) {}
    }
}

// =============== 色轮视图 ===============

/**
 * 色轮视图类
 */
class ColorWheelView extends View {
    private Paint wheelPaint; // 色轮画笔
    private Paint centerPaint; // 中心画笔
    private Paint cursorPaint; // 光标画笔
    private int centerX, centerY, radius; // 圆心坐标和半径
    private float cursorX, cursorY; // 光标坐标
    private int currentHue = 0; // 当前色相
    private float currentSat = 1.0f; // 当前饱和度
    private OnColorChangedListener listener; // 颜色变化监听器
    private Bitmap cacheBitmap; // 缓存位图
    private boolean isSizeValid = false; // 尺寸是否有效
    
    /**
     * 构造函数
     * @param context 上下文
     * @param initialColor 初始颜色
     */
    public ColorWheelView(Context context, int initialColor) {
        super(context);
        setWillNotDraw(false);
        
        wheelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        centerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        cursorPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        cursorPaint.setStyle(Paint.Style.STROKE);
        cursorPaint.setStrokeWidth(3);
        cursorPaint.setColor(Color.WHITE);
        try {
            cursorPaint.setShadowLayer(2, 0, 0, Color.BLACK);
        } catch (Exception e) {}
        
        setColor(initialColor);
    }
    
    /** 设置当前颜色 */
    public void setColor(int color) {
        try {
            float[] hsv = new float[3];
            Color.colorToHSV(color, hsv);
            currentHue = (int) hsv[0];
            currentSat = hsv[1];
            updateCursorPosition();
            invalidate();
        } catch (Exception e) {}
    }
    
    /** 设置颜色变化监听器 */
    public void setOnColorChangedListener(OnColorChangedListener l) {
        listener = l;
    }
        protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        
        // 安全检查：防止宽高为0
        if (w <= 0 || h <= 0) {
            isSizeValid = false;
            return;
        }
        
        centerX = w / 2;
        centerY = h / 2;
        radius = Math.min(w, h) / 2 - dp(getContext(), 16);
        
        // 安全检查：半径必须大于0才能创建位图
        if (radius <= 0) {
            isSizeValid = false;
            return;
        }
        
        updateCursorPosition();
        isSizeValid = true;
        
        // 预渲染色轮背景
        try {
            if (cacheBitmap != null && !cacheBitmap.isRecycled()) {
                cacheBitmap.recycle();
            }
            cacheBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            Canvas cacheCanvas = new Canvas(cacheBitmap);
            
            // 绘制色轮 (扫描渐变)
            Shader shader = new SweepGradient(centerX, centerY, 
                new int[]{Color.RED, Color.YELLOW, Color.GREEN, Color.CYAN, Color.BLUE, Color.MAGENTA, Color.RED},
                null);
            wheelPaint.setShader(shader);
            cacheCanvas.drawCircle(centerX, centerY, radius, wheelPaint);
            
            // 叠加饱和度渐变 (从中心白色到边缘透明)
            Shader satShader = new RadialGradient(centerX, centerY, radius, 
                Color.WHITE, Color.TRANSPARENT, Shader.TileMode.CLAMP);
            centerPaint.setShader(satShader);
            cacheCanvas.drawCircle(centerX, centerY, radius, centerPaint);
            
        } catch (Exception e) {
            // 如果创建失败，清理资源
            if (cacheBitmap != null && !cacheBitmap.isRecycled()) {
                cacheBitmap.recycle();
            }
            cacheBitmap = null;
        }
    }
    
    /** 更新光标位置 */
    private void updateCursorPosition() {
        try {
            float angle = (float) Math.toRadians(currentHue);
            float r = currentSat * radius;
            cursorX = centerX + (float) Math.cos(angle) * r;
            cursorY = centerY + (float) Math.sin(angle) * r;
        } catch (Exception e) {}
    }
        protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        
        if (!isSizeValid) return;
        
        try {
            // 绘制缓存的色轮
            if (cacheBitmap != null && !cacheBitmap.isRecycled()) {
                canvas.drawBitmap(cacheBitmap, 0, 0, null);
            }
            
            // 确保光标在有效范围内
            float dx = cursorX - centerX;
            float dy = cursorY - centerY;
            float dist = (float) Math.sqrt(dx * dx + dy * dy);
            if (dist > radius) {
                dx = dx / dist * radius;
                dy = dy / dist * radius;
                cursorX = centerX + dx;
                cursorY = centerY + dy;
            }
            
            // 绘制光标 (双圈)
            Paint shadowPaint = new Paint();
            shadowPaint.setColor(Color.BLACK);
            shadowPaint.setStyle(Paint.Style.STROKE);
            shadowPaint.setStrokeWidth(4);
            canvas.drawCircle(cursorX, cursorY, 10, shadowPaint);
            
            cursorPaint.setColor(Color.WHITE);
            cursorPaint.setStrokeWidth(2);
            canvas.drawCircle(cursorX, cursorY, 8, cursorPaint);
            
        } catch (Exception e) {}
    }
        public boolean onTouchEvent(MotionEvent event) {
        if (!isSizeValid) return false;
        
        try {
            float x = event.getX();
            float y = event.getY();
            
            float dx = x - centerX;
            float dy = y - centerY;
            float dist = (float) Math.sqrt(dx * dx + dy * dy);
            
            if (dist > radius) {
                dx = dx / dist * radius;
                dy = dy / dist * radius;
                dist = radius;
            }
            
            cursorX = centerX + dx;
            cursorY = centerY + dy;
            
            currentSat = dist / radius;
            currentHue = (int) Math.toDegrees(Math.atan2(dy, dx));
            if (currentHue < 0) currentHue += 360;
            
            if (listener != null) {
                listener.onColorChanged(Color.HSVToColor(new float[]{currentHue, currentSat, 1.0f}));
            }
            
            invalidate();
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}

// =============== 颜色条视图 ===============

/**
 * 颜色条视图 (垂直，右侧，修复版)
 */
class ColorBarView extends View {
    private Paint paint; // 主画笔
    private Paint cursorPaint; // 光标画笔
    private Paint borderPaint; // 边框画笔
    private int currentColor; // 当前颜色
    private int[] colors; // 颜色数组
    private OnColorChangedListener listener; // 颜色变化监听器
    private int barLeft, barTop, barRight, barBottom; // 条形边界
    private boolean isSizeValid = false; // 尺寸是否有效
    
    /**
     * 构造函数
     * @param context 上下文
     * @param initialColor 初始颜色
     */
    public ColorBarView(Context context, int initialColor) {
        super(context);
        setWillNotDraw(false);
        
        paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        cursorPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        
        cursorPaint.setStyle(Paint.Style.STROKE);
        cursorPaint.setStrokeWidth(4);
        cursorPaint.setColor(Color.WHITE);
        try {
            cursorPaint.setShadowLayer(3, 0, 0, Color.BLACK);
        } catch (Exception e) {}
        
        borderPaint.setColor(Color.parseColor("#40FFFFFF"));
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(1);
        
        colors = new int[]{
            Color.parseColor("#FFFF0000"),
            Color.parseColor("#FFFFFF00"),
            Color.parseColor("#FF00FF00"),
            Color.parseColor("#FF00FFFF"),
            Color.parseColor("#FF0000FF"),
            Color.parseColor("#FFFF00FF"),
            Color.parseColor("#FFFF0000")
        };
        
        setColor(initialColor);
    }
    
    /** 设置当前颜色 */
    public void setColor(int color) {
        currentColor = color;
        invalidate();
    }
    
    /** 设置颜色变化监听器 */
    public void setOnColorChangedListener(OnColorChangedListener l) {
        listener = l;
    }
        protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        
        // 安全检查：防止宽高为0
        if (w <= 0 || h <= 0) {
            isSizeValid = false;
            return;
        }
        
        int padding = dp(getContext(), 8);
        barLeft = padding;
        barTop = padding;
        barRight = w - padding;
        barBottom = h - padding;
        
        // 安全检查：防止 RectF 坐标无效
        if (barLeft >= barRight || barTop >= barBottom) {
            isSizeValid = false;
            return;
        }
        
        isSizeValid = true;
    }
        protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        
        if (!isSizeValid) return;
        
        try {
            // 创建Shader (仅在尺寸有效时)
            Shader shader = new LinearGradient(barLeft, barTop, barLeft, barBottom, colors, null, Shader.TileMode.CLAMP);
            paint.setShader(shader);
            
            RectF rect = new RectF(barLeft, barTop, barRight, barBottom);
            canvas.drawRoundRect(rect, 8, 8, paint);
            canvas.drawRoundRect(rect, 8, 8, borderPaint); // 绘制边框
            
            // 绘制光标
            float[] hsv = new float[3];
            Color.colorToHSV(currentColor, hsv);
            float y = barTop + (barBottom - barTop) * (hsv[0] / 360.0f);
            y = Math.max(barTop + 2, Math.min(barBottom - 2, y));
            
            canvas.drawLine(barLeft - 4, y, barRight + 4, y, cursorPaint);
            
        } catch (Exception e) {}
    }
        public boolean onTouchEvent(MotionEvent event) {
        if (!isSizeValid) return false;
        
        try {
            float y = event.getY();
            
            if (y < barTop) y = barTop;
            if (y > barBottom) y = barBottom;
            
            float hue = (y - barTop) / (barBottom - barTop) * 360;
            currentColor = Color.HSVToColor(new float[]{hue, 1.0f, 1.0f});
            
            if (listener != null) {
                listener.onColorChanged(currentColor);
            }
            
            invalidate();
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}

// =============== 放大镜视图 ===============

/**
 * 放大镜视图 (修复版)
 */
class MagnifierView extends View {
    private Paint paint; // 主画笔
    private Paint borderPaint; // 边框画笔
    private Bitmap magnifiedBitmap; // 放大后的位图
    
    /**
     * 构造函数
     * @param context 上下文
     */
    public MagnifierView(Context context) {
        super(context);
        paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setFilterBitmap(true);
        
        borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(4);
        borderPaint.setColor(Color.WHITE);
    }
    
    /**
     * 更新放大镜内容
     * @param source 源位图
     * @param srcX 源X坐标
     * @param srcY 源Y坐标
     * @param currentColor 当前颜色
     */
    public void update(Bitmap source, int srcX, int srcY, int currentColor) {
        try {
            int size = 30; // 放大尺寸
            int scale = 4; // 缩放倍数
            
            // 安全检查：防止 source 为 null
            if (source == null || source.isRecycled() || source.getWidth() <= 0 || source.getHeight() <= 0) {
                return;
            }
            
            if (magnifiedBitmap != null && !magnifiedBitmap.isRecycled()) {
                magnifiedBitmap.recycle();
            }
            
            // 确保尺寸有效
            if (size <= 0 || scale <= 0) return;
            
            magnifiedBitmap = Bitmap.createBitmap(size * 2, size * 2, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(magnifiedBitmap);
            
            Rect srcRect = new Rect(
                Math.max(0, srcX - size),
                Math.max(0, srcY - size),
                Math.min(source.getWidth(), srcX + size),
                Math.min(source.getHeight(), srcY + size)
            );
            
            // 确保源矩形有效
            if (srcRect.width() <= 0 || srcRect.height() <= 0) {
                return;
            }
            
            canvas.save();
            canvas.scale(scale, scale);
            canvas.drawBitmap(source, srcRect, new RectF(0, 0, size * 2, size * 2), paint);
            canvas.restore();
            
            Paint crossPaint = new Paint();
            crossPaint.setColor(Color.WHITE);
            crossPaint.setStrokeWidth(2);
            int center = size * scale;
            canvas.drawLine(center, 0, center, size * 2 * scale, crossPaint);
            canvas.drawLine(0, center, size * 2 * scale, center, crossPaint);
            
            invalidate();
        } catch (Exception e) {}
    }
        protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        try {
            if (magnifiedBitmap != null && !magnifiedBitmap.isRecycled()) {
                int w = getWidth();
                int h = getHeight();
                if (w <= 0 || h <= 0) return;
                
                float radius = Math.min(w, h) / 2;
                
                canvas.save();
                Path path = new Path();
                path.addCircle(w/2, h/2, radius, Path.Direction.CCW);
                canvas.clipPath(path);
                
                canvas.drawBitmap(magnifiedBitmap, null, new RectF(0, 0, w, h), paint);
                canvas.restore();
                
                canvas.drawCircle(w/2, h/2, radius, borderPaint);
            }
        } catch (Exception e) {}
    }
}

// =============== 模式内容创建 ===============

/**
 * 创建 RGB 调色视图
 * @param activity 当前 Activity
 * @param initialColor 初始颜色
 * @param listener 颜色变化监听器
 * @return 创建的视图
 */
View createRgbView(Activity activity, int initialColor, final OnColorChangedListener listener) {
    LinearLayout layout = new LinearLayout(activity);
    layout.setOrientation(LinearLayout.VERTICAL);
    layout.setPadding(dp(activity, 16), dp(activity, 24), dp(activity, 16), dp(activity, 24));
    layout.setGravity(Gravity.CENTER_VERTICAL);
    
    final int[] rgb = {Color.red(initialColor), Color.green(initialColor), Color.blue(initialColor)};
    
    // R
    final IOSSeekBar redBar = new IOSSeekBar(activity, "R", Color.parseColor("#FFFF3B30"), rgb[0], 255);
    redBar.setOnColorChangedListener(new OnColorChangedListener() {
        public void onColorChanged(int progress) {
            rgb[0] = progress;
            if (listener != null) listener.onColorChanged(Color.rgb(rgb[0], rgb[1], rgb[2]));
        }
    });
    layout.addView(redBar);
    
    // G
    final IOSSeekBar greenBar = new IOSSeekBar(activity, "G", Color.parseColor("#FF34C759"), rgb[1], 255);
    greenBar.setOnColorChangedListener(new OnColorChangedListener() {
        public void onColorChanged(int progress) {
            rgb[1] = progress;
            if (listener != null) listener.onColorChanged(Color.rgb(rgb[0], rgb[1], rgb[2]));
        }
    });
    layout.addView(greenBar);
    
    // B
    final IOSSeekBar blueBar = new IOSSeekBar(activity, "B", Color.parseColor("#FF007AFF"), rgb[2], 255);
    blueBar.setOnColorChangedListener(new OnColorChangedListener() {
        public void onColorChanged(int progress) {
            rgb[2] = progress;
            if (listener != null) listener.onColorChanged(Color.rgb(rgb[0], rgb[1], rgb[2]));
        }
    });
    layout.addView(blueBar);
    
    return layout;
}

/**
 * 创建 HSV 调色视图
 * @param activity 当前 Activity
 * @param initialColor 初始颜色
 * @param listener 颜色变化监听器
 * @return 创建的视图
 */
View createHsvView(Activity activity, int initialColor, final OnColorChangedListener listener) {
    FrameLayout layout = new FrameLayout(activity);
    layout.setPadding(dp(activity, 8), dp(activity, 8), dp(activity, 8), dp(activity, 8));
    
    HsvPickerView hsvView = new HsvPickerView(activity, initialColor);
    hsvView.setOnColorChangedListener(listener);
    layout.addView(hsvView, new FrameLayout.LayoutParams(-1, -1));
    
    return layout;
}

/**
 * 创建色轮调色视图
 * @param activity 当前 Activity
 * @param initialColor 初始颜色
 * @param listener 颜色变化监听器
 * @return 创建的视图
 */
View createColorWheelView(Activity activity, int initialColor, final OnColorChangedListener listener) {
    FrameLayout layout = new FrameLayout(activity);
    layout.setPadding(dp(activity, 8), dp(activity, 8), dp(activity, 8), dp(activity, 8));
    
    ColorWheelView wheelView = new ColorWheelView(activity, initialColor);
    wheelView.setOnColorChangedListener(listener);
    layout.addView(wheelView, new FrameLayout.LayoutParams(-1, -1));
    
    return layout;
}

/**
 * 创建颜色条调色视图
 * @param activity 当前 Activity
 * @param initialColor 初始颜色
 * @param listener 颜色变化监听器
 * @return 创建的视图
 */
View createColorBarView(Activity activity, int initialColor, final OnColorChangedListener listener) {
    LinearLayout layout = new LinearLayout(activity);
    layout.setOrientation(LinearLayout.HORIZONTAL);
    layout.setPadding(dp(activity, 16), dp(activity, 16), dp(activity, 16), dp(activity, 16));
    
    // 左侧预览 (大色块)
    final View preview = new View(activity);
    LinearLayout.LayoutParams previewParams = new LinearLayout.LayoutParams(dp(activity, 80), -1);
    previewParams.rightMargin = dp(activity, 16);
    preview.setLayoutParams(previewParams);
    preview.setBackgroundColor(initialColor);
    
    GradientDrawable previewBg = new GradientDrawable();
    previewBg.setColor(initialColor);
    previewBg.setCornerRadius(dp(activity, 12));
    preview.setBackgroundDrawable(previewBg);
    
    layout.addView(preview);
    
    // 右侧颜色条
    ColorBarView bar = new ColorBarView(activity, initialColor);
    bar.setLayoutParams(new LinearLayout.LayoutParams(dp(activity, 48), -1));
    layout.addView(bar);
    
    bar.setOnColorChangedListener(new OnColorChangedListener() {
        public void onColorChanged(int color) {
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(color);
            bg.setCornerRadius(dp(activity, 12));
            preview.setBackgroundDrawable(bg);
            if (listener != null) listener.onColorChanged(color);
        }
    });
    
    return layout;
}

// =============== 收藏夹视图 ===============

/**
 * 显示收藏夹视图
 * @param activity 当前 Activity
 * @param container 容器
 * @param favorites 收藏的颜色列表
 * @param listener 颜色选择监听器
 */
void showFavoritesView(Activity activity, FrameLayout container, ArrayList favorites, final OnColorPickedListener listener) {
    container.removeAllViews();
    
    ScrollView scroll = new ScrollView(activity);
    scroll.setVerticalScrollBarEnabled(false);
    
    LinearLayout list = new LinearLayout(activity);
    list.setOrientation(LinearLayout.VERTICAL);
    list.setPadding(dp(activity, 16), dp(activity, 8), dp(activity, 16), dp(activity, 8));
    
    if (favorites.isEmpty()) {
        TextView empty = new TextView(activity);
        empty.setText("暂无收藏颜色\n点击 + 添加当前颜色");
        empty.setTextSize(14);
        empty.setTextColor(Color.GRAY);
        empty.setGravity(Gravity.CENTER);
        empty.setPadding(0, dp(activity, 40), 0, 0);
        list.addView(empty);
    } else {
        for (int i = 0; i < favorites.size(); i++) {
            final String colorStr = favorites.get(i).toString();
            
            // 每项容器
            LinearLayout item = new LinearLayout(activity);
            item.setOrientation(LinearLayout.HORIZONTAL);
            item.setGravity(Gravity.CENTER_VERTICAL);
            item.setPadding(dp(activity, 12), dp(activity, 12), dp(activity, 12), dp(activity, 12));
            item.setBackground(createSelectableBackground());
            
            // 颜色方块
            View colorBlock = new View(activity);
            LinearLayout.LayoutParams blockParams = new LinearLayout.LayoutParams(dp(activity, 40), dp(activity, 40));
            colorBlock.setLayoutParams(blockParams);
            
            try {
                int color = Color.parseColor(colorStr);
                GradientDrawable bg = new GradientDrawable();
                bg.setColor(color);
                bg.setCornerRadius(dp(activity, 8));
                // 添加边框
                bg.setStroke(2, Color.parseColor("#20FFFFFF"));
                colorBlock.setBackgroundDrawable(bg);
            } catch (Exception e) {
                colorBlock.setBackgroundColor(Color.GRAY);
            }
            item.addView(colorBlock);
            
            // 颜色代码文本
            TextView codeText = new TextView(activity);
            codeText.setText(colorStr.toUpperCase());
            codeText.setTextSize(16);
            codeText.setTypeface(Typeface.MONOSPACE);
            codeText.setTextColor(Color.WHITE);
            codeText.setPadding(dp(activity, 16), 0, 0, 0);
            codeText.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
            item.addView(codeText);
            
            // 删除按钮
            TextView deleteBtn = new TextView(activity);
            deleteBtn.setText("×");
            deleteBtn.setTextSize(24);
            deleteBtn.setTextColor(Color.parseColor("#FF999999"));
            deleteBtn.setPadding(dp(activity, 8), 0, dp(activity, 8), 0);
            item.addView(deleteBtn);
            
            // 点击选择
            item.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    try {
                        int color = Color.parseColor(colorStr);
                        if (listener != null) listener.onColorPicked(color);
                    } catch (Exception e) {}
                }
            });
            
            // 点击删除
            deleteBtn.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    favorites.remove(colorStr);
                    saveFavoriteColors(activity, favorites);
                    item.setVisibility(View.GONE);
                    Toast("已删除");
                }
            });
            
            list.addView(item);
            
            // 分隔线
            if (i < favorites.size() - 1) {
                View line = new View(activity);
                line.setBackgroundColor(Color.parseColor("#1AFFFFFF"));
                line.setLayoutParams(new LinearLayout.LayoutParams(-1, 1));
                list.addView(line);
            }
        }
    }
    
    scroll.addView(list);
    container.addView(scroll);
}

// =============== 图片取色对话框 ===============

/**
 * 显示图片取色对话框
 * @param activity 当前 Activity
 * @param callback 颜色选择回调
 */
void showImagePickerDialog(final Activity activity, final OnColorPickedListener callback) {
    try {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity, AlertDialog.THEME_DEVICE_DEFAULT_DARK);
        
        FrameLayout root = new FrameLayout(activity);
        root.setBackgroundColor(Color.parseColor("#FF000000"));
        
        String imgPath = null;
        try {
            if (pluginPath != null) {
                imgPath = pluginPath + "/API/background.png";
            }
        } catch (Exception e) {}
        
        if (imgPath == null) {
            Toast("图片路径错误");
            return;
        }
        
        File imgFile = new File(imgPath);
        if (!imgFile.exists()) {
            Toast("图片不存在");
            return;
        }
        
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = 2;
        final Bitmap bitmap = BitmapFactory.decodeFile(imgPath, opts);
        
        if (bitmap == null) {
            Toast("无法加载图片");
            return;
        }
        
        // 图片视图 (限制最大高度)
        final ImageView imageView = new ImageView(activity);
        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        imageView.setImageBitmap(bitmap);
        FrameLayout.LayoutParams imgParams = new FrameLayout.LayoutParams(-1, dp(activity, 400));
        imgParams.gravity = Gravity.CENTER;
        root.addView(imageView, imgParams);
        
        // 放大镜
        final MagnifierView magnifier = new MagnifierView(activity);
        magnifier.setVisibility(View.GONE);
        root.addView(magnifier, new FrameLayout.LayoutParams(dp(activity, 120), dp(activity, 120)));
        
        // 底部颜色预览栏
        LinearLayout bottomBar = new LinearLayout(activity);
        bottomBar.setOrientation(LinearLayout.HORIZONTAL);
        bottomBar.setGravity(Gravity.CENTER_VERTICAL);
        bottomBar.setBackgroundColor(Color.parseColor("#FF2D2D2D"));
        bottomBar.setPadding(dp(activity, 16), dp(activity, 12), dp(activity, 16), dp(activity, 12));
        FrameLayout.LayoutParams barParams = new FrameLayout.LayoutParams(-1, -2);
        barParams.gravity = Gravity.BOTTOM;
        bottomBar.setLayoutParams(barParams);
        
        final View colorPreview = new View(activity);
        LinearLayout.LayoutParams previewParams = new LinearLayout.LayoutParams(dp(activity, 48), dp(activity, 48));
        colorPreview.setLayoutParams(previewParams);
        colorPreview.setBackgroundColor(Color.WHITE);
        bottomBar.addView(colorPreview);
        
        final TextView hexText = new TextView(activity);
        hexText.setText("#FFFFFF");
        hexText.setTextSize(18);
        hexText.setTypeface(Typeface.MONOSPACE);
        hexText.setTextColor(Color.WHITE);
        hexText.setPadding(dp(activity, 16), 0, 0, 0);
        hexText.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
        bottomBar.addView(hexText);
        
        TextView confirmBtn = new TextView(activity);
        confirmBtn.setText("确定");
        confirmBtn.setTextSize(16);
        confirmBtn.setTextColor(Color.parseColor("#FF7A9681"));
        confirmBtn.setPadding(dp(activity, 16), dp(activity, 8), dp(activity, 16), dp(activity, 8));
        bottomBar.addView(confirmBtn);
        
        root.addView(bottomBar);
        
        // 取消按钮 (左上角)
        TextView closeBtn = new TextView(activity);
        closeBtn.setText("✕");
        closeBtn.setTextSize(24);
        closeBtn.setTextColor(Color.WHITE);
        closeBtn.setPadding(dp(activity, 16), dp(activity, 16), dp(activity, 16), dp(activity, 16));
        FrameLayout.LayoutParams closeParams = new FrameLayout.LayoutParams(-2, -2);
        closeParams.gravity = Gravity.TOP | Gravity.RIGHT;
        closeBtn.setLayoutParams(closeParams);
        root.addView(closeBtn);
        
        imageView.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                if (bitmap == null) return false;
                
                try {
                    Matrix matrix = imageView.getImageMatrix();
                    RectF drawableRect = new RectF(0, 0, bitmap.getWidth(), bitmap.getHeight());
                    matrix.mapRect(drawableRect);
                    
                    float x = event.getX();
                    float y = event.getY();
                    
                    if (!drawableRect.contains(x, y)) {
                        magnifier.setVisibility(View.GONE);
                        return true;
                    }
                    
                    int bitmapX = (int) ((x - drawableRect.left) / drawableRect.width() * bitmap.getWidth());
                    int bitmapY = (int) ((y - drawableRect.top) / drawableRect.height() * bitmap.getHeight());
                    
                    bitmapX = Math.max(0, Math.min(bitmap.getWidth() - 1, bitmapX));
                    bitmapY = Math.max(0, Math.min(bitmap.getHeight() - 1, bitmapY));
                    
                    final int color = bitmap.getPixel(bitmapX, bitmapY);
                    
                    switch (event.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                        case MotionEvent.ACTION_MOVE:
                            magnifier.setVisibility(View.VISIBLE);
                            
                            int magX = (int) x - dp(activity, 60);
                            int magY = (int) y - dp(activity, 140);
                            if (magX < 0) magX = 0;
                            if (magY < 0) magY = 0;
                            magnifier.setX(magX);
                            magnifier.setY(magY);
                            magnifier.update(bitmap, bitmapX, bitmapY, color);
                            
                            colorPreview.setBackgroundColor(color);
                            hexText.setText(colorToHex(color));
                            return true;
                            
                        case MotionEvent.ACTION_UP:
                            return true;
                    }
                } catch (Exception e) {}
                return true;
            }
        });
        
        builder.setView(root);
        final AlertDialog dialog = builder.create();
        
        closeBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        
        confirmBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try {
                    int color = Color.parseColor(hexText.getText().toString());
                    if (callback != null) callback.onColorPicked(color);
                } catch (Exception e) {}
                dialog.dismiss();
            }
        });
        
        dialog.show();
        
    } catch (Exception e) {}
}

// =============== 主调色盘入口 ===============

/**
 * 显示主调色盘对话框
 * @param activity 当前 Activity
 * @param initialColor 初始颜色
 * @param callback 颜色选择回调
 */
void showColorPickerDialog(final Activity activity, final String initialColor, final OnColorPickedListener callback) {
    try {
        final int[] currentColor = {Color.parseColor("#FF7A9681")};
        try {
            if (initialColor != null && !initialColor.isEmpty()) {
                currentColor[0] = Color.parseColor(initialColor);
            }
        } catch (Exception e) {}
        
        final ArrayList favoriteColors = loadFavoriteColors(activity);
        final boolean[] showingFavorites = {false};
        
        AlertDialog.Builder builder = new AlertDialog.Builder(activity, AlertDialog.THEME_DEVICE_DEFAULT_DARK);
        
        // 根布局
        final LinearLayout root = new LinearLayout(activity);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#FF2D2D2D"));
        root.setPadding(dp(activity, 16), dp(activity, 16), dp(activity, 16), dp(activity, 16));
        
        // 顶部标题栏
        LinearLayout header = new LinearLayout(activity);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        
        TextView title = new TextView(activity);
        title.setText("颜色");
        title.setTextSize(20);
        title.setTextColor(Color.WHITE);
        title.setTypeface(null, Typeface.BOLD);
        title.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
        header.addView(title);
        
        // 收藏夹按钮
        final TextView favBtn = new TextView(activity);
        favBtn.setText("收藏夹");
        favBtn.setTextSize(14);
        favBtn.setTextColor(Color.WHITE);
        favBtn.setBackground(createRoundRectDrawable(Color.parseColor("#FF7A9681"), dp(activity, 16)));
        favBtn.setPadding(dp(activity, 16), dp(activity, 8), dp(activity, 16), dp(activity, 8));
        header.addView(favBtn);
        
        // 取色按钮
        final TextView pickBtn = new TextView(activity);
        pickBtn.setText("取色");
        pickBtn.setTextSize(14);
        pickBtn.setTextColor(Color.WHITE);
        pickBtn.setBackground(createRoundRectDrawable(Color.parseColor("#FF5A5A5A"), dp(activity, 16)));
        pickBtn.setPadding(dp(activity, 16), dp(activity, 8), dp(activity, 16), dp(activity, 8));
        LinearLayout.LayoutParams pickParams = new LinearLayout.LayoutParams(-2, -2);
        pickParams.leftMargin = dp(activity, 12);
        pickBtn.setLayoutParams(pickParams);
        header.addView(pickBtn);
        
        root.addView(header);
        
        // 颜色预览
        LinearLayout previewRow = new LinearLayout(activity);
        previewRow.setOrientation(LinearLayout.HORIZONTAL);
        previewRow.setGravity(Gravity.CENTER_VERTICAL);
        previewRow.setPadding(0, dp(activity, 16), 0, dp(activity, 16));
        
        final View colorPreview = new View(activity);
        LinearLayout.LayoutParams previewParams = new LinearLayout.LayoutParams(dp(activity, 56), dp(activity, 56));
        previewParams.rightMargin = dp(activity, 16);
        colorPreview.setLayoutParams(previewParams);
        
        GradientDrawable previewBg = new GradientDrawable();
        previewBg.setColor(currentColor[0]);
        previewBg.setCornerRadius(dp(activity, 12));
        previewBg.setStroke(2, Color.parseColor("#40FFFFFF"));
        colorPreview.setBackgroundDrawable(previewBg);
        previewRow.addView(colorPreview);
        
        final TextView hexText = new TextView(activity);
        hexText.setText(colorToHex(currentColor[0]));
        hexText.setTextSize(16);
        hexText.setTextColor(Color.WHITE);
        hexText.setTypeface(Typeface.MONOSPACE);
        hexText.setPadding(dp(activity, 12), dp(activity, 8), dp(activity, 12), dp(activity, 8));
        hexText.setBackground(createRoundRectDrawable(Color.parseColor("#FF3D3D3D"), dp(activity, 8)));
        hexText.setClickable(true);
        hexText.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                copyToClipboard(activity, hexText.getText().toString());
                Toast("颜色代码已复制");
            }
        });
        previewRow.addView(hexText);
        
        final TextView addFavBtn = new TextView(activity);
        addFavBtn.setText("+");
        addFavBtn.setTextSize(28);
        addFavBtn.setTextColor(Color.parseColor("#FF7A9681"));
        addFavBtn.setPadding(dp(activity, 16), 0, dp(activity, 8), 0);
        previewRow.addView(addFavBtn);
        
        root.addView(previewRow);
        
        // 模式标签栏
        LinearLayout tabRow = new LinearLayout(activity);
        tabRow.setOrientation(LinearLayout.HORIZONTAL);
        tabRow.setBackground(createRoundRectDrawable(Color.parseColor("#FF1E1E1E"), dp(activity, 8)));
        tabRow.setPadding(dp(activity, 4), dp(activity, 4), dp(activity, 4), dp(activity, 4));
        
        final String[] modes = {"RGB", "HSV", "色轮", "颜色条"};
        final TextView[] tabViews = new TextView[4];
        final int[] currentMode = {1};
        
        for (int i = 0; i < 4; i++) {
            final int mode = i;
            TextView tab = new TextView(activity);
            tab.setText(modes[i]);
            tab.setTextSize(14);
            tab.setGravity(Gravity.CENTER);
            tab.setPadding(0, dp(activity, 8), 0, dp(activity, 8));
            tab.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
            
            if (i == currentMode[0]) {
                tab.setTextColor(Color.parseColor("#FF2D2D2D"));
                tab.setTypeface(null, Typeface.BOLD);
                tab.setBackground(createRoundRectDrawable(Color.parseColor("#FF7A9681"), dp(activity, 6)));
            } else {
                tab.setTextColor(Color.GRAY);
                tab.setBackground(null);
            }
            
            final int index = i;
            tab.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    currentMode[0] = index;
                    for (int j = 0; j < 4; j++) {
                        if (j == index) {
                            tabViews[j].setTextColor(Color.parseColor("#FF2D2D2D"));
                            tabViews[j].setTypeface(null, Typeface.BOLD);
                            tabViews[j].setBackground(createRoundRectDrawable(Color.parseColor("#FF7A9681"), dp(activity, 6)));
                        } else {
                            tabViews[j].setTextColor(Color.GRAY);
                            tabViews[j].setTypeface(null, Typeface.NORMAL);
                            tabViews[j].setBackground(null);
                        }
                    }
                    showModeContent(activity, contentContainer, index, currentColor[0], new OnColorChangedListener() {
                        public void onColorChanged(int color) {
                            currentColor[0] = color;
                            updatePreview(colorPreview, hexText, color);
                        }
                    });
                }
            });
            
            tabViews[i] = tab;
            tabRow.addView(tab);
        }
        
        root.addView(tabRow);
        
        // 内容容器 - 固定高度确保显示完整
        final FrameLayout contentContainer = new FrameLayout(activity);
        LinearLayout.LayoutParams contentParams = new LinearLayout.LayoutParams(-1, dp(activity, 280));
        contentParams.topMargin = dp(activity, 16);
        contentParams.bottomMargin = dp(activity, 16);
        contentContainer.setLayoutParams(contentParams);
        contentContainer.setBackground(createRoundRectDrawable(Color.parseColor("#FF1E1E1E"), dp(activity, 12)));
        root.addView(contentContainer);
        
        // 初始化
        showModeContent(activity, contentContainer, 1, currentColor[0], new OnColorChangedListener() {
            public void onColorChanged(int color) {
                currentColor[0] = color;
                updatePreview(colorPreview, hexText, color);
            }
        });
        
        // 透明度滑块
        LinearLayout alphaRow = new LinearLayout(activity);
        alphaRow.setOrientation(LinearLayout.HORIZONTAL);
        alphaRow.setGravity(Gravity.CENTER_VERTICAL);
        alphaRow.setPadding(0, dp(activity, 8), 0, dp(activity, 8));
        
        TextView alphaLabel = new TextView(activity);
        alphaLabel.setText("透明度");
        alphaLabel.setTextSize(14);
        alphaLabel.setTextColor(Color.parseColor("#FFAAAAAA"));
        alphaLabel.setLayoutParams(new LinearLayout.LayoutParams(dp(activity, 60), -2));
        alphaRow.addView(alphaLabel);
        
        final SeekBar alphaSeek = new SeekBar(activity);
        alphaSeek.setMax(255);
        alphaSeek.setProgress(Color.alpha(currentColor[0]));
        alphaSeek.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
        alphaRow.addView(alphaSeek);
        
        final TextView alphaValue = new TextView(activity);
        alphaValue.setText(String.valueOf(Color.alpha(currentColor[0])));
        alphaValue.setTextSize(14);
        alphaValue.setTextColor(Color.WHITE);
        alphaValue.setTypeface(Typeface.MONOSPACE);
        alphaValue.setLayoutParams(new LinearLayout.LayoutParams(dp(activity, 40), -2));
        alphaValue.setGravity(Gravity.RIGHT);
        alphaRow.addView(alphaValue);
        
        root.addView(alphaRow);
        
        alphaSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    currentColor[0] = Color.argb(progress, 
                        Color.red(currentColor[0]), 
                        Color.green(currentColor[0]), 
                        Color.blue(currentColor[0]));
                    updatePreview(colorPreview, hexText, currentColor[0]);
                    alphaValue.setText(String.valueOf(progress));
                }
            }
            public void onStartTrackingTouch(SeekBar seekBar) {}
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        
        // 底部按钮
        LinearLayout buttonRow = new LinearLayout(activity);
        buttonRow.setOrientation(LinearLayout.HORIZONTAL);
        buttonRow.setGravity(Gravity.END);
        buttonRow.setPadding(0, dp(activity, 8), 0, 0);
        
        TextView cancelBtn = new TextView(activity);
        cancelBtn.setText("取消");
        cancelBtn.setTextSize(16);
        cancelBtn.setTextColor(Color.parseColor("#FF7A9681"));
        cancelBtn.setPadding(dp(activity, 24), dp(activity, 12), dp(activity, 24), dp(activity, 12));
        buttonRow.addView(cancelBtn);
        
        TextView confirmBtn = new TextView(activity);
        confirmBtn.setText("确定");
        confirmBtn.setTextSize(16);
        confirmBtn.setTypeface(null, Typeface.BOLD);
        confirmBtn.setTextColor(Color.parseColor("#FF7A9681"));
        confirmBtn.setPadding(dp(activity, 24), dp(activity, 12), dp(activity, 24), dp(activity, 12));
        buttonRow.addView(confirmBtn);
        
        root.addView(buttonRow);
        
        builder.setView(root);
        final AlertDialog dialog = builder.create();
        
        // 按钮事件
        cancelBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        
        confirmBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (callback != null) {
                    callback.onColorPicked(currentColor[0]);
                }
                dialog.dismiss();
            }
        });
        
        favBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showingFavorites[0] = !showingFavorites[0];
                if (showingFavorites[0]) {
                    favBtn.setText("返回");
                    favBtn.setBackground(createRoundRectDrawable(Color.parseColor("#FF5A5A5A"), dp(activity, 16)));
                    showFavoritesView(activity, contentContainer, favoriteColors, new OnColorPickedListener() {
                        public void onColorPicked(int color) {
                            currentColor[0] = color;
                            updatePreview(colorPreview, hexText, color);
                            alphaSeek.setProgress(Color.alpha(color));
                            alphaValue.setText(String.valueOf(Color.alpha(color)));
                        }
                    });
                } else {
                    favBtn.setText("收藏夹");
                    favBtn.setBackground(createRoundRectDrawable(Color.parseColor("#FF7A9681"), dp(activity, 16)));
                    showModeContent(activity, contentContainer, currentMode[0], currentColor[0], new OnColorChangedListener() {
                        public void onColorChanged(int color) {
                            currentColor[0] = color;
                            updatePreview(colorPreview, hexText, color);
                        }
                    });
                }
            }
        });
        
        addFavBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String hex = colorToHex(currentColor[0]);
                if (!favoriteColors.contains(hex)) {
                    if (favoriteColors.size() >= 30) {
                        favoriteColors.remove(0);
                    }
                    favoriteColors.add(hex);
                    saveFavoriteColors(activity, favoriteColors);
                    Toast("已添加到收藏夹");
                } else {
                    Toast("该颜色已存在");
                }
            }
        });
        
        pickBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showImagePickerDialog(activity, new OnColorPickedListener() {
                    public void onColorPicked(int color) {
                        currentColor[0] = color;
                        updatePreview(colorPreview, hexText, color);
                        alphaSeek.setProgress(Color.alpha(color));
                        alphaValue.setText(String.valueOf(Color.alpha(color)));
                    }
                });
            }
        });
        
        dialog.show();
        
        // 简单设置窗口背景 (兼容BeanShell)
        try {
            Window window = dialog.getWindow();
            if (window != null) {
                window.setBackgroundDrawable(createRoundRectDrawable(Color.parseColor("#FF2D2D2D"), dp(activity, 16)));
            }
        } catch (Exception e) {}
        
    } catch (Exception e) {}
}

/**
 * 更新预览区域
 * @param preview 预览视图
 * @param hexText Hex文本视图
 * @param color 新颜色
 */
void updatePreview(View preview, TextView hexText, int color) {
    try {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(preview.getContext(), 12));
        bg.setStroke(2, Color.parseColor("#40FFFFFF"));
        preview.setBackgroundDrawable(bg);
        hexText.setText(colorToHex(color));
    } catch (Exception e) {}
}

/**
 * 显示模式内容
 * @param activity 当前 Activity
 * @param container 容器
 * @param mode 模式
 * @param initialColor 初始颜色
 * @param listener 颜色变化监听器
 */
void showModeContent(Activity activity, FrameLayout container, int mode, int initialColor, OnColorChangedListener listener) {
    container.removeAllViews();
    
    View view = null;
    switch (mode) {
        case 0:
            view = createRgbView(activity, initialColor, listener);
            break;
        case 1:
            view = createHsvView(activity, initialColor, listener);
            break;
        case 2:
            view = createColorWheelView(activity, initialColor, listener);
            break;
        case 3:
            view = createColorBarView(activity, initialColor, listener);
            break;
    }
    
    if (view != null) {
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(-1, -1);
        params.gravity = Gravity.CENTER;
        container.addView(view, params);
    }
}

// =============== 添加带调色盘按钮的输入项方法 ===============

/**
 * 添加带调色盘按钮的颜色输入项
 * @param activity 当前 Activity
 * @param parent 父容器
 * @param title 标题文本
 * @param value 初始颜色值
 * @param hint 提示文本
 * @param titleColor 标题颜色
 * @param cardColor 卡片背景颜色
 * @param saveKey 存储键
 */
void addColorInputItem(final Activity activity, LinearLayout parent, String title, String value, String hint, int titleColor, int cardColor, final String saveKey) {
    try {
        LinearLayout item = new LinearLayout(activity);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setPadding(dp(activity, 16), dp(activity, 12), dp(activity, 16), dp(activity, 12));
        
        // 内层浅背景 (比卡片浅35%)
        int itemColor = lightenColor(cardColor, 0.35f);
        GradientDrawable itemBg = new GradientDrawable();
        itemBg.setColor(itemColor);
        itemBg.setCornerRadius(dp(activity, 8));
        item.setBackgroundDrawable(itemBg);
        
        TextView t1 = new TextView(activity); 
        t1.setText(title); 
        t1.setTextSize(14); 
        t1.setTextColor(titleColor);
        item.addView(t1);

        LinearLayout inputRow = new LinearLayout(activity);
        inputRow.setOrientation(LinearLayout.HORIZONTAL);
        inputRow.setGravity(Gravity.CENTER_VERTICAL);
        inputRow.setPadding(0, dp(activity, 8), 0, 0);
        
        final int[] currentColor = {Color.parseColor("#FF7A9681")}; // 默认颜色
        boolean hasValidColor = false;
        String displayValue = "";
        
        try {
            if (value != null && !value.trim().isEmpty()) {
                currentColor[0] = Color.parseColor(value.trim());
                hasValidColor = true;
                displayValue = value.trim();
            }
        } catch (Exception e) {
            displayValue = "";
        }
        
        final EditText input = new EditText(activity);
        input.setText(displayValue);
        input.setHint(hint);
        input.setTextSize(14);
        input.setTypeface(Typeface.MONOSPACE);
        input.setBackgroundColor(Color.parseColor("#15FFFFFF"));
        input.setPadding(dp(activity, 12), dp(activity, 10), dp(activity, 12), dp(activity, 10));
        
        if (hasValidColor) {
            input.setTextColor(currentColor[0]);
        } else {
            input.setTextColor(Color.parseColor("#FF333333"));
        }
        input.setHintTextColor(Color.GRAY);
        
        LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(0, -2, 1.0f);
        input.setLayoutParams(inputParams);
        
        input.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
            public void afterTextChanged(android.text.Editable s) {
                String val = s.toString().trim();
                // 保存到挂起映射
                pendingSettingsChanges.put(saveKey, val);
                try {
                    if (val.startsWith("#") && (val.length() == 7 || val.length() == 9)) {
                        int color = Color.parseColor(val);
                        input.setTextColor(color);
                    }
                } catch (Exception e) {
                    input.setTextColor(Color.parseColor("#FF333333"));
                }
            }
        });
        
        inputRow.addView(input);

        final TextView colorBtn = new TextView(activity);
        colorBtn.setText("🎨");
        colorBtn.setTextSize(22);
        colorBtn.setGravity(Gravity.CENTER);
        colorBtn.setPadding(dp(activity, 12), dp(activity, 8), dp(activity, 12), dp(activity, 8));
        colorBtn.setBackground(createSelectableBackground());
        inputRow.addView(colorBtn);
        
        item.addView(inputRow);
        parent.addView(item);
        
        // 添加底部间距
        View space = new View(activity);
        space.setBackgroundColor(Color.TRANSPARENT);
        LinearLayout.LayoutParams spaceParams = new LinearLayout.LayoutParams(-1, dp(activity, 4));
        spaceParams.leftMargin = dp(activity, 6);
        spaceParams.rightMargin = dp(activity, 6);
        parent.addView(space, spaceParams);
        
        // UI线程保护：按钮点击事件强制使用runOnUiThread包裹
        View.OnClickListener clickListener = new View.OnClickListener() {
            public void onClick(View v) {
                // 防御性编程：确保所有UI操作在主线程执行
                activity.runOnUiThread(new Runnable() {
                    public void run() {
                        try {
                            String initialColorStr = input.getText().toString().trim();
                            if (initialColorStr.isEmpty() || initialColorStr.equals(hint)) {
                                initialColorStr = "#FF7A9681";
                            }
                            
                            showColorPickerDialog(activity, initialColorStr, new OnColorPickedListener() {
                                public void onColorPicked(final int color) {
                                    // 回调中再次确保UI线程安全
                                    activity.runOnUiThread(new Runnable() {
                                        public void run() {
                                            try {
                                                String hex = colorToHex(color);
                                                input.setText(hex);
                                                input.setTextColor(color);
                                                // 保存到挂起映射
                                                pendingSettingsChanges.put(saveKey, hex);
                                            } catch (Exception e) {}
                                        }
                                    });
                                }
                            });
                        } catch (Exception e) {}
                    }
                });
            }
        };
        
        colorBtn.setOnClickListener(clickListener);
        
    } catch (Exception e) {}
}


// =============== 设置对话框 ===============

void showStyleSettingsDialog(final Activity activity) {
    activity.runOnUiThread(new Runnable() {
        public void run() {
            try {
                final boolean isDark = isEffectiveDarkMode(activity);
                
                int cardColor = isDark ? Color.parseColor("#FF2D2D2D") : Color.parseColor("#FFF5F5F5");
                int subTextColor = isDark ? Color.parseColor("#AAFFFFFF") : Color.parseColor("#99000000");
                int dividerColor = isDark ? Color.parseColor("#1AFFFFFF") : Color.parseColor("#1A000000");
                int textColor = isDark ? Color.parseColor("#FFEFEFEF") : Color.parseColor("#FF333333");
                
                LinearLayout root = new LinearLayout(activity);
                root.setOrientation(LinearLayout.VERTICAL);
                
                LinearLayout header = new LinearLayout(activity);
                header.setOrientation(LinearLayout.VERTICAL);
                header.setPadding(dp(activity, 20), dp(activity, 16), dp(activity, 16), dp(activity, 8));
                header.setBackgroundColor(Color.TRANSPARENT);
                
                LinearLayout titleRow = new LinearLayout(activity);
                titleRow.setOrientation(LinearLayout.HORIZONTAL);
                titleRow.setGravity(Gravity.CENTER_VERTICAL);
                
                TextView title = new TextView(activity);
                title.setText("设置");
                title.setTextSize(22);
                title.setTypeface(null, Typeface.BOLD);
                title.setTextColor(isDark ? Color.parseColor("#FFEFEFEF") : Color.parseColor("#FF333333"));
                title.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
                titleRow.addView(title);
                
                TextView closeBtn = new TextView(activity);
                closeBtn.setText("取消");
                closeBtn.setTextSize(16);
                closeBtn.setTextColor(isDark ? Color.parseColor("#AAFFFFFF") : Color.parseColor("#99000000"));
                closeBtn.setPadding(dp(activity, 12), 0, dp(activity, 4), 0);
                closeBtn.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        Toast("已取消");
                        pendingSettingsChanges.clear();
                        dialog.dismiss();
                    }
                });
                
                TextView previewBtn = new TextView(activity);
                previewBtn.setText("预览");
                previewBtn.setTextSize(16);
                previewBtn.setTextColor(Color.parseColor("#007AFF"));
                previewBtn.setPadding(dp(activity, 12), 0, dp(activity, 8), 0);
                previewBtn.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        savePendingSettings();
                        showPreviewPopup(activity);
                    }
                });
                
                TextView resetBtn = new TextView(activity);
                resetBtn.setText("重置");
                resetBtn.setTextSize(16);
                resetBtn.setTextColor(Color.parseColor("#FF9500"));
                resetBtn.setPadding(dp(activity, 12), 0, dp(activity, 8), 0);
                resetBtn.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        pendingSettingsChanges.clear();
                        Toast("已重置");
                        dialog.dismiss();
                    }
                });
                
                TextView saveBtn = new TextView(activity);
                saveBtn.setText("保存");
                saveBtn.setTextSize(16);
                saveBtn.setTextColor(Color.parseColor("#34C759"));
                saveBtn.setPadding(dp(activity, 12), 0, dp(activity, 8), 0);
                saveBtn.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        int savedCount = savePendingSettings();
                        String msg = savedCount > 0 ? "已保存" + savedCount + "项设置" : "无更改";
                        Toast(msg);
                        dialog.dismiss();
                    }
                });
                
                LinearLayout buttonRow = new LinearLayout(activity);
                buttonRow.setOrientation(LinearLayout.HORIZONTAL);
                buttonRow.addView(resetBtn);
                buttonRow.addView(previewBtn);
                buttonRow.addView(saveBtn);
                buttonRow.addView(closeBtn);
                LinearLayout.LayoutParams buttonRowParams = new LinearLayout.LayoutParams(-2, -2);
                buttonRowParams.gravity = Gravity.END | Gravity.CENTER_VERTICAL;
                titleRow.addView(buttonRow, buttonRowParams);
                header.addView(titleRow);
                
                TextView subTitle = new TextView(activity);
                subTitle.setText("深度定制你的QFX");
                subTitle.setTextSize(12);
                subTitle.setTextColor(subTextColor);
                subTitle.setPadding(0, dp(activity, 4), 0, 0);
                header.addView(subTitle);
                root.addView(header);
                
                ScrollView scroll = new ScrollView(activity);
                scroll.setVerticalScrollBarEnabled(false);
                scroll.setBackgroundColor(Color.TRANSPARENT);
                
                LinearLayout list = new LinearLayout(activity);
                list.setOrientation(LinearLayout.VERTICAL);
                list.setPadding(dp(activity, 16), 0, dp(activity, 16), dp(activity, 30));
                list.setBackgroundColor(Color.TRANSPARENT);
                
                // ==================== 基础模式 ====================
                addSectionHeader(activity, list, "基础模式", subTextColor);
                LinearLayout group1 = createCardGroup(activity, cardColor, 12);
                
                String currMode = getSetting("settings", "ui_theme_mode", "default");
                final String[] modes = {"默认（推荐）", "跟随系统", "强制浅色", "强制深色"};
                final String[] modeVals = {"default", "system", "light", "dark"};
                String modeDisplay = "默认（推荐）";
                if(currMode.equals("system")) modeDisplay = "跟随系统";
                else if(currMode.equals("light")) modeDisplay = "强制浅色";
                else if(currMode.equals("dark")) modeDisplay = "强制深色";
                
                addClickableItem(activity, group1, "主题模式", modeDisplay, textColor, cardColor, false, new View.OnClickListener() {
                    public void onClick(View v) {
                        showM3ChoiceDialog(activity, "主题模式", modes, modeVals, "ui_theme_mode", new OnChoiceSelected() {
                            public void onSelect(String val) {
                                if(val.equals("dark")) putBoolean("settings", "黑白", true);
                                else if(val.equals("light")) putBoolean("settings", "黑白", false);
                                else if(val.equals("default")) putBoolean("settings", "黑白", false);
                                dialog.dismiss();
                                showStyleSettingsDialog(activity);
                            }
                        });
                    }
                });
                
                String scaleVal = getSetting("settings", "ui_dialog_scale", "");
                String scaleDisplay = scaleVal.isEmpty() ? "1.0x (默认)" : scaleVal + "x";
                addClickableItem(activity, group1, "弹窗大小(比例)", scaleDisplay, textColor, cardColor, false, new View.OnClickListener() {
                    public void onClick(View v) {
                        showScaleSliderDialog(activity, new OnChoiceSelected() {
                            public void onSelect(String val) {
                                if (val != null) {
                                    scaleDisplay = val + "x";
                                    dialog.dismiss();
                                    showStyleSettingsDialog(activity);
                                }
                            }
                        });
                    }
                });

                String widthVal = getSetting("settings", "ui_dialog_width", "");
                addInputItem(activity, group1, "弹窗宽度", widthVal, "默认最大260dp，两边各留12dp", textColor, cardColor, "ui_dialog_width", "");
                
                String heightVal = getSetting("settings", "ui_dialog_height", "");
                addInputItem(activity, group1, "弹窗高度", heightVal, "自适应内容", textColor, cardColor, "ui_dialog_height", "");

                LinearLayout switchContainer = new LinearLayout(activity);
                switchContainer.setOrientation(LinearLayout.HORIZONTAL);
                switchContainer.setGravity(Gravity.CENTER_VERTICAL);
                switchContainer.setPadding(dp(activity, 16), dp(activity, 14), dp(activity, 16), dp(activity, 14));
                
                int itemColor = lightenColor(cardColor, 0.35f);
                GradientDrawable bg = new GradientDrawable();
                bg.setColor(itemColor);
                bg.setCornerRadius(dp(activity, 8));
                switchContainer.setBackgroundDrawable(bg);
                
                LinearLayout.LayoutParams containerParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                );
                containerParams.topMargin = dp(activity, 4);
                containerParams.bottomMargin = dp(activity, 4);
                switchContainer.setLayoutParams(containerParams);
                    
                TextView label = new TextView(activity);
                label.setText("振动反馈");
                label.setTextSize(16);
                label.setTextColor(textColor);
                label.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
                switchContainer.addView(label);
                
                Switch switch1 = createSwitch(activity, " ",getSettingBoolean("settings", "振动反馈", true), 16, 0);
                switchContainer.addView(switch1);
                switch1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        pendingSettingsChanges.put("振动反馈",isChecked ? "true":"false");
                    }
                });
                group1.addView(switchContainer);

                View space = new LinearLayout(activity);
                space.setBackgroundColor(Color.TRANSPARENT);
                LinearLayout.LayoutParams spaceParams = new LinearLayout.LayoutParams(-1, dp(activity, 8));
                group1.addView(space, spaceParams);
                
                list.addView(group1);
                
                // ==================== 背景与图标 ====================
                addSectionHeader(activity, list, "背景与图标", subTextColor);
                LinearLayout group2 = createCardGroup(activity, cardColor, 12);
                
                String bgType = getSetting("settings", "ui_bg_type", "color");
                final String[] bgTypes = {"纯色背景", "三色渐变", "图片背景"};
                final String[] bgTypeVals = {"color", "gradient", "image"};
                String bgDisplay = bgType.equals("image") ? "图片背景" : (bgType.equals("gradient") ? "三色渐变" : "纯色背景");
                
                addClickableItem(activity, group2, "背景类型", bgDisplay, textColor, cardColor, false, new View.OnClickListener() {
                    public void onClick(View v) {
                        showM3ChoiceDialog(activity, "背景类型", bgTypes, bgTypeVals, "ui_bg_type", new OnChoiceSelected() {
                            public void onSelect(String val) {
                                dialog.dismiss();
                                showStyleSettingsDialog(activity);
                            }
                        });
                    }
                });
                
                String suffix = isDark ? " (深色模式)" : " (浅色模式)";
                
                if ("color".equals(bgType)) {
                    final String[] colorNames = isDark 
                        ? new String[]{"默认黑", "深空灰", "午夜蓝", "暗夜紫", "墨绿", "酒红", "深褐"} 
                        : new String[]{"默认白", "米白", "柔粉", "天蓝", "薄荷", "香芋紫", "柠檬黄"};
                    final String[] colorVals = isDark
                        ? new String[]{"#FF1E1E1E", "#FF2D2D2D", "#FF1A237E", "#FF4A148C", "#FF1B5E20", "#FF880E4F", "#FF3E2723"}
                        : new String[]{"#FFFFFF", "#FFF8F0", "#FFF0F5", "#E6F7FF", "#F0FFF0", "#E6E6FA", "#FFFFF0"};
                    final String key = isDark ? "ui_bg_color_dark" : "ui_bg_color_light";
                    
                    addClickableItem(activity, group2, "预设颜色" + suffix, "点击选择内置配色", textColor, cardColor, false, new View.OnClickListener() {
                        public void onClick(View v) {
                            showM3ChoiceDialog(activity, "预设颜色", colorNames, colorVals, key, new OnChoiceSelected() {
                                public void onSelect(String val) {
                                    dialog.dismiss();
                                    showStyleSettingsDialog(activity);
                                }
                            });
                        }
                    });
                    String val = getSetting("settings", key, isDark ? "#FF1E1E1E" : "#FFFFFF");
                    addColorInputItem(activity, group2, "自定义Hex", val, "#RRGGBB", textColor, cardColor, key);
                    
                } else if ("gradient".equals(bgType)) {
                    final String[] gradNames = {"默认渐变", "落日余晖", "深海幽蓝", "清新森林", "梦幻紫罗兰", "极光", "黑金"};
                    final String[] gradVals = isDark
                        ? new String[]{"#FF2C2C2C,#FF121212,#FF2C2C2C", "#FF4E342E,#FF3E2723,#FF4E342E", "#FF1A237E,#FF0D47A1,#FF1A237E", "#FF1B5E20,#FF33691E,#FF1B5E20", "#FF4A148C,#FF311B92,#FF4A148C", "#FF006064,#FF004D40,#FF006064", "#FF212121,#FF000000,#FF212121"}
                        : new String[]{"#FFFFFFFF,#FFF5F5F5,#FFFFFFFF", "#FFFFE0B2,#FFFFCC80,#FFFFE0B2", "#FFBBDEFB,#FF90CAF9,#FFBBDEFB", "#FFC8E6C9,#FFA5D6A7,#FFC8E6C9", "#FFE1BEE7,#FFCE93D8,#FFE1BEE7", "#FFB2EBF2,#FF80DEEA,#FFB2EBF2", "#FFF5F5F5,#FFE0E0E0,#FFF5F5F5"};
                    final String key = isDark ? "ui_bg_gradient_dark" : "ui_bg_gradient_light";
                    
                    addClickableItem(activity, group2, "预设渐变" + suffix, "点击选择内置渐变", textColor, cardColor, false, new View.OnClickListener() {
                        public void onClick(View v) {
                            showM3ChoiceDialog(activity, "预设渐变", gradNames, gradVals, key, new OnChoiceSelected() {
                                public void onSelect(String val) {
                                    dialog.dismiss();
                                    showStyleSettingsDialog(activity);
                                }
                            });
                        }
                    });
                    String gradVal = getSetting("settings", key, "");
                    addInputItem(activity, group2, "自定义渐变", gradVal, "Hex1,Hex2,Hex3", textColor, cardColor, key, null);
                    
                } else if ("image".equals(bgType)) {
                    addClickableItem(activity, group2, "选择背景图片", "点击选择本地图片", textColor, cardColor, false, new View.OnClickListener() {
                        public void onClick(View v) {
                            try {
                                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                                intent.setType("image/*");
                                intent.addCategory(Intent.CATEGORY_OPENABLE);
                                activity.startActivityForResult(intent, 1007);
                                Toast("选择后自动居中裁剪应用");
                            } catch(Exception e) { 
                                Toast("失败: " + e); 
                            }
                        }
                    });
                    
                    String blur = getSetting("settings", "ui_img_blur", "0");
                    addInputItem(activity, group2, "图片模糊 (0-25)", blur, "0为不模糊", textColor, cardColor, "ui_img_blur", "0");
                    
                    String alpha = getSetting("settings", "ui_img_alpha", isDark ? "180" : "100");
                    addInputItem(activity, group2, "遮罩浓度 (0-255)", alpha, "越大越暗", textColor, cardColor, "ui_img_alpha", isDark ? "180" : "100");
                }
                
                list.addView(group2);
                
                // ==================== 字体样式 ====================
                addSectionHeader(activity, list, "字体样式", subTextColor);
                LinearLayout group3 = createCardGroup(activity, cardColor, 12);
                
                String currFont = getSetting("settings", "ui_font_type", "default");
                final String[] fonts = {"默认字体", "衬线体", "无衬线", "等宽", "粗体"};
                final String[] fontVals = {"default", "serif", "sans", "monospace", "bold"};
                String fontDisplay = "默认字体";
                for(int i=0; i<fontVals.length; i++) if(fontVals[i].equals(currFont)) fontDisplay = fonts[i];
                
                addClickableItem(activity, group3, "字体风格", fontDisplay, textColor, cardColor, false, new View.OnClickListener() {
                    public void onClick(View v) {
                        showM3ChoiceDialog(activity, "字体风格", fonts, fontVals, "ui_font_type", new OnChoiceSelected() {
                            public void onSelect(String val) {
                                dialog.dismiss();
                                showStyleSettingsDialog(activity);
                            }
                        });
                    }
                });
                
                String currSize = getSetting("settings", "ui_font_size", "1.0");
                final String[] sizes = {"小 (0.85x)", "默认 (1.0x)", "中 (1.15x)", "大 (1.3x)"};
                final String[] sizeVals = {"0.85", "1.0", "1.15", "1.3"};
                String sizeDisplay = "默认 (1.0x)";
                for(int i=0; i<sizeVals.length; i++) if(sizeVals[i].equals(currSize)) sizeDisplay = sizes[i];
                
                addClickableItem(activity, group3, "字体大小", sizeDisplay, textColor, cardColor, false, new View.OnClickListener() {
                    public void onClick(View v) {
                        showM3ChoiceDialog(activity, "字体大小", sizes, sizeVals, "ui_font_size", new OnChoiceSelected() {
                            public void onSelect(String val) {
                                dialog.dismiss();
                                showStyleSettingsDialog(activity);
                            }
                        });
                    }
                });
                
                String tKey = isDark ? "ui_text_color_dark" : "ui_text_color_light";
                String tVal = getSetting("settings", tKey, "");
                addColorInputItem(activity, group3, "字体颜色" + suffix, tVal, "留空自动配色 (推荐)", textColor, cardColor, tKey);
                
                list.addView(group3);
                
                // ==================== 线程池 ====================
                addSectionHeader(activity, list, "线程池", subTextColor);
                LinearLayout group4 = createCardGroup(activity, cardColor, 12);
                
                String priorityVal = getSetting("settings", "thread_pool_priority", "");
                String priorityDisplay;
                if (priorityVal.isEmpty()) {
                    priorityDisplay = "5 (默认)";
                } else {
                    switch (priorityVal) {
                        case "1": priorityDisplay = "1 (最低)"; break;
                        case "2": priorityDisplay = "2"; break;
                        case "3": priorityDisplay = "3"; break;
                        case "4": priorityDisplay = "4"; break;
                        case "5": priorityDisplay = "5 (默认)"; break;
                        case "6": priorityDisplay = "6"; break;
                        case "7": priorityDisplay = "7"; break;
                        case "8": priorityDisplay = "8"; break;
                        case "9": priorityDisplay = "9"; break;
                        case "10": priorityDisplay = "10 (最高)"; break;
                        default: priorityDisplay = "5 (默认)"; break;
                    }
                }
                
                addClickableItem(activity, group4, "线程优先级", priorityDisplay, textColor, cardColor, false, new View.OnClickListener() {
                    public void onClick(View v) {
                        final String[] priorities = {"1 (最低)", "2", "3", "4", "5 (默认)", "6", "7", "8", "9", "10 (最高)"};
                        final String[] priorityNums = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"};
                        showM3ChoiceDialog(activity, "线程优先级", priorities, priorityNums, "thread_pool_priority", new OnChoiceSelected() {
                            public void onSelect(String val) {
                                dialog.dismiss();
                                showStyleSettingsDialog(activity);
                            }
                        });
                    }
                });
                
                String queueCapacity = getSetting("settings", "thread_pool_queue_capacity", "50");
                addInputItem(activity, group4, "任务队列容量", queueCapacity, "默认50", textColor, cardColor, "thread_pool_queue_capacity", "");
                
                String keepAlive = getSetting("settings", "thread_pool_keep_alive", "30");
                addInputItem(activity, group4, "核心线程存活(秒)", keepAlive, "默认30", textColor, cardColor, "thread_pool_keep_alive", "");
                
                String rejectPolicy = getSetting("settings", "thread_pool_reject_policy", "0");
                String[] rejectPolicies = {"丢弃最旧任务 (默认)", "丢弃最新任务", "抛出异常", "调用者执行"};
                String[] rejectPolicyVals = {"0", "1", "2", "3"};
                String rejectPolicyDisplay = "丢弃最旧任务 (默认)";
                for(int i=0; i<rejectPolicyVals.length; i++) {
                    if(rejectPolicyVals[i].equals(rejectPolicy)) {
                        rejectPolicyDisplay = rejectPolicies[i];
                        break;
                    }
                }
                
                addClickableItem(activity, group4, "任务满载策略", rejectPolicyDisplay, textColor, cardColor, false, new View.OnClickListener() {
                    public void onClick(View v) {
                        showM3ChoiceDialog(activity, "任务满载策略", rejectPolicies, rejectPolicyVals, "thread_pool_reject_policy", new OnChoiceSelected() {
                            public void onSelect(String val) {
                                dialog.dismiss();
                                showStyleSettingsDialog(activity);
                            }
                        });
                    }
                });
                
                list.addView(group4);
                
                // ==================== 悬浮窗设置 ====================
                addSectionHeader(activity, list, "悬浮窗设置", subTextColor);
                LinearLayout group5 = createCardGroup(activity, cardColor, 12);
                
                String icpath = getSetting("settings", "iconPath", "");
                boolean isAnim = icpath.toLowerCase().endsWith(".gif") || icpath.toLowerCase().endsWith(".GIF");
                String iconTypeDisplay = isAnim ? "动态图标 (GIF/WebP)" : "静态图标 (PNG/JPG)";
                if (icpath.isEmpty()) iconTypeDisplay = "点击选择图标 (未设置)";
                
                addClickableItem(activity, group5, "更换图标", iconTypeDisplay, textColor, cardColor, false, new View.OnClickListener() {
                    public void onClick(View v) {
                        try {
                            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                            intent.setType("image/*"); 
                            intent.addCategory(Intent.CATEGORY_OPENABLE);
                            activity.startActivityForResult(intent, 1005);
                            Toast("选择后请重新打开设置刷新");
                        } catch(Exception e) { 
                            Toast("文件选择启动失败: " + e); 
                        }
                    }
                });
                
                String floatSize = getSetting("settings", "悬浮窗大小", "48");
                addInputItem(activity, group5, "悬浮窗大小", floatSize, "默认48", textColor, cardColor, "悬浮窗大小", "");
                
                String closeIconSize = getSetting("settings", "关闭区域图标大小", "24");
                addInputItem(activity, group5, "关闭图标大小", closeIconSize, "默认24", textColor, cardColor, "关闭区域图标大小", "");
                
                String dragSens = getSetting("settings", "拖拽灵敏度", "12");
                addInputItem(activity, group5, "拖拽灵敏度", dragSens, "数值越小越灵敏", textColor, cardColor, "拖拽灵敏度", "");
                
                String longPress = getSetting("settings", "长按关闭阈值", "650");
                addInputItem(activity, group5, "长按关闭阈值", longPress, "默认650", textColor, cardColor, "长按关闭阈值", "");
                
                String iconAlpha = getSetting("settings", "iconAlpha", "255");
                addInputItem(activity, group5, "图标透明度", iconAlpha, "0-255", textColor, cardColor, "iconAlpha", "");
                
                if (isAnim) {
                    float refreshRate = 60f;
                    try {
                        Display display = activity.getWindowManager().getDefaultDisplay();
                        refreshRate = display.getRefreshRate();
                    } catch (Exception e) {}
                    
                    java.util.ArrayList<String> fpsPresetList = new java.util.ArrayList<>();
                    java.util.ArrayList<String> fpsDelayList = new java.util.ArrayList<>();
                    
                    fpsPresetList.add("30 FPS (默认)");
                    fpsDelayList.add("33");
                    
                    if (refreshRate >= 59.9f) {
                        fpsPresetList.add("60 FPS");
                        fpsDelayList.add("17");
                    }
                    
                    if (refreshRate >= 89.9f) {
                        fpsPresetList.add("90 FPS");
                        fpsDelayList.add("11");
                    }
                    
                    if (refreshRate >= 119.9f) {
                        fpsPresetList.add("120 FPS");
                        fpsDelayList.add("8");
                    }
                    
                    if (refreshRate >= 143.9f) {
                        fpsPresetList.add("144 FPS");
                        fpsDelayList.add("7");
                    }
                    
                    final String[] fpsPresets = fpsPresetList.toArray(new String[0]);
                    final String[] fpsDelayValues = fpsDelayList.toArray(new String[0]);
                    
                    String currentDelay = getSetting("settings", "gifDelay", "100");
                    int currentFps = 10;
                    try {
                        int delay = Integer.parseInt(currentDelay);
                        currentFps = delay > 0 ? 1000 / delay : 10;
                    } catch(Exception e) {}
                    
                    String fpsDisplay = "点击选择帧率";
                    for (int i = 0; i < fpsPresets.length; i++) {
                        int presetDelay = Integer.parseInt(fpsDelayValues[i]);
                        int presetFps = 1000 / presetDelay;
                        if (Math.abs(currentFps - presetFps) <= 2) {
                            fpsDisplay = fpsPresets[i];
                            break;
                        }
                    }
                    if (currentDelay.equals("100") || currentDelay.equals("33")) fpsDisplay = "30 FPS (默认)";
                    
                    addClickableItem(activity, group5, "帧率设置", fpsDisplay, textColor, cardColor, false, new View.OnClickListener() {
                        public void onClick(View v) {
                            showM3ChoiceDialog(activity, "选择帧率", fpsPresets, fpsDelayValues, "gifDelay", new OnChoiceSelected() {
                                public void onSelect(String val) {
                                    dialog.dismiss();
                                    showStyleSettingsDialog(activity);
                                }
                            });
                        }
                    });
                    
                    LinearLayout animItem = new LinearLayout(activity);
                    animItem.setOrientation(LinearLayout.VERTICAL);
                    animItem.setPadding(dp(activity, 16), dp(activity, 12), dp(activity, 16), dp(activity, 12));
                    
                    GradientDrawable animBg = new GradientDrawable();
                    animBg.setColor(itemColor);
                    animBg.setCornerRadius(dp(activity, 8));
                    animItem.setBackgroundDrawable(animBg);
                    
                    TextView tAnim = new TextView(activity);
                    tAnim.setText("动画速度 (每帧延迟 ms)");
                    tAnim.setTextSize(14);
                    tAnim.setTextColor(textColor);
                    animItem.addView(tAnim);

                    final EditText inputAnim = new EditText(activity);
                    inputAnim.setText(currentDelay);
                    inputAnim.setTextSize(14);
                    inputAnim.setHintTextColor(Color.GRAY);
                    inputAnim.setBackgroundColor(Color.TRANSPARENT);
                    inputAnim.setPadding(0, dp(activity, 8), 0, dp(activity, 8));
                    inputAnim.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);

                    final TextView fpsText = new TextView(activity);
                    fpsText.setTextSize(12);
                    fpsText.setTextColor(textColor);
                    fpsText.setAlpha(0.7f);
                    
                    try {
                        int delay = Integer.parseInt(currentDelay);
                        int fps = delay > 0 ? 1000 / delay : 0;
                        fpsText.setText("当前帧率: " + fps + " FPS");
                    } catch(Exception e) { 
                        fpsText.setText("当前帧率: - FPS"); 
                    }

                    inputAnim.addTextChangedListener(new android.text.TextWatcher() {
                        public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
                        public void onTextChanged(CharSequence s, int start, int before, int count) {}
                        public void afterTextChanged(android.text.Editable s) {
                            String val = s.toString().trim();
                            pendingSettingsChanges.put("gifDelay", val);
                            try {
                                int delay = Integer.parseInt(val);
                                if (delay > 0) {
                                    int fps = 1000 / delay;
                                    fpsText.setText("当前帧率: " + fps + " FPS");
                                } else { fpsText.setText("当前帧率: - FPS"); }
                            } catch(Exception e) { fpsText.setText("当前帧率: - FPS"); }
                        }
                    });

                    animItem.addView(inputAnim);
                    animItem.addView(fpsText);
                    group5.addView(animItem);
                    
                    View aspace = new View(activity);
                    aspace.setBackgroundColor(Color.TRANSPARENT);
                    group5.addView(aspace, new LinearLayout.LayoutParams(-1, dp(activity, 4)));
                }
                
                list.addView(group5);
                
                scroll.addView(list);
                root.addView(scroll);
                
                AlertDialog.Builder builder = new AlertDialog.Builder(activity, AlertDialog.THEME_DEVICE_DEFAULT_LIGHT);
                builder.setView(root);
                builder.setCancelable(true);
                
                dialog = builder.create();
                
                dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
                    public void onDismiss(DialogInterface d) {
                        isDialogShowing = false;
                    }
                });
                
                Window win = dialog.getWindow();
                if (win != null) {
                    win.requestFeature(Window.FEATURE_NO_TITLE);
                } else {
                    // ignore
                }
                
                dialog.show();
                isDialogShowing = true;
                
                applyUiTheme(activity, dialog);
                
                hookFilePicker(activity, 1005, pluginPath + "/API/icon{ext}");
                hookFilePicker(activity, 1007, pluginPath + "/API/background{ext}");
                
                if (win != null) {
                    applyDialogSize(activity, win);
                }
                
            } catch (Exception e) {
                Toast("设置打开失败: " + e.getMessage());
            }
        }
    });
}

void showPreviewPopup(final Activity activity) {
    final boolean isDark = isEffectiveDarkMode(activity);
    
    String bgType = getSetting("settings", "ui_bg_type", "color");
    String bgColor = getSetting("settings", isDark ? "ui_bg_color_dark" : "ui_bg_color_light", 
        isDark ? "#FF1E1E1E" : "#FFFFFFFF");
    String textColorUser = getSetting("settings", isDark ? "ui_text_color_dark" : "ui_text_color_light", "");
    
    int overlayAlpha = 100;
    try { overlayAlpha = Integer.parseInt(getSetting("settings", "ui_img_alpha", isDark ? "180" : "100")); } catch(Exception e){}
    
    boolean isBgDark = isDark;
    if ("color".equals(bgType) && isValidHexColor(bgColor)) {
        isBgDark = isColorDark(Color.parseColor(bgColor.trim()));
    } else if ("image".equals(bgType)) {
        isBgDark = currentIsDark;
    }
    
    int previewTextColor;
    if (isValidHexColor(textColorUser)) {
        previewTextColor = Color.parseColor(textColorUser);
    } else {
        previewTextColor = isBgDark ? Color.parseColor("#FFEFEFEF") : Color.parseColor("#FF333333");
    }
    
    final String fontType = getSetting("settings", "ui_font_type", "default");
    float fSize = 1.0f;
    try { fSize = Float.parseFloat(getSetting("settings", "ui_font_size", "1.0")); } catch(Exception e){}
    final float fontSizeScale = fSize;
    final Typeface tf = getCustomTypeface(fontType);
    
    LinearLayout previewContent = new LinearLayout(activity);
    previewContent.setLayoutParams(new ViewGroup.LayoutParams(250, 250));
    previewContent.setOrientation(LinearLayout.VERTICAL);
    previewContent.setGravity(Gravity.CENTER);
    previewContent.setPadding(dp(activity, 16), dp(activity, 16), dp(activity, 16), dp(activity, 16));
    
    TextView previewTitle = new TextView(activity);
    previewTitle.setText("预览标题");
    previewTitle.setTextSize(18);
    previewTitle.setTypeface(null, Typeface.BOLD);
    previewTitle.setTextColor(previewTextColor);
    previewTitle.setGravity(Gravity.CENTER);
    previewContent.addView(previewTitle);
    
    TextView previewText = new TextView(activity);
    previewText.setText("这是一段测试文本，用于预览弹窗的显示效果。");
    previewText.setTextSize(12);
    previewText.setTextColor(previewTextColor);
    previewText.setGravity(Gravity.CENTER);
    previewText.setPadding(0, dp(activity, 8), 0, dp(activity, 16));
    previewContent.addView(previewText);
    
    Button toastButton = new Button(activity);
    toastButton.setText("Toast");
    toastButton.setTextColor(previewTextColor);
    toastButton.setBackground(null);
    toastButton.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
            Toast("这是一个测试toast");
        }
    });
    previewContent.addView(toastButton);
    
    AlertDialog.Builder previewBuilder = new AlertDialog.Builder(activity, 
        isDark ? AlertDialog.THEME_DEVICE_DEFAULT_DARK : AlertDialog.THEME_DEVICE_DEFAULT_LIGHT);
    previewBuilder.setView(previewContent);
    previewBuilder.setPositiveButton("关闭", null);
    
    final AlertDialog previewDialog = previewBuilder.create();
    previewDialog.show();
    
    Window previewWindow = previewDialog.getWindow();
    if (previewWindow != null) {
        applyDialogSize(activity, previewWindow);
    }
    
    applyUiTheme(activity, previewDialog);
}

void showM3ChoiceDialog(final Activity activity, String title, final String[] names, final String[] values, final String saveKey, final OnChoiceSelected callback) {
    String currentVal = getSetting("settings", saveKey, values[0]);
    int checkedItem = 0;
    for (int i = 0; i < values.length; i++) {
        if (values[i].toString().equals(currentVal)) { checkedItem = i; break; }
    }
    
    AlertDialog.Builder b = new AlertDialog.Builder(activity, 
        isEffectiveDarkMode(activity) ? AlertDialog.THEME_DEVICE_DEFAULT_DARK : AlertDialog.THEME_DEVICE_DEFAULT_LIGHT);
    b.setTitle(title);
    b.setSingleChoiceItems(names, checkedItem, new DialogInterface.OnClickListener() {
        public void onClick(DialogInterface d, int which) {
            try {
                String newVal = values[which].toString();
                pendingSettingsChanges.put(saveKey, newVal);
                try { putString("settings", saveKey, newVal); } catch (Exception e) { }
                if (callback != null) callback.onSelect(newVal);
            } catch (Throwable ex) {}
            d.dismiss();
        }
    });
    b.setNegativeButton("取消", null);
    
    AlertDialog d = b.create();
    d.show();
    applyUiTheme(activity, d);
}

void showScaleSliderDialog(final Activity activity, final OnChoiceSelected callback) {
    try {
        final boolean isDark = false; 
        
        String currentScaleStr = getString("settings", "ui_dialog_scale", "1.0");
        float currentScale = 1.0f;
        try {
            currentScale = Float.parseFloat(currentScaleStr);
        } catch (Exception e) {}
        
        LinearLayout root = new LinearLayout(activity);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(activity, 24), dp(activity, 20), dp(activity, 24), dp(activity, 20));
        
        final TextView valueText = new TextView(activity);
        valueText.setText(String.format("%.2f", currentScale) + "x");
        valueText.setTextSize(28);
        valueText.setTypeface(null, Typeface.BOLD);
        valueText.setTextColor(Color.parseColor("#FF333333"));
        valueText.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams valueParams = new LinearLayout.LayoutParams(-1, -2);
        valueParams.bottomMargin = dp(activity, 20);
        root.addView(valueText, valueParams);
        
        LinearLayout sliderRow = new LinearLayout(activity);
        sliderRow.setOrientation(LinearLayout.HORIZONTAL);
        sliderRow.setGravity(Gravity.CENTER_VERTICAL);
        
        final float MIN_SCALE = 0.25f;
        final float MAX_SCALE = 2.0f;
        final float SCALE_STEP = 0.01f;
        final int MAX_PROGRESS = (int) ((MAX_SCALE - MIN_SCALE) / SCALE_STEP);
        
        final TextView btnMinus = new TextView(activity);
        btnMinus.setText("−");
        btnMinus.setTextSize(28);
        btnMinus.setTypeface(null, Typeface.BOLD);
        btnMinus.setTextColor(Color.parseColor("#007AFF"));
        btnMinus.setPadding(dp(activity, 12), 0, dp(activity, 8), 0);
        sliderRow.addView(btnMinus);
        
        final SeekBar seekBar = new SeekBar(activity);
        int currentProgress = Math.round((currentScale - MIN_SCALE) / SCALE_STEP);
        currentProgress = Math.max(0, Math.min(MAX_PROGRESS, currentProgress));
        seekBar.setMax(MAX_PROGRESS);
        seekBar.setProgress(currentProgress);
        seekBar.setPadding(0, 0, 0, 0);
        
        int progressColor = Color.parseColor("#007AFF");
        seekBar.setProgressTintList(android.content.res.ColorStateList.valueOf(progressColor));
        seekBar.setThumbTintList(android.content.res.ColorStateList.valueOf(progressColor));
        
        LinearLayout.LayoutParams seekParams = new LinearLayout.LayoutParams(0, -2, 1.0f);
        sliderRow.addView(seekBar, seekParams);
        
        final TextView btnPlus = new TextView(activity);
        btnPlus.setText("+");
        btnPlus.setTextSize(28);
        btnPlus.setTypeface(null, Typeface.BOLD);
        btnPlus.setTextColor(Color.parseColor("#007AFF"));
        btnPlus.setPadding(dp(activity, 8), 0, dp(activity, 12), 0);
        sliderRow.addView(btnPlus);
        
        LinearLayout.LayoutParams sliderRowParams = new LinearLayout.LayoutParams(-1, -2);
        sliderRowParams.bottomMargin = dp(activity, 12);
        root.addView(sliderRow, sliderRowParams);
        
        LinearLayout presetRow = new LinearLayout(activity);
        presetRow.setOrientation(LinearLayout.HORIZONTAL);
        presetRow.setGravity(Gravity.CENTER);
        
        final String[] presets = {"0.25", "0.5", "0.75", "1.0", "1.25", "1.5", "1.75", "2.0"};
        final List<TextView> presetButtons = new ArrayList<>();
        
        for (int i = 0; i < presets.length; i++) {
            final String value = presets[i];
            TextView btn = new TextView(activity);
            btn.setText(value + "x");
            btn.setTextSize(12);
            btn.setTextColor(Color.parseColor("#007AFF"));
            btn.setPadding(dp(activity, 8), dp(activity, 6), dp(activity, 8), dp(activity, 6));
            
            presetButtons.add(btn);
            
            btn.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    float val = Float.parseFloat(value);
                    int progress = Math.round((val - MIN_SCALE) / SCALE_STEP);
                    progress = Math.max(0, Math.min(MAX_PROGRESS, progress));
                    seekBar.setProgress(progress);
                    valueText.setText(value + "x");
                    vibrate(activity, 32);
                    updatePresetHighlight(currentScale);
                }
            });
            
            LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(-2, -2);
            if (i < presets.length - 1) {
                btnParams.rightMargin = dp(activity, 6);
            }
            presetRow.addView(btn, btnParams);
        }
        
        LinearLayout.LayoutParams presetParams = new LinearLayout.LayoutParams(-1, -2);
        presetParams.bottomMargin = dp(activity, 16);
        root.addView(presetRow, presetParams);
        
        LinearLayout inputRow = new LinearLayout(activity);
        inputRow.setOrientation(LinearLayout.HORIZONTAL);
        inputRow.setGravity(Gravity.CENTER_VERTICAL);
        
        TextView inputLabel = new TextView(activity);
        inputLabel.setText("自定义:");
        inputLabel.setTextSize(14);
        inputLabel.setTextColor(Color.parseColor("#99000000"));
        inputRow.addView(inputLabel);
        
        final EditText input = new EditText(activity);
        input.setText(String.format("%.2f", currentScale));
        input.setTextSize(14);
        input.setTextColor(Color.parseColor("#FF333333"));
        input.setHintTextColor(Color.parseColor("#66000000"));
        input.setHint("0.25~2.0");
        input.setBackground(null);
        input.setPadding(dp(activity, 8), 0, dp(activity, 8), 0);
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        
        LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(0, -2, 1.0f);
        inputRow.addView(input, inputParams);
        
        TextView unitLabel = new TextView(activity);
        unitLabel.setText("x");
        unitLabel.setTextSize(14);
        unitLabel.setTextColor(Color.parseColor("#99000000"));
        inputRow.addView(unitLabel);
        
        LinearLayout.LayoutParams inputRowParams = new LinearLayout.LayoutParams(-1, -2);
        inputRowParams.bottomMargin = dp(activity, 16);
        root.addView(inputRow, inputRowParams);
        
        final Runnable updateButtonStates = new Runnable() {
            public void run() {
                int progress = seekBar.getProgress();
                btnMinus.setAlpha(progress > 0 ? 1.0f : 0.3f);
                btnPlus.setAlpha(progress < MAX_PROGRESS ? 1.0f : 0.3f);
            }
        };
        
        final Runnable updatePresetHighlight = new Runnable() {
            public void run() {
                float currentScale = MIN_SCALE + (seekBar.getProgress() * SCALE_STEP);
                for (int i = 0; i < presetButtons.size(); i++) {
                    TextView btn = presetButtons.get(i);
                    float presetValue = Float.parseFloat(presets[i]);
                    if (Math.abs(currentScale - presetValue) < 0.01f) {
                        btn.setTextColor(Color.parseColor("#0047AB"));
                        btn.setTypeface(null, Typeface.BOLD);
                    } else {
                        btn.setTextColor(Color.parseColor("#007AFF"));
                        btn.setTypeface(null, Typeface.NORMAL);
                    }
                }
            }
        };
        
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                progress = Math.max(0, Math.min(MAX_PROGRESS, progress));
                
                float scale = MIN_SCALE + (progress * SCALE_STEP);
                String scaleStr = String.format("%.2f", scale);
                valueText.setText(scaleStr + "x");
                
                if (!input.hasFocus()) {
                    input.setText(scaleStr);
                }
                
                updateButtonStates.run();
                updatePresetHighlight.run();
                
                if (fromUser) {
                    vibrate(activity, 48);
                }
            }
            public void onStartTrackingTouch(SeekBar seekBar) {}
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        
        input.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
            public void afterTextChanged(android.text.Editable s) {
                String val = s.toString().trim();
                if (!val.isEmpty()) {
                    try {
                        float f = Float.parseFloat(val);
                        if (f >= MIN_SCALE && f <= MAX_SCALE) {
                            int progress = Math.round((f - MIN_SCALE) / SCALE_STEP);
                            progress = Math.max(0, Math.min(MAX_PROGRESS, progress));
                            seekBar.setProgress(progress);
                            valueText.setText(String.format("%.2f", f) + "x");
                            updateButtonStates.run();
                            updatePresetHighlight.run();
                        }
                    } catch (Exception e) {}
                }
            }
        });
        
        btnMinus.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int progress = seekBar.getProgress();
                if (progress > 0) {
                    seekBar.setProgress(progress - 1);
                    vibrate(activity, 48);
                    updateButtonStates.run();
                    updatePresetHighlight.run();
                }
            }
        });
        
        btnPlus.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int progress = seekBar.getProgress();
                if (progress < MAX_PROGRESS) {
                    seekBar.setProgress(progress + 1);
                    vibrate(activity, 48);
                    updateButtonStates.run();
                    updatePresetHighlight.run();
                }
            }
        });
        
        updateButtonStates.run();
        updatePresetHighlight.run();
        
        AlertDialog.Builder builder = new AlertDialog.Builder(activity, AlertDialog.THEME_DEVICE_DEFAULT_LIGHT);
        builder.setTitle("弹窗缩放");
        builder.setView(root);
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int which) {
                String finalValue = input.getText().toString().trim();
                
                if (!finalValue.isEmpty()) {
                    try {
                        float f = Float.parseFloat(finalValue);
                        if (f >= MIN_SCALE && f <= MAX_SCALE) {
                            pendingSettingsChanges.put("ui_dialog_scale", String.format("%.2f", f));
                        }
                    } catch (Exception e) {
                    }
                }
                
                if (callback != null) {
                    final String valueToPass = finalValue.isEmpty() ? "1.00" : finalValue;
                    activity.runOnUiThread(new Runnable() {
                        public void run() {
                            try {
                                callback.onSelect(valueToPass);
                            } catch (Throwable t) {
                            }
                        }
                    });
                }
                
                d.dismiss();
            }
        });
        
        builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int which) {
                pendingSettingsChanges.remove("ui_dialog_scale");
                
                if (callback != null) {
                    activity.runOnUiThread(new Runnable() {
                        public void run() {
                            try {
                                callback.onSelect(null);
                            } catch (Throwable t) {
                            }
                        }
                    });
                }
                
                d.dismiss();
            }
        });

        final AlertDialog dialog = builder.create();
        dialog.show();
        
        Window window = dialog.getWindow();
        if (window != null) {
            WindowManager.LayoutParams params = window.getAttributes();
            params.width = dialogWidth;
            params.height = ViewGroup.LayoutParams.WRAP_CONTENT;
            window.setAttributes(params);
        }
        
        updateButtonStates.run();
        updatePresetHighlight.run();
        
    } catch (Exception e) {}
}

void addSectionHeader(Activity activity, LinearLayout parent, String text, int color) {
    TextView tv = new TextView(activity);
    tv.setText(text); tv.setTextSize(13); tv.setTextColor(color);
    tv.setPadding(dp(activity, 4), dp(activity, 10), 0, dp(activity, 6));
    parent.addView(tv);
}

LinearLayout createCardGroup(Activity activity, int color, int radius) {
    LinearLayout card = new LinearLayout(activity);
    card.setOrientation(LinearLayout.VERTICAL);
    int padding = dp(activity, 6);
    card.setPadding(padding, padding, padding, padding);
    
    GradientDrawable bg = new GradientDrawable();
    bg.setColor(darkenColor(color, 0.02f));
    bg.setCornerRadius(dp(activity, radius));
    card.setBackgroundDrawable(bg);
    card.setClipToOutline(true);
    return card;
}

void addClickableItem(Activity activity, LinearLayout parent, String title, String sub, int titleColor, int cardColor, boolean isLast, View.OnClickListener onClick) {
    LinearLayout item = new LinearLayout(activity);
    item.setOrientation(LinearLayout.HORIZONTAL);
    item.setGravity(Gravity.CENTER_VERTICAL);
    item.setPadding(dp(activity, 16), dp(activity, 14), dp(activity, 16), dp(activity, 14));
    
    int itemColor = lightenColor(cardColor, 0.35f);
    GradientDrawable itemBg = new GradientDrawable();
    itemBg.setColor(itemColor);
    itemBg.setCornerRadius(dp(activity, 8));
    item.setBackgroundDrawable(itemBg);
    item.setOnClickListener(onClick);
    
    LinearLayout textLayout = new LinearLayout(activity);
    textLayout.setOrientation(LinearLayout.VERTICAL);
    TextView t1 = new TextView(activity); t1.setText(title); t1.setTextSize(16); t1.setTextColor(titleColor);
    textLayout.addView(t1);
    TextView t2 = new TextView(activity); t2.setText(sub); t2.setTextSize(12); t2.setTextColor(titleColor); t2.setAlpha(0.6f);
    textLayout.addView(t2);
    
    item.addView(textLayout, new LinearLayout.LayoutParams(0, -2, 1.0f));
    TextView arrow = new TextView(activity); arrow.setText(">"); arrow.setTextSize(20); arrow.setTextColor(titleColor); arrow.setAlpha(0.4f);
    item.addView(arrow);
    
    parent.addView(item);
    
    if (!isLast) {
        View space = new View(activity);
        space.setBackgroundColor(Color.TRANSPARENT);
        LinearLayout.LayoutParams spaceParams = new LinearLayout.LayoutParams(-1, dp(activity, 4));
        spaceParams.leftMargin = dp(activity, 6);
        spaceParams.rightMargin = dp(activity, 6);
        parent.addView(space, spaceParams);
    }
}

void addInputItem(Activity activity, LinearLayout parent, String title, String value, String hint, int titleColor, int cardColor, String saveKey, String defaultValue) {
    LinearLayout item = new LinearLayout(activity);
    item.setOrientation(LinearLayout.VERTICAL);
    item.setPadding(dp(activity, 16), dp(activity, 12), dp(activity, 16), dp(activity, 12));
    
    int itemColor = lightenColor(cardColor, 0.35f);
    GradientDrawable itemBg = new GradientDrawable();
    itemBg.setColor(itemColor);
    itemBg.setCornerRadius(dp(activity, 8));
    item.setBackgroundDrawable(itemBg);
    
    TextView t1 = new TextView(activity); t1.setText(title); t1.setTextSize(14); t1.setTextColor(titleColor);
    item.addView(t1);

    final EditText input = new EditText(activity);
    String displayValue = value;
    if (value == null || value.trim().isEmpty()) {
        if (defaultValue != null) {
            displayValue = defaultValue;
            input.setHint(hint);
            input.setTextColor(Color.GRAY);
        } else {
            input.setHint(hint);
        }
    }
    input.setText(displayValue);
    input.setTextSize(14);
    input.setHintTextColor(Color.GRAY);
    input.setBackgroundColor(Color.TRANSPARENT);
    input.setPadding(0, dp(activity, 8), 0, dp(activity, 8));

    input.addTextChangedListener(new android.text.TextWatcher() {
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
        public void onTextChanged(CharSequence s, int start, int before, int count) {}
        public void afterTextChanged(android.text.Editable s) {
            String val = s.toString().trim();
            pendingSettingsChanges.put(saveKey, val);
        }
    });

    item.addView(input);
    parent.addView(item);
    
    View space = new View(activity);
    space.setBackgroundColor(Color.TRANSPARENT);
    LinearLayout.LayoutParams spaceParams = new LinearLayout.LayoutParams(-1, dp(activity, 4));
    spaceParams.leftMargin = dp(activity, 6);
    spaceParams.rightMargin = dp(activity, 6);
    parent.addView(space, spaceParams);
}

int lightenColor(int color, float factor) {
    int r = Color.red(color);
    int g = Color.green(color);
    int b = Color.blue(color);
    int a = Color.alpha(color);
    
    r = (int) (r + (255 - r) * factor);
    g = (int) (g + (255 - g) * factor);
    b = (int) (b + (255 - b) * factor);
    
    return Color.argb(a, Math.min(255, r), Math.min(255, g), Math.min(255, b));
}

int darkenColor(int color, float factor) {
    int r = Color.red(color);
    int g = Color.green(color);
    int b = Color.blue(color);
    int a = Color.alpha(color);
    
    r = (int) (r * (1 - factor));
    g = (int) (g * (1 - factor));
    b = (int) (b * (1 - factor));
    
    return Color.argb(a, Math.max(0, r), Math.max(0, g), Math.max(0, b));
}

void addInputItem(Activity activity, LinearLayout parent, String title, String value, String hint, int titleColor, String saveKey, String defaultValue) {
    int cardColor = Color.parseColor("#FFF5F5F5");
    addInputItem(activity, parent, title, value, hint, titleColor, cardColor, saveKey, defaultValue);
}

void addInputItem(Activity activity, LinearLayout parent, String title, String value, String hint, int titleColor, String saveKey) {
    addInputItem(activity, parent, title, value, hint, titleColor, saveKey, null);
}

static java.util.HashMap pendingSettingsChanges = new java.util.HashMap();

int savePendingSettings() {
    if (pendingSettingsChanges == null || pendingSettingsChanges.isEmpty()) {
        return 0;
    }
    
    int count = 0;
    Object[] keys = pendingSettingsChanges.keySet().toArray();
    for (Object keyObj : keys) {
        String key = (String) keyObj;
        Object value = pendingSettingsChanges.get(key);
        if (value != null) {
            putString("settings", key, value.toString());
            count++;
        }
    }
    
    pendingSettingsChanges.clear();
    return count;
}

int resetAllSettingsToDefault() {
    String[] settingKeys = {
        "ui_theme_mode", "ui_dialog_scale", "ui_dialog_width", "ui_dialog_height", 
        "振动反馈", "ui_bg_type", "ui_bg_color_dark", "ui_bg_color_light", 
        "ui_bg_gradient_dark", "ui_bg_gradient_light", "ui_img_blur", "ui_img_alpha", 
        "ui_font_type", "ui_font_size", "ui_text_color_dark", "ui_text_color_light", 
        "thread_pool_priority", "thread_pool_queue_capacity", "thread_pool_keep_alive", 
        "thread_pool_name_prefix", "thread_pool_reject_policy", "悬浮窗大小", 
        "关闭区域图标大小", "拖拽灵敏度", "长按关闭阈值", "移动阈值"
    };
    
    int count = 0;
    for (String key : settingKeys) {
        putString("settings", key, "");
        count++;
    }
    
    if (pendingSettingsChanges != null) {
        pendingSettingsChanges.clear();
    }
    
    return count;
}

public Switch createSwitch(Context activity, String str, boolean state, int size, float weight) {
    Switch switch1 = new Switch(activity);
    switch1.setText(str);
    switch1.setTextColor(Color.parseColor("#4CA1AF"));
    switch1.setChecked(state);
    
    switch1.setScaleX(3.2f);
    switch1.setScaleY(3.2f);
    
    if(size > 0) switch1.setTextSize(size);
    
    if(weight > 0) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, weight);
        params.leftMargin = dp(activity, 8);
        params.rightMargin = dp(activity, 8);
        switch1.setLayoutParams(params);
    }
    
    return switch1;
}

CheckBox createCheckBox(Activity activity, String text, boolean checked, int textSizeDp, int textColor) {
    CheckBox checkBox = new CheckBox(activity);
    checkBox.setText(text);
    checkBox.setChecked(checked);
    if (textSizeDp > 0) checkBox.setTextSize(textSizeDp);
    
    LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    );
    params.topMargin = dp(activity, 4);
    params.bottomMargin = dp(activity, 4);
    checkBox.setLayoutParams(params);
    
    int padding = dp(activity, 16);
    checkBox.setPadding(padding, padding, padding, padding);
    
    checkBox.setTextColor(textColor);
    
    checkBox.setButtonTintList(android.content.res.ColorStateList.valueOf(textColor));
    
    return checkBox;
}

void addDivider(Activity activity, LinearLayout parent, int color) {
    View v = new View(activity); v.setBackgroundColor(color);
    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 1); lp.leftMargin = dp(activity, 16);
    parent.addView(v, lp);
}

android.graphics.drawable.StateListDrawable getSelectableBg(Activity activity) {
    android.graphics.drawable.StateListDrawable res = new android.graphics.drawable.StateListDrawable();
    res.setExitFadeDuration(300);
    res.addState(new int[]{android.R.attr.state_pressed}, new android.graphics.drawable.ColorDrawable(Color.parseColor("#1A000000")));
    res.addState(new int[]{}, new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
    return res;
}

private float getMaxRefreshRate(Context context) {
    try {
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        if (wm == null) return 60f;
        Display display = wm.getDefaultDisplay();
        if (display == null) return 60f;

        if (android.os.Build.VERSION.SDK_INT >= 23) {
            Display.Mode[] modes = display.getSupportedModes();
            float max = 0f;
            for (int i = 0; i < modes.length; i++) {
                float r = modes[i].getRefreshRate();
                if (r > max) {
                    max = r;
                }
            }
            return max > 0f ? max : display.getRefreshRate();
        } else {
            return display.getRefreshRate();
        }
    } catch (Throwable t) {
        return 60f;
    }
}
