//作者ᗜ×ᗜ
//使用请保留版权
//有bug或者建议可以大胆向我反馈

// 图标路径
String iconBase        = pluginPath + "/API/icon";
String iconPath        = new java.io.File(iconBase + ".png").exists() ? iconBase + ".png" :
                        new java.io.File(iconBase + ".gif").exists() ? iconBase + ".gif" :
                        iconBase + ".png"; // 默认兜底
String closeIconPath   = pluginPath + "/API/closeIcon.png";
String settingiconPath = pluginPath + "/API/settingicon.png";

// 不要改！不要改！不要改！
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicBoolean;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Calendar;

String rootPath        = pluginPath + "/API/";
String htmlPath        = pluginPath + "/HTML/";
String configPath      = pluginPath + "/config/";
String qq              = myUin;
final String logPath   = pluginPath + "/Log/";
long startTime         = System.currentTimeMillis();
// 因为模拟定位暂时只适配了QQ
final String QQpackage = "com.tencent.mobileqq";
ExecutorService ThreadPool = null;

// 核心api（顺序加载）  非核心api（并行加载）
final String[] coreFiles = {
    rootPath + "import.java",   // 导类
    rootPath + "api.java",      // 基础
    rootPath + "uitools.java"   // UI工具
};
final String[] parallelFiles = {
    rootPath + "api2.java",     // 模拟定位
    rootPath + "api3.java",     // 消息统计
    rootPath + "api4.java",     // 悬浮窗
    rootPath + "api5.java",     // 跳转
    rootPath + "api6.java",     // 运行状态
    rootPath + "api7.java",     // html
    rootPath + "api8.java",     // QQ空间
    rootPath + "function.java"//功能(动态热插拔)
};

// API加载耗时，-1表示未初始化
volatile long apiLoadCostTime = -1;
// 静态变量用于缓存 SimpleDateFormat，避免频繁创建
private static ThreadLocal dateFormatHolder = new ThreadLocal();

public static String getTime() {
    try {
        // 尝试从线程缓存获取
        SimpleDateFormat df = (SimpleDateFormat) dateFormatHolder.get();
        if (df == null) {
            // 如果未创建，则新建并存入缓存
            df = new SimpleDateFormat("HH:mm:ss");
            dateFormatHolder.set(df);
        }
        return df.format(new Date());
    } catch (Exception e) {
        try {
            SimpleDateFormat df = new SimpleDateFormat("HH:mm:ss");
            return df.format(new Date());
        } catch (Exception ex) {
            Calendar calendar = Calendar.getInstance();
            int hour = calendar.get(Calendar.HOUR_OF_DAY);
            int minute = calendar.get(Calendar.MINUTE);
            int second = calendar.get(Calendar.SECOND);
            return (hour < 10 ? "0" + hour : hour) + ":" + 
                   (minute < 10 ? "0" + minute : minute) + ":" + 
                   (second < 10 ? "0" + second : second);
        }
    }
}

void traceLog(String name, String txt) {
    String 文件名 = name;
    try {
        if (!name.endsWith(".txt")) {
            文件名 = name + ".txt";
        }
        log("/Log/" + 文件名, getTime() + "    " + txt);
    } catch (Exception e) {
        log("/Log/" + 文件名, "    " + txt);
    }
}

void traceLog(String txt) {
    try {
        log("/Log/api_log.txt", getTime() + "    " + txt);
    } catch (Exception e) {
        log("/Log/api_log.txt", "    " + txt);
    }
}

/**
 * 初始化/重建线程池（支持自定义配置）
 * 调用时机：应用启动时、检测到线程池异常时
 */
void initThreadPool() {
    // 检查线程池是否存活
    if (ThreadPool != null) {
        try {
            ThreadPool.submit(new Runnable() {
                public void run() {}
            }).get(100, TimeUnit.MILLISECONDS);
            traceLog("main_log", "线程池存活，直接使用");
            return; // 线程池正常，跳过重建
        } catch (Exception e) {
            traceLog("main_log", "线程池异常，执行重建: " + e.getMessage());
            ThreadPool = null; // 强制重建
        }
    }

    // 线程优先级 (1-10，默认5=NORM_PRIORITY)
    int threadPriority = 5;
    try {
        String sp = getString("settings", "thread_pool_priority", "");
        if (!sp.isEmpty()) threadPriority = Math.max(1, Math.min(10, Integer.parseInt(sp)));
    } catch (Exception e) {}

    // 最大任务队列容量 (默认50)
    int queueCapacity = 50;
    try {
        String sp = getString("settings", "thread_pool_queue_capacity", "");
        if (!sp.isEmpty()) queueCapacity = Math.max(10, Integer.parseInt(sp));
    } catch (Exception e) {}

    // 空闲线程存活时间 (默认30秒)
    long keepAliveTime = 30;
    try {
        String sp = getString("settings", "thread_pool_keep_alive", "");
        if (!sp.isEmpty()) keepAliveTime = Math.max(5, Long.parseLong(sp));
    } catch (Exception e) {}

    // 线程名称前缀
    String threadNamePrefix = getString("settings", "thread_pool_name_prefix", "ovoWorker");

    // 拒绝策略 (0=DiscardOldest, 1=Discard, 2=Abort, 3=CallerRuns)
    int rejectPolicy = 0;
    try {
        String sp = getString("settings", "thread_pool_reject_policy", "");
        if (!sp.isEmpty()) rejectPolicy = Math.max(0, Math.min(3, Integer.parseInt(sp)));
    } catch (Exception e) {}

    // 动态内存计算：可用内存 / 10MB = 线程数
    long freeMemory = Runtime.getRuntime().freeMemory();
    long maxHeap = Runtime.getRuntime().maxMemory();
    long totalMemory = Runtime.getRuntime().totalMemory();
    long availableMemory = freeMemory + (maxHeap - totalMemory);

    // 每10MB分配1线程，至少2个，最多不超过CPU核心数*2且≤16
    int cpuCores = Runtime.getRuntime().availableProcessors();
    int corePoolSize = Math.max(2, Math.min((int)(availableMemory / (10 * 1024 * 1024)), Math.min(cpuCores, 8)));
    int maxPoolSize = Math.min(corePoolSize * 2, 16);

    traceLog("main_log", "初始化线程池: 核心=" + corePoolSize + ", 最大=" + maxPoolSize +
             ", 队列=" + queueCapacity + ", 优先级=" + threadPriority);

    // 线程工厂
    ThreadFactory threadFactory = new ThreadFactory() {
        private int threadCount = 1;
        public Thread newThread(Runnable r) {
            Thread t = new Thread(r);
            t.setName(threadNamePrefix + "-" + threadCount++);
            t.setDaemon(true);
            t.setPriority(threadPriority);
            return t;
        }
    };

    // 拒绝策略
    RejectedExecutionHandler rejectHandler;
    switch (rejectPolicy) {
        case 1:
            rejectHandler = new ThreadPoolExecutor.DiscardPolicy();
            break;
        case 2:
            rejectHandler = new ThreadPoolExecutor.AbortPolicy();
            break;
        case 3:
            rejectHandler = new ThreadPoolExecutor.CallerRunsPolicy();
            break;
        default:
            rejectHandler = new ThreadPoolExecutor.DiscardOldestPolicy();
            break;
    }

    ThreadPool = new ThreadPoolExecutor(
        corePoolSize,
        maxPoolSize,
        keepAliveTime,
        TimeUnit.SECONDS,
        new LinkedBlockingQueue(queueCapacity),
        threadFactory,
        rejectHandler
    );

    traceLog("main_log", "线程池初始化完成: " + ThreadPool.toString());
}

initThreadPool();

ThreadPool.execute(new Runnable() {
    public void run() {
        try {
            for (int i = 0; i < coreFiles.length; i++) {
                loadJava(coreFiles[i]);
                traceLog("main_log", "核心api加载完成：" + coreFiles[i] + "，耗时：" + (System.currentTimeMillis() - startTime) + "ms");
            }

            final CountDownLatch latch = new CountDownLatch(parallelFiles.length);
            for (int i = 0; i < parallelFiles.length; i++) {
                final String currentFile = parallelFiles[i];
                ThreadPool.execute(new Runnable() {
                    public void run() {
                        try {
                            long fileStartTime = System.currentTimeMillis();
                            loadJava(currentFile);
                            traceLog("main_log", "非核心api加载完成：" + currentFile + "，耗时：" + (System.currentTimeMillis() - fileStartTime) + "ms");
                        } catch (Exception e) {
                            String errorMsg = "[非核心API加载] 失败：" + currentFile + "，原因：" + e.getMessage();
                            traceLog("main_log", errorMsg);
                            Toast(errorMsg);
                        } finally {
                            latch.countDown();
                        }
                    }
                });
            }

            latch.await(10000, TimeUnit.MILLISECONDS);

            apiLoadCostTime = System.currentTimeMillis() - startTime;

            traceLog("main_log", "所有API加载完成，总耗时：" + apiLoadCostTime + "ms");

            uiHandler.post(new Runnable() {
                public void run() {
                    traceLog("main_log", "切换到UI线程执行原神启动");
                    原神启动();
                }
            });

        } catch (Exception e) {
            String errorMsg = "[API加载异常] 为什么呢？！请看VCR：" + e.getMessage();
            traceLog("main_log", errorMsg);
            Toast(errorMsg);
        }
    }
});

// 全局变量
String currentPackageName = context.getPackageName();
String applicationType = "";

// 使用 volatile 声明状态变量
volatile boolean 悬浮窗显示状态 = false;
volatile boolean 应用前台状态 = false;
volatile boolean 延迟启动完成 = false;
volatile boolean OK = false;
volatile boolean 允许触摸 = true;

//初始化ui线程用于将ui操作提交到主线程
Handler uiHandler = new Handler(Looper.getMainLooper());
Activity 最后Activity = null;
AtomicBoolean isRunning = new AtomicBoolean(false);
Context appContext = null;

boolean dialogVisible = false;
Activity activity = null;
volatile boolean Hook已调用 = false;

List hookloveList = new ArrayList();

void 卸载loveHook() {
    if (hookloveList.isEmpty()) {
        traceLog("main_log", "  [卸载Hook] 无需卸载，列表为空");
        return;
    }

    traceLog("main_log", "  [卸载Hook] 开始清理，Hook数量=" + hookloveList.size());

    for (int i = 0; i < hookloveList.size(); i++) {
        Object unhook = hookloveList.get(i);
        try {
            Method unhookMethod = unhook.getClass().getMethod("unhook");
            unhookMethod.invoke(unhook);
            traceLog("main_log", "    [卸载Hook] 成功卸载");
        } catch (Exception e) {
            traceLog("main_log", "    [卸载Hook] 取消失败: " + e.getMessage());
        }
    }

    hookloveList.clear();
    traceLog("main_log", "  [卸载Hook] 清理完成，剩余数量: " + hookloveList.size());
}

void Hook生命周期() {
    try {
        // Hook onResume - 前台
        Object resumeHook = XposedBridge.hookMethod(
            android.app.Activity.class.getDeclaredMethod("onResume"),
            new XC_MethodHook() {
                protected void afterHookedMethod(XC_MethodHook.MethodHookParam param) {
                    try {
                        Activity activity = (Activity) param.thisObject;
                        if (!activity.getPackageName().equals(QQpackage)) return;

                        traceLog("main_log", "应用进入前台: " + activity.getClass().getSimpleName());

                        uiHandler.post(new Runnable() {
                            public void run() {
                                应用前台状态 = true;
                                允许触摸 = true;
                                最后Activity = activity;

                                if (!延迟启动完成) {
                                    traceLog("main_log", "延迟启动未完成，尝试重新初始化");
                                    原神启动();
                                    return;
                                }

                                if (!悬浮窗显示状态 && getBoolean("settings", "开关", false)) {
                                    traceLog("main_log", "前台自动显示悬浮窗");
                                    启动悬浮窗(activity);
                                }
                            }
                        });
                    } catch (Throwable e) {
                        traceLog("main_log", "onResume异常: " + e.getMessage());
                    }
                }
            }
        );
        hookloveList.add(resumeHook);

        // Hook onPause - 后台
        Object pauseHook = XposedBridge.hookMethod(
            android.app.Activity.class.getDeclaredMethod("onPause"),
            new XC_MethodHook() {
                protected void afterHookedMethod(XC_MethodHook.MethodHookParam param) {
                    try {
                        Activity activity = (Activity) param.thisObject;
                        if (!activity.getPackageName().equals(QQpackage)) return;

                        traceLog("main_log", "应用进入后台: " + activity.getClass().getSimpleName());

                        uiHandler.post(new Runnable() {
                            public void run() {
                                应用前台状态 = false;
                                允许触摸 = false;

                                if (悬浮窗显示状态) {
                                    traceLog("main_log", "后台隐藏悬浮窗");
                                    停止悬浮窗();
                                }
                            }
                        });
                    } catch (Throwable e) {
                        traceLog("main_log", "onPause异常: " + e.getMessage());
                    }
                }
            }
        );
        hookloveList.add(pauseHook);
        initStats();
        installQFunHooks();
        Hook已调用 = true;
    } catch (Throwable e) {
        traceLog("main_log", "Hook生命周期失败: " + e.getMessage());
    }
}

void 原神启动() {
    if (!Hook已调用) {
        Hook生命周期();
        Hook已调用 = true;
        traceLog("main_log", "Hook生命周期已调用，标志位设置完成");
    }

    if (延迟启动完成) return;

    if (apiLoadCostTime == -1) {
        traceLog("main_log", "错误：apiLoadCostTime未初始化");
        return;
    }

    traceLog("main_log", "脚本开始异步初始化，API加载耗时：" + apiLoadCostTime + "ms");

    try {
        activity = getNowActivity();
        if (activity == null) {
            Toast("获取活动失败");
            traceLog("main_log", "获取活动失败");
            return;
        }
        最后Activity = activity;
    } catch (Exception e) {
        traceLog("main_log", "获取Activity异常：" + e.getMessage());
        Toast("获取活动异常");
        return;
    }

    final String appType;
    if ("com.tencent.mobileqq".equals(currentPackageName)) {
        appType = "QQ";
    } else if ("com.tencent.tim".equals(currentPackageName)) {
        appType = "TIM";
    } else {
        Toast("当前应用不支持" + currentPackageName);
        traceLog("main_log", "当前应用不支持: " + currentPackageName);
        return;
    }

    Toast("当前运行App为: " + appType + "\n点击悬浮窗查看菜单\n加载耗时：" + apiLoadCostTime + "ms");

    boolean 模拟定位开关a = getBoolean("模拟定位开关", "模拟定位开关", false);
    if (模拟定位开关a) {
        Toast("正在开启模拟定位...");
        traceLog("main_log", "开启模拟定位");
        开模拟定位();
    }

    try {
        ThreadPool.execute(new Runnable() {
            public void run() {
                try {
                    checkQFXUpdate();
                    ensureResourceAvailable();
                    addItem("开/关悬浮窗", "悬浮窗开关");
                    addItem("Java脚本", "openPlugin");
                    addItem("设置页面", "openSetting");
                    延迟启动完成 = true;
                    traceLog("main_log", "add项添加完成");
                    isRunning.set(false);
                } catch (Exception e) {
                    traceLog("main_log", "添加菜单项异常: " + e);
                }
            }
        });
    } catch (Exception e) {
        traceLog("main_log", "提交菜单项任务异常: " + e);
    }

    if (getBoolean("settings", "开关", false)) {
        悬浮窗状态 = STATE_DESTROYED;
        启动悬浮窗(activity);
    }

    traceLog("main_log", "异步初始化完成，hook监听已启动");
}

addMenuItem("菜单", "菜单");

// 给作者点个赞
sendZan("3069670151", 50);