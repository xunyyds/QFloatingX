// 悬浮窗生命周期状态常量
private static final int STATE_DESTROYED = 0;  // 视图已销毁，内存释放，不可见不可交互
private static final int STATE_CREATED = 1;    // 视图已实例化但未添加到WindowManager，不可见
private static final int STATE_VISIBLE = 2;    // 视图已添加到WindowManager，可见且可交互
private static final int STATE_HIDDEN = 3;     // 视图已从WindowManager移除但实例保留，不可见

// 关闭区域常量（可配置）
private static final int DEFAULT_CLOSE_RANGE_SIZE_DP = 80;     // 关闭区域直径(dp)
private static final int DEFAULT_FLOAT_SIZE_DP = 60;           // 悬浮窗默认大小(dp)
private static final int DEFAULT_CLOSE_ICON_SIZE_DP = 24;      // 关闭图标默认大小(dp)
private static final int DEFAULT_ICON_SIZE_DP = 35;            // 悬浮窗图标默认大小(dp)
private static final int VIBRATION_INTERVAL_MS = 100;          // 持续振动间隔

// 拖拽手势状态标志
private boolean isDragging = false;                     // 是否处于拖拽模式
private boolean isInCloseRange = false;                 // 悬浮窗中心是否进入关闭区域
private boolean isCloseRangeAttached = false;           // 防止重复添加到WindowManager
private View screenDimView = null;                      // 系统窗口管理器服务
private FrameLayout closeRangeView = null;              // 关闭区域容器
private ImageView closeRangeIcon = null;                // 关闭区域图标
private Bitmap cachedCloseIconBitmap = null;            // 关闭图标缓存
private Vibrator vibrator = null;                      // 系统振动服务
private Runnable continuousVibrationRunnable = null;    // 持续振动任务

// 触摸与动画状态
private final Handler xfcHandler = new Handler(Looper.getMainLooper());
private int touchOffsetX, touchOffsetY;
private long touchStartTime;
private boolean isLongClickScheduled = false;
private int currentAlpha = 255;
private Runnable longClickRunnable;
private Runnable fadeRunnable;

// 悬浮窗核心状态字段
private int 悬浮窗状态 = STATE_DESTROYED;
private boolean 悬浮窗显示状态 = false;
private boolean 允许触摸 = false;
private WindowManager wm = null;
private WindowManager.LayoutParams params = null;
private FrameLayout floatingView = null;
private ImageView iconImageView = null;
private Bitmap cachedIconBitmap = null;

// =============== 设置读取方法 ===============

private int 获取悬浮窗大小(Activity activity) {
    String value = getString("settings", "悬浮窗大小", "60");
    try {
        return (int) (Double.parseDouble(value) * activity.getResources().getDisplayMetrics().density);
    } catch (Exception e) {
        return (int) (DEFAULT_FLOAT_SIZE_DP * activity.getResources().getDisplayMetrics().density);
    }
}

private int 获取悬浮窗图标大小(Activity activity) {
    String value = getString("settings", "悬浮窗大小", "60");
    try {
        double size = Double.parseDouble(value) * 0.6; // 图标为悬浮窗大小的60%
        return (int) (size * activity.getResources().getDisplayMetrics().density);
    } catch (Exception e) {
        return (int) (DEFAULT_ICON_SIZE_DP * activity.getResources().getDisplayMetrics().density);
    }
}

private int 获取关闭区域大小(Activity activity) {
    String value = getString("settings", "关闭区域图标大小", "80");
    try {
        return (int) (Double.parseDouble(value) * activity.getResources().getDisplayMetrics().density);
    } catch (Exception e) {
        return (int) (DEFAULT_CLOSE_RANGE_SIZE_DP * activity.getResources().getDisplayMetrics().density);
    }
}

private int 获取关闭图标大小(Activity activity) {
    String value = getString("settings", "关闭区域图标大小", "24");
    try {
        return (int) (Double.parseDouble(value) * activity.getResources().getDisplayMetrics().density);
    } catch (Exception e) {
        return (int) (DEFAULT_CLOSE_ICON_SIZE_DP * activity.getResources().getDisplayMetrics().density);
    }
}

private float 获取移动阈值(Activity activity) {
    String value = getString("settings", "移动阈值", "12");
    try {
        return (float) (Double.parseDouble(value) * activity.getResources().getDisplayMetrics().density);
    } catch (Exception e) {
        return 12 * activity.getResources().getDisplayMetrics().density;
    }
}

private long 获取长按关闭阈值() {
    String value = getString("settings", "长按关闭阈值", "650");
    try {
        return Long.parseLong(value);
    } catch (Exception e) {
        return 650;
    }
}

private int 获取拖拽灵敏度() {
    String value = getString("settings", "拖拽灵敏度", "12");
    try {
        return Integer.parseInt(value);
    } catch (Exception e) {
        return 12;
    }
}

// =============== 辅助方法 ===============

android.graphics.drawable.Drawable createCircleDrawable(String colorStr) {
    int color = Color.parseColor(colorStr);
    android.graphics.drawable.ShapeDrawable drawable = new android.graphics.drawable.ShapeDrawable(
        new android.graphics.drawable.shapes.OvalShape()
    );
    drawable.getPaint().setColor(color);
    drawable.getPaint().setAntiAlias(true);
    return drawable;
}

Bitmap 创建关闭区域Fallback图标(Activity activity, int size) {
    try {
        Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        Paint paint = new Paint();
        
        paint.setColor(Color.parseColor("#F44336"));
        paint.setStyle(Paint.Style.FILL);
        paint.setAntiAlias(true);
        canvas.drawCircle(size / 2, size / 2, size / 2, paint);
        
        paint.setColor(Color.WHITE);
        paint.setTextSize(size * 0.5f);
        paint.setTextAlign(Paint.Align.CENTER);
        Paint.FontMetrics fontMetrics = paint.getFontMetrics();
        float centerX = size / 2;
        float centerY = size / 2 - (fontMetrics.ascent + fontMetrics.descent) / 2;
        canvas.drawText("X", centerX, centerY, paint);
        
        return bitmap;
    } catch (Exception e) {
        return null;
    }
}

Bitmap 加载图片文件(String path) {
    try {
        return BitmapFactory.decodeFile(path);
    } catch (Exception e) {
        return null;
    }
}

Bitmap 创建默认图标(Activity activity) {
    try {
        int size = 获取悬浮窗图标大小(activity);
        Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        Paint paint = new Paint();
        
        paint.setColor(Color.parseColor("#4CAF50"));
        paint.setStyle(Paint.Style.FILL);
        paint.setAntiAlias(true);
        canvas.drawCircle(size / 2, size / 2, size / 2, paint);
        
        paint.setColor(Color.WHITE);
        paint.setTextSize(size * 0.4f);
        paint.setTextAlign(Paint.Align.CENTER);
        canvas.drawText("≡", size / 2, size / 2 + size * 0.12f, paint);
        
        return bitmap;
    } catch (Exception e) {
        return null;
    }
}

Bitmap 加载图标Bitmap(Activity activity) {
    Bitmap bitmap = null;
    if (iconPath != null && !iconPath.isEmpty()) {
        bitmap = 加载图片文件(iconPath);
    }
    if (bitmap == null) {
        bitmap = 创建默认图标(activity);
    }
    return bitmap;
}

void 设置图标图片(Activity activity, ImageView imageView) {
    if (cachedIconBitmap == null) {
        cachedIconBitmap = 加载图标Bitmap(activity);
    }
    if (cachedIconBitmap != null && imageView != null) {
        imageView.setImageBitmap(cachedIconBitmap);
    }
}

boolean 检查悬浮窗权限(Activity activity) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        return Settings.canDrawOverlays(activity);
    }
    return true;
}

void 保存悬浮窗位置(Activity activity) {
    try {
        if (params != null && activity != null) {
            SharedPreferences sp = activity.getSharedPreferences("floating_window_pos", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sp.edit();
            editor.putInt("x", params.x);
            editor.putInt("y", params.y);
            editor.apply();
        }
    } catch (Exception e) {
    }
}

int 加载悬浮窗位置(Activity activity) {
    try {
        if (activity != null) {
            SharedPreferences sp = activity.getSharedPreferences("floating_window_pos", Context.MODE_PRIVATE);
            return sp.getInt("x", 0);
        }
    } catch (Exception e) {
    }
    return 0;
}

int 加载悬浮窗Y位置(Activity activity) {
    try {
        if (activity != null) {
            SharedPreferences sp = activity.getSharedPreferences("floating_window_pos", Context.MODE_PRIVATE);
            return sp.getInt("y", (int)(100 * activity.getResources().getDisplayMetrics().density));
        }
    } catch (Exception e) {
    }
    return (int)(100 * activity.getResources().getDisplayMetrics().density);
}

// =============== 关闭区域视图 ===============

void 创建关闭区域视图(final Activity activity) {
    if (closeRangeView != null) {
        return;
    }
    
    final int closeRangeSize = 获取关闭区域大小(activity);
    final int closeIconSize = 获取关闭图标大小(activity);
    
    closeRangeView = new FrameLayout(activity);
    FrameLayout.LayoutParams containerParams = new FrameLayout.LayoutParams(closeRangeSize, closeRangeSize);
    closeRangeView.setLayoutParams(containerParams);
    closeRangeView.setBackground(createCircleDrawable("#4DFFFFFF"));
    
    closeRangeIcon = new ImageView(activity);
    FrameLayout.LayoutParams iconParams = new FrameLayout.LayoutParams(closeIconSize, closeIconSize);
    iconParams.gravity = Gravity.CENTER;
    closeRangeIcon.setLayoutParams(iconParams);
    closeRangeIcon.setScaleType(ImageView.ScaleType.CENTER_CROP);
    
    if (closeIconPath != null && !closeIconPath.isEmpty()) {
        cachedCloseIconBitmap = 加载图片文件(closeIconPath);
    }
    if (cachedCloseIconBitmap == null) {
        cachedCloseIconBitmap = 创建关闭区域Fallback图标(activity, closeIconSize);
    }
    if (cachedCloseIconBitmap != null) {
        closeRangeIcon.setImageBitmap(cachedCloseIconBitmap);
    }
    
    closeRangeView.addView(closeRangeIcon);
    closeRangeView.setVisibility(View.GONE);
}

void 显示关闭区域(final Activity activity) {
    if (wm == null || params == null) return;
    
    if (closeRangeView == null) {
        创建关闭区域视图(activity);
    }
    
    activity.runOnUiThread(new Runnable() {
        public void run() {
            try {
                if (isCloseRangeAttached && closeRangeView != null) {
                    try {
                        if (closeRangeView.isAttachedToWindow()) {
                            wm.removeView(closeRangeView);
                        }
                    } catch (Exception e) {
                    }
                }
                
                DisplayMetrics dm = new DisplayMetrics();
                wm.getDefaultDisplay().getMetrics(dm);
                int screenHeight = dm.heightPixels;
                int closeRangeSize = 获取关闭区域大小(activity);
                
                WindowManager.LayoutParams closeParams = new WindowManager.LayoutParams(
                    closeRangeSize, closeRangeSize,
                    params.type,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | 
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    android.graphics.PixelFormat.TRANSLUCENT
                );
                closeParams.gravity = Gravity.CENTER;
                closeParams.y = (int)(screenHeight * 0.45f);
                
                wm.addView(closeRangeView, closeParams);
                closeRangeView.setVisibility(View.VISIBLE);
                
                isCloseRangeAttached = true;
                
            } catch (Exception e) {
            }
        }
    });
}

void 隐藏关闭区域(final Activity activity) {
    if (wm == null) return;
    
    activity.runOnUiThread(new Runnable() {
        public void run() {
            try {
                if (closeRangeView != null && closeRangeView.isAttachedToWindow()) {
                    wm.removeView(closeRangeView);
                }
                
                if (vibrator != null) {
                    vibrator.cancel();
                }
                xfcHandler.removeCallbacks(continuousVibrationRunnable);
                
                isInCloseRange = false;
                isCloseRangeAttached = false;
                
            } catch (Exception e) {
            }
        }
    });
}

void 更新关闭区域状态(Activity activity, int floatX, int floatY) {
    if (closeRangeView == null || !isDragging) return;
    
    try {
        int[] closeRangePos = new int[2];
        closeRangeView.getLocationOnScreen(closeRangePos);
        int closeCenterX = closeRangePos[0] + closeRangeView.getWidth() / 2;
        int closeCenterY = closeRangePos[1] + closeRangeView.getHeight() / 2;
        
        int floatCenterX = floatX + 获取悬浮窗大小(activity) / 2;
        int floatCenterY = floatY + 获取悬浮窗大小(activity) / 2;
        
        float distance = (float) Math.sqrt(
            Math.pow(closeCenterX - floatCenterX, 2) + 
            Math.pow(closeCenterY - floatCenterY, 2)
        );
        
        boolean previouslyInRange = isInCloseRange;
        isInCloseRange = distance <= (closeRangeView.getWidth() / 2f);
        
        if (closeRangeIcon != null) {
            int brightness = isInCloseRange ? 255 : 180;
            closeRangeIcon.setImageAlpha(brightness);
        }
        
        if (isInCloseRange && !previouslyInRange) {
            启动持续振动(activity);
        } else if (!isInCloseRange && previouslyInRange) {
            停止持续振动();
        }
        
    } catch (Exception e) {
    }
}

void 启动持续振动(Activity activity) {
    if (vibrator == null) {
        vibrator = (Vibrator) activity.getSystemService(Context.VIBRATOR_SERVICE);
    }
    
    if (continuousVibrationRunnable == null) {
        continuousVibrationRunnable = new Runnable() {
            public void run() {
                if (isInCloseRange && isDragging) {
                    vibrate(activity, 12);
                    xfcHandler.postDelayed(this, VIBRATION_INTERVAL_MS);
                }
            }
        };
    }
    
    xfcHandler.post(continuousVibrationRunnable);
}

void 停止持续振动() {
    if (vibrator != null) {
        vibrator.cancel();
    }
    xfcHandler.removeCallbacks(continuousVibrationRunnable);
}

// =============== 悬浮窗核心功能 ===============

void 设置窗口参数(Activity activity) {
    int type;
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
    } else {
        type = WindowManager.LayoutParams.TYPE_PHONE;
    }
    
    int floatSize = 获取悬浮窗大小(activity);
    
    params = new WindowManager.LayoutParams(
        floatSize, floatSize,
        type,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | 
        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        android.graphics.PixelFormat.TRANSLUCENT
    );
    params.gravity = Gravity.TOP | Gravity.LEFT;
    params.x = 加载悬浮窗位置(activity);
    params.y = 加载悬浮窗Y位置(activity);
}

void 创建悬浮窗视图(final Activity activity) {
    try {
        if (floatingView != null) {
            悬浮窗状态 = STATE_CREATED;
            return;
        }
        
        touchOffsetX = 0;
        touchOffsetY = 0;
        currentAlpha = 255;
        
        floatingView = new FrameLayout(activity);
        floatingView.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        ));
        
        iconImageView = new ImageView(activity);
        int iconSize = 获取悬浮窗图标大小(activity);
        FrameLayout.LayoutParams iconParams = new FrameLayout.LayoutParams(iconSize, iconSize);
        iconImageView.setLayoutParams(iconParams);
        
        设置图标图片(activity, iconImageView);
        iconImageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        iconImageView.setImageAlpha(255);
        floatingView.addView(iconImageView);
        
        设置触摸事件(activity);
        
        悬浮窗状态 = STATE_CREATED;
        
    } catch (Exception e) {
        销毁悬浮窗资源();
    }
}

void 添加到窗口管理器(Activity activity) {
    try {
        if (floatingView == null || wm == null) return;
        
        if (floatingView.isAttachedToWindow()) {
            wm.removeView(floatingView);
        }
        
        设置窗口参数(activity);
        wm.addView(floatingView, params);
        
        if (iconImageView != null) {
            iconImageView.setImageAlpha(currentAlpha);
        }
        
        悬浮窗状态 = STATE_VISIBLE;
        悬浮窗显示状态 = true;
        
    } catch (Exception e) {
        悬浮窗状态 = STATE_CREATED;
    }
}

void 销毁悬浮窗资源() {
    try {
        if (floatingView != null && floatingView.isAttachedToWindow()) {
            wm.removeView(floatingView);
        }
    } catch (Exception e) {
    }
    
    floatingView = null;
    iconImageView = null;
    悬浮窗状态 = STATE_DESTROYED;
    悬浮窗显示状态 = false;
    允许触摸 = false;
    isLongClickScheduled = false;
    isDragging = false;
    isInCloseRange = false;
}

void 设置触摸事件(final Activity activity) {
    if (iconImageView == null) return;
    
    final float moveThreshold = 获取移动阈值(activity);
    final long longClickThreshold = 获取长按关闭阈值();
    
    if (fadeRunnable == null) {
        fadeRunnable = new Runnable() {
            public void run() {
                if (isLongClickScheduled && currentAlpha > 100 && 悬浮窗显示状态 && 允许触摸) {
                    currentAlpha -= 10;
                    if (iconImageView != null) {
                        iconImageView.setImageAlpha(currentAlpha);
                    }
                    if (isLongClickScheduled) {
                        xfcHandler.postDelayed(this, 30);
                    }
                }
            }
        };
    }
    
    if (longClickRunnable == null) {
        longClickRunnable = new Runnable() {
            public void run() {
                isLongClickScheduled = false;
                if (悬浮窗显示状态 && 允许触摸) {
                    long pressDuration = System.currentTimeMillis() - touchStartTime;
                    if (pressDuration >= longClickThreshold) {
                        activity.runOnUiThread(new Runnable() {
                            public void run() {
                                if (悬浮窗显示状态) {
                                    Toast("长按关闭悬浮窗");
                                    停止悬浮窗(activity);
                                    putBoolean("settings", "开关", false);
                                }
                            }
                        });
                    }
                }
            }
        };
    }
    
    iconImageView.setOnTouchListener(new View.OnTouchListener() {
        public boolean onTouch(View v, MotionEvent event) {
            if (!允许触摸 || floatingView == null || !悬浮窗显示状态) {
                return false;
            }
            
            boolean handled = false;
            
            try {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        isDragging = false;
                        touchStartTime = System.currentTimeMillis();
                        touchOffsetX = (int) (event.getRawX() - params.x);
                        touchOffsetY = (int) (event.getRawY() - params.y);
                        currentAlpha = 255;
                        
                        xfcHandler.removeCallbacks(fadeRunnable);
                        xfcHandler.postDelayed(fadeRunnable, 30);
                        
                        if (!isLongClickScheduled) {
                            isLongClickScheduled = true;
                            xfcHandler.postDelayed(longClickRunnable, longClickThreshold);
                        }
                        handled = true;
                        break;
                        
                    case MotionEvent.ACTION_MOVE:
                        if (isLongClickScheduled) {
                            xfcHandler.removeCallbacks(longClickRunnable);
                            isLongClickScheduled = false;
                        }
                        xfcHandler.removeCallbacks(fadeRunnable);
                        
                        int deltaX = Math.abs((int)(event.getRawX() - (params.x + touchOffsetX)));
                        int deltaY = Math.abs((int)(event.getRawY() - (params.y + touchOffsetY)));
                        
                        if (!isDragging && (deltaX > moveThreshold || deltaY > moveThreshold)) {
                            isDragging = true;
                            显示关闭区域(activity);
                        }
                        
                        if (isDragging) {
                            int sensitivity = 获取拖拽灵敏度();
                            int baseMoveX = (int) (event.getRawX() - touchOffsetX - params.x);
                            int baseMoveY = (int) (event.getRawY() - touchOffsetY - params.y);
                            
                            int newX = params.x + (int)(baseMoveX * sensitivity / 12.0f);
                            int newY = params.y + (int)(baseMoveY * sensitivity / 12.0f);
                            
                            int screenWidth = wm.getDefaultDisplay().getWidth();
                            int screenHeight = wm.getDefaultDisplay().getHeight();
                            int iconSize = 获取悬浮窗大小(activity);
                            
                            newX = Math.max(0, Math.min(newX, screenWidth - iconSize));
                            newY = Math.max(0, Math.min(newY, screenHeight - iconSize));
                            
                            params.x = newX;
                            params.y = newY;
                            wm.updateViewLayout(floatingView, params);
                            保存悬浮窗位置(activity);
                            
                            更新关闭区域状态(activity, newX, newY);
                        }
                        
                        if (iconImageView != null) {
                            iconImageView.setImageAlpha(255);
                        }
                        handled = true;
                        break;
                        
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        xfcHandler.removeCallbacks(longClickRunnable);
                        xfcHandler.removeCallbacks(fadeRunnable);
                        isLongClickScheduled = false;
                        
                        if (iconImageView != null) {
                            iconImageView.setImageAlpha(255);
                        }
                        
                        if (isDragging) {
                            isDragging = false;
                            
                            if (isInCloseRange) {
                                Toast("已关闭悬浮窗");
                                停止悬浮窗(activity);
                                putBoolean("settings", "开关", false);
                            }
                            
                            隐藏关闭区域(activity);
                        } else if (event.getAction() == MotionEvent.ACTION_UP) {
                            long pressDuration = System.currentTimeMillis() - touchStartTime;
                            int deltaXUp = Math.abs((int) event.getRawX() - (params.x + touchOffsetX));
                            int deltaYUp = Math.abs((int) event.getRawY() - (params.y + touchOffsetY));
                            
                            if (pressDuration < longClickThreshold && 
                                deltaXUp < moveThreshold && deltaYUp < moveThreshold) {
                                处理图标点击();
                            }
                        }
                        
                        handled = true;
                        break;
                }
            } catch (Exception e) {
                xfcHandler.removeCallbacks(longClickRunnable);
                xfcHandler.removeCallbacks(fadeRunnable);
                停止持续振动();
                isLongClickScheduled = false;
                isDragging = false;
                isInCloseRange = false;
                if (iconImageView != null) {
                    iconImageView.setImageAlpha(255);
                }
                隐藏关闭区域(activity);
            }
            
            return handled;
        }
    });
}

void 处理图标点击() {
    try {
        final Activity activity = getNowActivity();
        if (activity == null) activity = 最后Activity;
        if (activity == null || activity.isFinishing()) {
            return;
        }
        final Activity finalActivity = activity;
        activity.runOnUiThread(new Runnable() {
            public void run() {
                vibrate(finalActivity, 48);
                if (!OK) {
                    显示菜单(finalActivity);
                    OK = true;
                }
            }
        });
    } catch (Exception e) {
        OK = false;
    }
}

// =============== 公开接口方法 ===============

public void 悬浮窗开关(int chatType, String peerUin, String name) {
    Activity activity = getNowActivity();
    if (activity == null) activity = 最后Activity;
    if (activity == null) return;
    
    final Activity finalActivity = activity;
    activity.runOnUiThread(new Runnable() {
        public void run() {
            boolean 开关状态 = !getBoolean("settings", "开关", false);
            putBoolean("settings", "开关", 开关状态);
            vibrate(finalActivity, 48);
            
            if (开关状态) {
                启动悬浮窗(finalActivity);
            } else {
                停止悬浮窗(finalActivity);
            }
        }
    });
}

public void 启动悬浮窗(final Activity activity) {
    try {
        if (activity == null || activity.isFinishing()) return;
        
        wm = (WindowManager) activity.getSystemService(Context.WINDOW_SERVICE);
        if (wm == null) return;
        
        if (!检查悬浮窗权限(activity)) {
            Toast("请先授予悬浮窗权限");
            return;
        }
        
        switch (悬浮窗状态) {
            case STATE_DESTROYED:
                创建悬浮窗视图(activity);
                添加到窗口管理器(activity);
                break;
            case STATE_HIDDEN:
                currentAlpha = 255;
                添加到窗口管理器(activity);
                break;
            case STATE_VISIBLE:
                break;
            case STATE_CREATED:
                currentAlpha = 255;
                添加到窗口管理器(activity);
                break;
        }
        OK = false;
        允许触摸 = true;
        
    } catch (Exception e) {
    }
}

public void 停止悬浮窗(final Activity activity) {
    try {
        xfcHandler.removeCallbacksAndMessages(null);
        isLongClickScheduled = false;
        isDragging = false;
        isInCloseRange = false;
        
        停止持续振动();
        隐藏关闭区域(activity);
        
        保存悬浮窗位置(activity);
        
        switch (悬浮窗状态) {
            case STATE_VISIBLE:
                if (floatingView != null && wm != null) {
                    try {
                        if (floatingView.isAttachedToWindow()) {
                            wm.removeView(floatingView);
                        }
                    } catch (Exception e) {
                    }
                }
                悬浮窗状态 = STATE_HIDDEN;
                悬浮窗显示状态 = false;
                允许触摸 = false;
                break;
            case STATE_HIDDEN:
                break;
            case STATE_CREATED:
                销毁悬浮窗资源();
                break;
            case STATE_DESTROYED:
                break;
        }
        
    } catch (Exception e) {
        悬浮窗状态 = STATE_DESTROYED;
        悬浮窗显示状态 = false;
        允许触摸 = false;
        isDragging = false;
        isInCloseRange = false;
    }
}

void 停止悬浮窗() {
    Activity activity = getNowActivity() != null ? getNowActivity() : 最后Activity;
    if (activity != null) {
        停止悬浮窗(activity);
    } else {
        xfcHandler.removeCallbacksAndMessages(null);
        悬浮窗状态 = STATE_DESTROYED;
        悬浮窗显示状态 = false;
        允许触摸 = false;
        isLongClickScheduled = false;
        isDragging = false;
        isInCloseRange = false;
    }
}

public void 卸载悬浮窗() {
    停止悬浮窗();
    try {
        if (floatingView != null && floatingView.isAttachedToWindow()) {
            wm.removeView(floatingView);
        }
        if (closeRangeView != null && closeRangeView.isAttachedToWindow()) {
            wm.removeView(closeRangeView);
        }
    } catch (Exception e) {
    }
    
    floatingView = null;
    iconImageView = null;
    closeRangeView = null;
    closeRangeIcon = null;
    
    if (cachedIconBitmap != null) {
        cachedIconBitmap.recycle();
        cachedIconBitmap = null;
    }
    if (cachedCloseIconBitmap != null) {
        cachedCloseIconBitmap.recycle();
        cachedCloseIconBitmap = null;
    }
    
    悬浮窗状态 = STATE_DESTROYED;
    悬浮窗显示状态 = false;
    允许触摸 = false;
    isLongClickScheduled = false;
    isDragging = false;
    isInCloseRange = false;
    isCloseRangeAttached = false;
    
    xfcHandler.removeCallbacksAndMessages(null);
    if (vibrator != null) {
        vibrator.cancel();
    }
}
