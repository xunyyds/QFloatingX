import com.tencent.qqnt.msg.api.IMsgUtilApi;
import com.tencent.qqnt.kernel.nativeinterface.MsgElement;
import com.tencent.qqnt.kernel.nativeinterface.Contact;
import com.tencent.qqnt.kernel.nativeinterface.MsgElement;
import com.tencent.qqnt.kernel.nativeinterface.TextElement;
import com.tencent.qqnt.kernel.nativeinterface.PicElement;
import com.tencent.qqnt.kernel.nativeinterface.VideoElement;
import com.tencent.mobileqq.qroute.QRoute;
import com.tencent.qqnt.msg.api.IMsgService;
import com.tencent.qqnt.kernel.nativeinterface.PttElement;
import com.tencent.qqnt.kernel.nativeinterface.IKernelMsgService;
import com.tencent.qqnt.kernelpublic.nativeinterface.Contact;
import com.tencent.qqnt.kernel.nativeinterface.MsgRecord;
import com.tencent.qqnt.kernel.nativeinterface.IOperateCallback;
import me.yxp.qfun.utils.qq.QQCurrentEnv;
import com.tencent.mobileqq.profilecard.api.IProfileDataService;
import com.tencent.mobileqq.profilecard.api.IProfileProtocolService;
import android.os.Bundle;
import com.tencent.mobileqq.data.Card;
import java.lang.Thread;            // Thread.yield()
Object app=BaseApplicationImpl.getApplication().getRuntime();


// 1. 背景颜色 (使用处: 弹窗背景、根布局背景)
String UI_COLOR_BG_LIGHT = "#FFFFFF";       // 亮色模式：纯白
String UI_COLOR_BG_DARK = "#FF1E1E1E";      // 暗色模式：深灰 (Material Dark)

// 2. 主文本颜色 (使用处: 标题、正文、列表项)
int UI_COLOR_TEXT_LIGHT = Color.parseColor("#FF000000"); // 亮色模式：纯黑
int UI_COLOR_TEXT_DARK = Color.parseColor("#FFEFEFEF");  // 暗色模式：灰白

// 3. 次要文本颜色 (使用处: Hint提示、取消按钮、说明文字)
int UI_COLOR_SUBTEXT_LIGHT = Color.parseColor("#99000000"); // 亮色模式：半透黑
int UI_COLOR_SUBTEXT_DARK = Color.parseColor("#99EFEFEF");  // 暗色模式：半透白

// 4. 输入框/容器背景 (使用处: EditText背景、代码块背景)
int UI_COLOR_INPUT_BG_LIGHT = Color.parseColor("#0D000000"); // 亮色模式：极淡黑
int UI_COLOR_INPUT_BG_DARK = Color.parseColor("#1AFFFFFF");  // 暗色模式：极淡白

// 5. 描边/分割线颜色 (使用处: 按钮边框、输入框边框)
int UI_COLOR_STROKE_LIGHT = Color.parseColor("#1A000000");   // 亮色模式：淡黑线条
int UI_COLOR_STROKE_DARK = Color.parseColor("#33FFFFFF");    // 暗色模式：淡白线条

// 6. 强调色 (使用处: 确定按钮文字、图标)
// 亮色模式默认蓝，暗色模式使用更柔和的蓝
int UI_COLOR_ACCENT_LIGHT = Color.parseColor("#FF2196F3");
int UI_COLOR_ACCENT_DARK = Color.parseColor("#FF8AB4F8");


boolean isThemeDark(Activity activity) {
    // 1. 【最高优先级】脚本手动强制暗黑开关
    try {
        boolean forceDark = getBoolean("settings", "黑白", false);
        if (forceDark) return true; // 如果手动开启了暗黑，直接返回真
    } catch (Throwable e) {}

    // try {
        // android.content.ContentResolver resolver = app.getApplication().getContentResolver();
        // if (android.provider.Settings.Global.getInt(resolver, "ui_night_mode", -1) == 2) {
            // return true; // 系统强制深色
        // }
    // } catch (Throwable e) {} // 静默失败
    
    // if (activity != null) {
        // try {
            // int actMode = activity.getResources().getConfiguration().uiMode & 48;
            // if (actMode == 32) return true; // Activity深色
        // } catch (Throwable e) {}
    // }
    
    // try {
        // int appMode = app.getApplication().getResources().getConfiguration().uiMode & 48;
        // if (appMode == 32) return true; // 应用深色
    // } catch (Throwable e) {}
    
    return false; // 默认浅色
}

public String get(String url) {
	StringBuffer buffer = new StringBuffer();
	InputStreamReader isr = null;
	try {
		URL urlObj = new URL(url);
		URLConnection uc = urlObj.openConnection();
		uc.setConnectTimeout(10000);
		uc.setReadTimeout(10000);
		isr = new InputStreamReader(uc.getInputStream(), "utf-8");
		BufferedReader reader = new BufferedReader(isr);
		String line;
		while((line = reader.readLine()) != null) {
			buffer.append(line + "\n");
		}
	} catch(Exception e) {
		return "访问网页失败，原因:" + e;
	} finally {
		try {
			if(null != isr) {
				isr.close();
			}
		} catch(IOException e) {
			return "访问网页失败，原因:" + e;
		}
	}
	if(buffer.length() == 0) return "访问网页失败";
	buffer.delete(buffer.length() - 1, buffer.length());
	return buffer.toString();
}

private String getTodayDateStr() {
    try {
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd", Locale.CHINA);
        return dateFormat.format(cal.getTime());
    } catch (Exception e) {
        log("日期格式化错误: " + e.getMessage());
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH) + 1;
        int day = cal.get(Calendar.DAY_OF_MONTH);
        return (year < 1000 ? "2000" : String.valueOf(year)) + 
               (month < 10 ? "0" + month : String.valueOf(month)) + 
               (day < 10 ? "0" + day : String.valueOf(day));
    }
}

IProfileDataService ProfileData=app.getRuntimeService(IProfileDataService.class);
IProfileProtocolService ProtocolService=app.getRuntimeService(IProfileProtocolService.class);

import com.tencent.mobileqq.troop.clockin.handler.TroopClockInHandler;
import com.tencent.mobileqq.troop.api.ITroopInfoService;
// 这个打卡Api写的我累死了啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊，改进自🥶🐔，添加了无数种查找方法
public boolean CheckSign(String qun, String uin) {
try {
    TroopClockInHandler inHandler;
    try {
        inHandler = new TroopClockInHandler(app);
    } catch(Exception e) {
        try {
            inHandler = new TroopClockInHandler();
        } catch(Exception ex) {
            Toast("创建处理器失败");
            return false;
        }
    }
    
    // 查找打卡方法
    Method targetMethod = null;
    Method[] allMethods = TroopClockInHandler.class.getDeclaredMethods();
    
    Class[][] paramTypeCombos = {
        new Class[] { String.class, String.class, int.class, boolean.class },
        new Class[] { String.class, String.class },
        new Class[] { String.class, String.class, int.class },
        new Class[] { String.class },
        new Class[] { long.class, long.class },
        new Class[] { String.class, long.class }
    };
    
    for (Class[] paramTypes : paramTypeCombos) {
        for (Method m : allMethods) {
            Class[] params = m.getParameterTypes();
            if (params.length != paramTypes.length) {
                continue;
            }
            
            boolean match = true;
            for (int i = 0; i < paramTypes.length; i++) {
                // 类型兼容检查
                if (!params[i].equals(paramTypes[i]) && 
                    !params[i].isAssignableFrom(paramTypes[i]) &&
                    !isPrimitiveWrapperPair(params[i], paramTypes[i])) {
                    match = false;
                    break;
                }
            }
            
            if (match) {
                targetMethod = m;
                break;
            }
        }
        if (targetMethod != null) {
            break;
        }
    }
    
    if (targetMethod == null) {
        String[] methodNames = {"doClockIn", "reportClockIn", "submitClockIn", "clockIn", "execClockIn", "onClockIn"};
        for (String name : methodNames) {
            for (Method m : allMethods) {
                if (m.getName().equals(name)) {
                    targetMethod = m;
                    break;
                }
            }
            if (targetMethod != null) {
                break;
            }
        }
    }
    
    if (targetMethod == null) {
        for (Method m : allMethods) {
            Class[] params = m.getParameterTypes();
            if (params.length >= 2) {
                String p0 = params[0].getName();
                String p1 = params[1].getName();
                if ((p0.contains("String") || p0.contains("Long")) && 
                    (p1.contains("String") || p1.contains("Long"))) {
                    targetMethod = m;
                    break;
                }
            }
        }
    }
    
    if (targetMethod != null) {
        try {
            targetMethod.setAccessible(true);
            
            // 构建参数
            Class[] params = targetMethod.getParameterTypes();
            Object[] args = new Object[params.length];
            
            for (int i = 0; i < params.length; i++) {
                String pname = params[i].getName();
                
                if (i == 0) {
                    if (pname.contains("Long")) {
                        args[i] = Long.parseLong(qun);
                    } else {
                        args[i] = qun;
                    }
                } else if (i == 1) {
                    if (pname.contains("Long")) {
                        args[i] = Long.parseLong(uin);
                    } else {
                        args[i] = uin;
                    }
                } else if (pname.contains("int") || pname.contains("Integer")) {
                    args[i] = 0;
                } else if (pname.contains("boolean") || pname.contains("Boolean")) {
                    args[i] = true;
                } else if (pname.contains("long") || pname.contains("Long")) {
                    args[i] = 0L;
                } else {
                    args[i] = null;
                }
            }
            
            targetMethod.invoke(inHandler, args);
            return true;
        } catch(Exception e) {
            Toast("调用失败: " + e.getMessage());
            return false;
        }
    } else {
        Toast("未找到打卡方法");
        return false;
    }
    } catch(Exception e) {
    // log(""+e);
    Toast(""+e);
    }
}

private boolean isPrimitiveWrapperPair(Class a, Class b) {
    return (a == Integer.class && b == int.class) ||
           (a == int.class && b == Integer.class) ||
           (a == Boolean.class && b == boolean.class) ||
           (a == boolean.class && b == Boolean.class) ||
           (a == Long.class && b == long.class) ||
           (a == long.class && b == Long.class) ||
           (a == String.class && b == CharSequence.class) ||
           (a == CharSequence.class && b == String.class);
}

import com.tencent.mobileqq.transfile.TransferRequest;
import com.tencent.mobileqq.transfile.api.ITransFileController;
import com.tencent.mobileqq.app.BaseApplicationImpl;
//无心 由ᗜ×ᗜ适配本脚本，你直接搬可能会遇到bug哦～
boolean 上传头像(String path)
{
// toast ("111");
try{
    ITransFileController control = app.getApplication().getRuntime().getRuntimeService(ITransFileController.class);
    TransferRequest transferRequest = new TransferRequest();
    transferRequest.mIsUp = true;
    transferRequest.mLocalPath = path;
    transferRequest.mFileType = 22;
    boolean transferAsync=control.transferAsync(transferRequest);
    return transferAsync;
    // toast("调用了上传头像");
                } catch (e) {
                return false ;
}
}

//来自🥶🐔的群头像上传和...
public boolean uploadCover(String path)
{
    ITransFileController control = BaseApplicationImpl.getApplication().getRuntime().getRuntimeService(ITransFileController.class);
    TransferRequest transferRequest = new TransferRequest();
    transferRequest.mIsUp = true;
    transferRequest.mLocalPath = path;
    transferRequest.mFileType = 35;
    boolean transferAsync=control.transferAsync(transferRequest);
    return transferAsync;
}
public boolean uploadTroopAvatar(String qun,String path)
{
    ITransFileController control = BaseApplicationImpl.getApplication().getRuntime().getRuntimeService(ITransFileController.class);
    TransferRequest transferRequest = new TransferRequest();
    transferRequest.mIsUp = true;
    transferRequest.mLocalPath = path;
    transferRequest.mFileType = 24;
    transferRequest.mPeerUin = qun;
    boolean transferAsync=control.transferAsync(transferRequest);
    return transferAsync;
}
import com.tencent.mobileqq.app.BaseActivity;
import com.tencent.mobileqq.troop.avatar.TroopPhotoController;
public boolean UploadTroopPhoto(String qun,String filepath) {
    boolean a = false;
    BaseActivity.sTopActivity.runOnUiThread(new Runnable() {
        public void run() {
            TroopAvatarActivity=new TroopAvatarWallEditActivity();
            Bundle bundle = new Bundle();
            bundle.putString("troopUin", qun);
            bundle.putInt("type", 1);
            TroopPhotoController troopPhotoController = new TroopPhotoController(context,TroopAvatarActivity, app,bundle);
            String tt=QRoute.api(ITroopPhotoUtilsApi.class).getClipStr(0,0,0,0);
            a=troopPhotoController.E(filepath,tt);
        }
    }
    );
    return a;
}
//上传群封面
import com.tencent.mobileqq.troop.avatar.TroopAvatarController;
import com.tencent.mobileqq.troop.avatar.api.ITroopPhotoUtilsApi;
import com.tencent.mobileqq.troop.activity.TroopAvatarWallEditActivity;
TroopAvatarWallEditActivity TroopAvatarActivity;
public boolean UploadTroopAvatar(String qun,String filepath) {
    boolean a = false;
    BaseActivity.sTopActivity.runOnUiThread(new Runnable() {
        public void run() {
            TroopAvatarActivity=new TroopAvatarWallEditActivity();
            Bundle bundle = new Bundle();
            bundle.putString("troopUin", qun);
            bundle.putInt("type", 1);
            TroopAvatarController troopAvatarController = new TroopAvatarController(context,TroopAvatarActivity, app,bundle);
            String tt=QRoute.api(ITroopPhotoUtilsApi.class).getClipStr(0,0,0,0);
            a=troopAvatarController.E(filepath,tt);
        }
    }
    );
    return a;
}



public Object GetCard(String uin){
ProfileData.onCreate(app);
Object card=ProfileData.getProfileCard(uin,false);
if(card==null||card.iQQLevel==null)
{
Bundle bundle =new Bundle();
bundle.putLong("selfUin",Long.parseLong(myUin));
bundle.putLong("targetUin",Long.parseLong(uin));
bundle.putInt("comeFromType",12);
ProtocolService.requestProfileCard(bundle);
return ProfileData.getProfileCard(uin,false);
}
else return card;
}
import com.tencent.mobileqq.troop.api.ITroopInfoService;
import com.tencent.mobileqq.data.troop.TroopInfo;

public TroopInfo findTroopInfo(String qun){
Object app = BaseApplicationImpl.getApplication().getRuntime();
ITroopInfoService Info = app.getRuntimeService(ITroopInfoService.class);
return Info.findTroopInfo(""+qun);
}

/*
Card card=GetCard(at);
//card.backgroundUrl QQ名片背景
//card.strNick 昵称
//card.iQQLevel QQ等级
//card.iQQVipLevel QQ会员等级
//card.iSuperVipLevel 超级QQ会员等级
//card.isForbidAccount 是否被封禁
//card.lVoteCount 名片赞
//card.lLoginDays 登录天数
//card.qid QID
TroopInfo info=findTroopInfo(qun);
//进群问题:info.joinTroopQuestion
//进群答案:info.joinTroopAnswer
//创建时间info.troopCreateTime
//群名info.troopname
//群主info.troopowneruin
//最大人数info.wMemberMax
//当前人数info.wMemberNum
Friends friend=GetFriendCard(at);
//card.remark 备注

*/


//图片类工具，由伊志平开发，由ᗜ×ᗜ适配本脚本并规范，不可直接搬运，因为适配性等未知问题

// 从路径/URL加载Bitmap（网络/本地）
Bitmap getbitmap(String path) {
    InputStream stream = null;
    try {
        if (path.startsWith("http")) {
            URL url1 = new URL(path);
            HttpURLConnection urlc = url1.openConnection();
            stream = urlc.getInputStream();
            Bitmap bmp = BitmapFactory.decodeStream(stream).copy(Bitmap.Config.ARGB_8888, true);
            return bmp;
        } else {
            stream = new FileInputStream(path);
            Bitmap bmp = BitmapFactory.decodeStream(stream).copy(Bitmap.Config.ARGB_8888, true);
            return bmp;
        }
    } catch (Throwable e) {
        traceLog("api_log.txt", "加载失败: " + e.getMessage());
        Toast("图片加载错误: " + e.getMessage());
        return Bitmap.createBitmap(800, 800, Bitmap.Config.ARGB_8888);
    } finally {
        if (stream != null) {
            try {
                stream.close();
            } catch (Throwable closeE) {
                traceLog("api_log.txt", "流关闭失败: " + closeE.getMessage());
            }
        }
    }
}

// 生成圆角Bitmap
Bitmap getroundbmp(Bitmap bitmap, float roundPx) {
    try {
        Bitmap bmp = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bmp);
        Paint paint = new Paint();
        Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
        RectF rectF = new RectF(rect);
        paint.setAntiAlias(true);
        canvas.drawRoundRect(rectF, roundPx, roundPx, paint);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(bitmap, rect, rect, paint);
        return bmp;
    } catch (Throwable e) {
        traceLog("api_log.txt", "圆角处理失败: " + e.getMessage());
        return bitmap;
    }
}

// Bitmap保存到文件
void bmptofile(Bitmap bmp, String path) {
    FileOutputStream fs = null;
    try {
        if (bmp == null) throw new IllegalArgumentException("Bitmap为空");
        
        File f = new File(path);
        if (f.exists()) f.delete();
        if (!f.getParentFile().exists()) f.getParentFile().mkdirs();
        
        fs = new FileOutputStream(path);
        bmp.compress(Bitmap.CompressFormat.PNG, 100, fs);
        fs.flush();
        
        traceLog("api_log.txt", "图片已保存: " + path);
    } catch (Throwable e) {
        traceLog("api_log.txt", "保存失败: " + e.getMessage());
        Toast("保存失败: " + e.getMessage());
    } finally {
        if (fs != null) {
            try {
                fs.close();
            } catch (Throwable closeE) {
                traceLog("api_log.txt", "文件流关闭失败: " + closeE.getMessage());
            }
        }
    }
}

// URL下载图片（异步）
void urltofile(final String url, final String path) {
    // ThreadPool.execute(new Runnable() {
        // public void run() {
            try {
                Bitmap bmp = getbitmap(url);
                bmptofile(bmp, path);
            } catch (Throwable e) {
                traceLog("api_log.txt", "下载失败: " + e.getMessage());
            }
        // }
    // });
}

// 缩放图片（异步）
void fsdx(final String path1, final String path, final Object a, final Object b) {
    ThreadPool.execute(new Runnable() {
        public void run() {
            try {
                Bitmap bm1 = getbitmap(path1);
                Matrix ma = new Matrix();
                float w = ((Number) a).floatValue();
                float h = ((Number) b).floatValue();
                ma.postScale(w, h);
                Bitmap bmp = Bitmap.createBitmap(bm1, 0, 0, bm1.getWidth(), bm1.getHeight(), ma, true);
                
                String savePath = ("".equals(path) || path == null) ? path1 : path;
                bmptofile(bmp, savePath);
            } catch (Throwable e) {
                traceLog("api_log.txt", "缩放失败: " + e.getMessage());
            }
        }
    });
}

// 叠加图片（异步）
void pinpic(final String path1, final String path2, final Object sw, final Object sh, 
            final Object x, final Object y, final Object yd, final String path) {
    ThreadPool.execute(new Runnable() {
        public void run() {
            try {
                Bitmap bm1 = getbitmap(path1);
                Bitmap bm2 = getbitmap(path2);
                
                float a = ((Number) sw).floatValue() * ((float) bm1.getWidth() / (float) bm2.getWidth());
                float b = ((Number) sh).floatValue() * ((float) bm1.getHeight() / (float) bm2.getHeight());
                
                Matrix ma = new Matrix();
                if (((Number) sw).floatValue() > 998 || ((Number) sh).floatValue() > 998) {
                    float i = Math.min(a, b);
                    ma.postScale(i, i);
                } else {
                    ma.postScale(a, b);
                }
                
                Bitmap zmp = Bitmap.createBitmap(bm2, 0, 0, bm2.getWidth(), bm2.getHeight(), ma, true);
                float x1 = ((Number) x).floatValue() * bm1.getWidth() - 0.5f * zmp.getWidth();
                float y1 = ((Number) y).floatValue() * bm1.getHeight() - 0.5f * zmp.getHeight();
                Bitmap smp = getroundbmp(zmp, ((Number) yd).floatValue());
                
                Canvas cas = new Canvas(bm1);
                cas.drawBitmap(smp, x1, y1, null);
                
                String savePath = ("".equals(path) || path == null) ? path1 : path;
                bmptofile(bm1, savePath);
            } catch (Throwable e) {
                traceLog("api_log.txt", "叠加失败: " + e.getMessage());
            }
        }
    });
}

// 写入文字（异步）
void writetopic(final String path1, final String text, final String color, 
                final Object x, final Object y, final Object size, final String path) {
    ThreadPool.execute(new Runnable() {
        public void run() {
            try {
                Bitmap bmp = getbitmap(path1);
                Canvas cas = new Canvas(bmp);
                Paint pt = new Paint();
                pt.setTextSize(((Number) size).floatValue());
                pt.setTypeface(Typeface.MONOSPACE);
                if (color != null && !"".equals(color)) {
                    pt.setColor(Color.parseColor(color));
                }
                
                float x1 = ((Number) x).floatValue() * bmp.getWidth() - 0.5f * text.length() * ((Number) size).floatValue();
                float y1 = ((Number) y).floatValue() * bmp.getHeight() + 0.5f * ((Number) size).floatValue();
                
                cas.drawText(text, x1, y1, pt);
                
                String savePath = ("".equals(path) || path == null) ? path1 : path;
                bmptofile(bmp, savePath);
            } catch (Throwable e) {
                traceLog("api_log.txt", "文字写入失败: " + e.getMessage());
            }
        }
    });
}

// 叠加QQ头像（异步）
void pinqpic(final String path1, final String qq, final Object sw, final Object sh, 
             final Object x, final Object y, final Object yd, final String path) {
    ThreadPool.execute(new Runnable() {
        public void run() {
            String qqUrl = "http://q1.qlogo.cn/g?b=qq&nk=" + qq + "&s=640";
            pinpic(path1, qqUrl, sw, sh, x, y, yd, path);
        }
    });
}


//  JSON解析工具  开发者:如如 改进:荨宝（有人记得这个人吗，其实就是ᗜ×ᗜ哦，嘻嘻）
//  必须配合org.json.JSONObject使用

public String jiexi(org.json.JSONObject json, String tag) {
    String result = "";
    for(String str : json.keySet()){
       result += "\n" + jiexi(json.get(str), str, tag);
    }
    return result;
}

public String jiexi(org.json.JSONObject json, String name, String tag) {
    String newTag = tag + "_" + name;
    if(!name.equals("h")) name = "\"" + name + "\"";
    String result = "\nJSONObject "+ newTag + " = " + tag + ".getJSONObject(" + name + ");\n";
    for(String str : json.keySet())
    {
         result += "\n" + jiexi(json.get(str), str, newTag);
    }
    return result;
}

public String jiexi(org.json.JSONArray json, String name, String tag) {
    String newTag = tag + "_" + name;
    if(!name.equals("h")) name = "\"" + name + "\"";
    int length = json.length();
    if(length > 0) return "\nJSONArray "+ newTag + " = " + tag + ".getJSONArray(" + name + ");\nfor(int h = 0; h < " + newTag + ".length(); h++)\n{\n   " + jiexi(json.get(0), "h", newTag) +"\n}";
    else return "//" + newTag+"没有数据\n";
}

public String jiexi(Object object, String name, String tag) {
    String newTag = tag + "_" + name;
    if(!name.equals("h")) name = "\"" + name + "\"";
    if(object instanceof Integer) return "\nInteger " + newTag + " = " + tag + ".getInt(" + name + ");//→" + object;
    else if(object instanceof Long) return "\nLong " + newTag + " = " + tag + ".getLong(" + name + ");//→" + object;
    else if(object instanceof Double) return "\nDouble " + newTag + " = " + tag + ".getDouble(" + name + ");//→" + object;
    else if(object instanceof Boolean) return "\nBoolean " + newTag + " = " + tag + ".getBoolean(" + name + ");//→" + object;
    else if(object instanceof String) return "\nString " + newTag + " = " + tag + ".getString(" + name + ");//→\"" + object + "\"";
    else return "\nObject "+ newTag + " = " + tag + ".get(" + name + ");//→" + object;
}

import java.util.Stack;

    public static String formatObjectString(String input) {
        if (input == null || input.isEmpty()) {
            return input;
        }
        
        List<String> lines = new ArrayList<>();
        StringBuilder currentLine = new StringBuilder();
        int indentLevel = 0;
        Stack<Character> braceStack = new Stack<>();
        
        // 状态标记
        boolean inQuotes = false;
        char quoteChar = '\0';
        boolean escapeNext = false;
        
        // 第一步：智能分割
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            
            // 处理转义
            if (escapeNext) {
                currentLine.append(c);
                escapeNext = false;
                continue;
            }
            
            if (c == '\\') {
                currentLine.append(c);
                escapeNext = true;
                continue;
            }
            
            // 处理引号
            if (c == '"' || c == '\'' || c == '`') {
                if (!inQuotes) {
                    inQuotes = true;
                    quoteChar = c;
                } else if (c == quoteChar) {
                    inQuotes = false;
                    quoteChar = '\0';
                }
                currentLine.append(c);
                continue;
            }
            
            if (!inQuotes) {
                // 处理括号和方括号
                if (c == '{' || c == '[' || c == '(') {
                    // 如果当前行有内容，先添加到lines
                    if (currentLine.length() > 0) {
                        String lineStr = currentLine.toString().trim();
                        if (!lineStr.isEmpty()) {
                            lines.add(getIndent(indentLevel) + lineStr);
                        }
                        currentLine.setLength(0);
                    }
                    
                    // 添加开括号
                    lines.add(getIndent(indentLevel) + c);
                    indentLevel++;
                    
                    // 对于大括号，检查是否是空对象
                    int j = i + 1;
                    while (j < input.length() && Character.isWhitespace(input.charAt(j))) {
                        j++;
                    }
                    if (j < input.length() && input.charAt(j) == getClosingChar(c)) {
                        // 空对象/数组，放在同一行
                        lines.set(lines.size() - 1, getIndent(indentLevel - 1) + c + getClosingChar(c));
                        i = j; // 跳过闭合括号
                        indentLevel--;
                    } else {
                        braceStack.push(c);
                    }
                    continue;
                }
                
                if (c == '}' || c == ']' || c == ')') {
                    // 添加当前行内容（如果有）
                    if (currentLine.length() > 0) {
                        String lineStr = currentLine.toString().trim();
                        if (!lineStr.isEmpty()) {
                            lines.add(getIndent(indentLevel) + lineStr);
                        }
                        currentLine.setLength(0);
                    }
                    
                    // 处理缩进
                    if (!braceStack.isEmpty()) {
                        char opening = braceStack.pop();
                        if (c != getClosingChar(opening)) {
                            // 括号不匹配，直接添加
                            lines.add(getIndent(indentLevel) + c);
                        } else {
                            indentLevel--;
                            lines.add(getIndent(indentLevel) + c);
                        }
                    } else {
                        lines.add(getIndent(indentLevel) + c);
                    }
                    continue;
                }
                
                // 处理逗号：换行点
                if (c == ',') {
                    currentLine.append(c);
                    String lineStr = currentLine.toString().trim();
                    if (!lineStr.isEmpty()) {
                        lines.add(getIndent(indentLevel) + lineStr);
                    }
                    currentLine.setLength(0);
                    continue;
                }
                
                // 处理等号：添加空格
                if (c == '=') {
                    // 检查前面是否有空格，没有则添加
                    if (currentLine.length() > 0 && currentLine.charAt(currentLine.length() - 1) != ' ') {
                        currentLine.append(' ');
                    }
                    currentLine.append("= ");
                    continue;
                }
                
                // 正常字符
                currentLine.append(c);
            } else {
                // 在引号内
                currentLine.append(c);
            }
        }
        
        // 处理最后一行
        if (currentLine.length() > 0) {
            String lineStr = currentLine.toString().trim();
            if (!lineStr.isEmpty()) {
                lines.add(getIndent(indentLevel) + lineStr);
            }
        }
        
        // 第二步：美化调整
        return beautifyLines(lines);
    }
    
    /**
     * 获取缩进字符串
     */
    private static String getIndent(int level) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < level; i++) {
            sb.append("  ");
        }
        return sb.toString();
    }
    
    /**
     * 获取对应的闭合字符
     */
    private static char getClosingChar(char opening) {
        switch (opening) {
            case '{': return '}';
            case '[': return ']';
            case '(': return ')';
            default: return opening;
        }
    }
    
    /**
     * 美化行，调整对齐和格式
     */
    private static String beautifyLines(List<String> lines) {
        List<String> result = new ArrayList<>();
        
        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i);
            
            // 移除行尾的空白
            line = line.trim();
            
            // 检查是否是空行或只有括号的行
            if (line.isEmpty()) {
                continue;
            }
            
            // 处理行尾的逗号
            if (line.endsWith(",")) {
                result.add(line);
                continue;
            }
            
            // 检查是否需要添加逗号
            if (i < lines.size() - 1) {
                String nextLine = lines.get(i + 1).trim();
                
                // 如果当前行以}或]或)结尾，且下一行不是以这些字符开头
                if ((line.endsWith("}") || line.endsWith("]") || line.endsWith(")")) && 
                    !nextLine.isEmpty() && !nextLine.startsWith("}") && 
                    !nextLine.startsWith("]") && !nextLine.startsWith(")") &&
                    !nextLine.startsWith("]")) {
                    // 检查是否应该加逗号
                    char lastChar = line.charAt(line.length() - 1);
                    char nextFirstChar = nextLine.charAt(0);
                    if (lastChar != nextFirstChar && nextFirstChar != ',' && 
                        !Character.isDigit(nextFirstChar)) {
                        line = line + ",";
                    }
                }
                
                // 如果当前行是字段定义，且下一行不是以{开头，则加逗号
                if (line.contains(" = ") && !line.endsWith("{") && !line.endsWith("[") &&
                    !line.endsWith("}") && !line.endsWith("]") && !line.endsWith(")") &&
                    !line.endsWith(",") && !nextLine.trim().startsWith("}") &&
                    !nextLine.trim().startsWith("]") && !nextLine.trim().startsWith(")")) {
                    line = line + ",";
                }
            }
            
            // 对齐等号
            line = alignEquals(line, result);
            
            result.add(line);
        }
        
        // 构建最终结果
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < result.size(); i++) {
            sb.append(result.get(i));
            if (i < result.size() - 1) {
                sb.append("\n");
            }
        }
        
        return sb.toString();
    }
    
    /**
     * 对齐等号
     */
    private static String alignEquals(String line, List<String> previousLines) {
        if (!line.contains(" = ")) {
            return line;
        }
        
        // 计算等号的位置
        int eqIndex = line.indexOf(" = ");
        if (eqIndex < 20) { // 如果等号位置靠前，不需要对齐
            return line;
        }
        
        // 查找前几行中相似的等号位置
        int maxEqIndex = eqIndex;
        for (String prevLine : previousLines) {
            if (prevLine.contains(" = ")) {
                int prevEqIndex = prevLine.indexOf(" = ");
                if (prevEqIndex > maxEqIndex) {
                    maxEqIndex = prevEqIndex;
                }
            }
        }
        
        // 如果等号位置差异不大，不调整
        if (maxEqIndex - eqIndex < 4) {
            return line;
        }
        
        // 在字段名后添加空格以对齐等号
        String[] parts = line.split(" = ", 2);
        if (parts.length == 2) {
            String fieldName = parts[0];
            String value = parts[1];
            
            // 计算需要的空格数
            int spacesNeeded = maxEqIndex - fieldName.length();
            if (spacesNeeded > 0) {
                StringBuilder alignedLine = new StringBuilder(fieldName);
                for (int i = 0; i < spacesNeeded; i++) {
                    alignedLine.append(' ');
                }
                alignedLine.append("= ").append(value);
                return alignedLine.toString();
            }
        }
        
        return line;
    }
    



boolean 判断文件(String files){
    File file = new File(files);
    long totalBytes = file.length();
    if(totalBytes==0){
    return false;
    }else{
    return true;
    }
}
public void 删除(String Path) {
    File file = null;
    try {
        file = new File(Path);
        if (file.exists()) {
            boolean deleted = file.delete();
        } else {
            traceLog("api_log.txt","文件不存在: " + Path);
        }
    } catch (Exception e) {
        traceLog("api_log.txt","删除文件时发生错误: " + e);
    }
}

private boolean 删除文件夹(File folder) {
    if (folder == null || !folder.isDirectory()) {
        return false;
    }

    File[] 子文件数组 = folder.listFiles();
    boolean 所有子项删除成功 = true;
    Exception 记录异常 = null;

    try {
        if (子文件数组 != null) {
            for (File 子项 : 子文件数组) {
                if (子项.isDirectory()) {
                    if (!删除文件夹(子项)) {
                        所有子项删除成功 = false;
                        traceLog("api_log.txt", "删除子文件夹失败: " + 子项.getAbsolutePath());
                    }
                } else {
                    if (!子项.delete()) {
                        所有子项删除成功 = false;
                        traceLog("api_log.txt", "删除文件失败: " + 子项.getAbsolutePath());
                    }
                }
            }
        }

        if (所有子项删除成功) {
            return folder.delete();
        } else {
            return false;
        }
    } catch (Exception e) {
        记录异常 = e;
        traceLog("api_log.txt", "删除文件夹过程中异常: " + e);
        return false;
    } finally {
        if (记录异常 != null) {
            traceLog("api_log.txt", "删除文件夹: 未完全删除" + 记录异常);
        }
    }
}


String formatTime(float time)
{
    String suffix = "豪秒";
    long seconds = (long)(time / 1000);
    String tr = seconds / 3600 + "时" + (seconds % 3600) / 60 + "分" + seconds % 3600 % 60 % 60 + "秒";
    tr = tr.replace("分0秒", "分");
    tr = tr.replace("时0分", "时");
    tr = tr.replace("0时", "");
    return tr;
}
String formatSize(long bytes) {
    if (bytes <= 0) return "0B";
    String[] units = new String[]{"B", "KB", "MB", "GB", "TB"};
    int digitGroups = (int) (Math.log10(bytes) / Math.log10(1024));
    StringBuffer result = new StringBuffer();
    result.append(new java.text.DecimalFormat("#,##0.##").format(bytes / Math.pow(1024, digitGroups)));
    result.append(units[digitGroups]);
    return result.toString();
}
// 基础文件大小获取 - 无外部依赖
long getFileSize(File file) {
    if (file == null) {
        traceLog("api_log.txt","getFileSize参数为null");
        return 0;
    }
    try {
        return file.length();
    } catch (Exception e) {
        traceLog("api_log.txt","获取文件大小失败: " + file.getName() + "    " + e);
        return 0;
    }
}

// 递归文件夹大小计算 - 依赖getFileSize
long getFolderSize(File folder) {
    if (folder == null || !folder.exists()) {
        traceLog("api_log.txt","getFolderSize文件夹不存在: " + folder);
        return 0;
    }
    long size = 0;
    try {
        File[] files = folder.listFiles();
        if (files != null) {
            for (int i = 0; i < files.length; i++) {
                File file = files[i];
                if (file.isFile()) {
                    size += getFileSize(file);
                } else if (file.isDirectory()) {
                    size += getFolderSize(file);
                }
            }
        }
    } catch (Exception e) {
        traceLog("api_log.txt","遍历文件夹失败: " + folder.getName() + "    " + e);
    }
    return size;
}

// 字节数格式化 - 无外部依赖
String getFormattedSize(long sizeInBytes) {
    if (sizeInBytes < 0) {
        traceLog("api_log.txt","getFormattedSize接收负值: " + sizeInBytes);
        return "0KB";
    }
    
    double sizeInKB = sizeInBytes / 1024.0;
    
    if (sizeInKB < 1024) {
        return String.format("%.3fKB", sizeInKB);
    } else if (sizeInKB < 1048576) { // 1024*1024
        double sizeInMB = sizeInKB / 1024.0;
        return String.format("%.3fMB", sizeInMB);
    } else {
        double sizeInGB = sizeInKB / 1048576.0;
        return String.format("%.3fGB", sizeInGB);
    }
}

// 文件夹对象格式化 - 依赖getFolderSize和getFormattedSize(long)
String getFormattedSize(File folder) {
    if (folder == null) {
        traceLog("api_log.txt","getFormattedSize(File)参数为null");
        return "文件夹不存在";
    }
    if (!folder.exists()) {
        traceLog("api_log.txt","文件夹不存在: " + folder.getAbsolutePath());
        return "文件夹不存在";
    }
    if (!folder.isDirectory()) {
        traceLog("api_log.txt","路径不是文件夹: " + folder.getAbsolutePath());
        return "不是有效文件夹";
    }
    
    try {
        long sizeInBytes = getFolderSize(folder);
        if (sizeInBytes == 0) {
            return "0KB";
        }
        return getFormattedSize(sizeInBytes);
    } catch (Exception e) {
        traceLog("api_log.txt","格式化文件夹大小失败: " + folder.getName() + "    " + e);
        return "计算失败";
    }
}
public String 读(String FilePath) {
    if (FilePath == null || FilePath.trim().isEmpty()) {
        return "读文件失败：文件路径为空";
    }
    InputStreamReader inputReader = null;
    BufferedReader bf = null;
    try {
        File file = new File(FilePath);
        if (!file.exists()) {
            if (file.createNewFile()) {
                return ""; // 新建空文件，返回空字符串
            } else {
                return "读文件失败：文件不存在且创建失败，路径：" + FilePath;
            }
        }
        if (file.isDirectory()) {
            return "读文件失败：路径指向目录，无法读取，路径：" + FilePath;
        }
        if (!file.canRead()) {
            return "读文件失败：文件无读取权限，路径：" + FilePath;
        }

        inputReader = new InputStreamReader(new FileInputStream(file), "UTF-8");
        bf = new BufferedReader(inputReader);
        StringBuilder sb = new StringBuilder();
        String str;

        while ((str = bf.readLine()) != null) {
            sb.append(str).append("\n"); // 每行结尾添加换行符，还原文件原始换行
        }
        return sb.toString();

    } catch (Exception e) {
        String errorMsg = "读文件失败：路径=" + FilePath + "，异常=" + e.getMessage();
        return errorMsg;
    } finally {
        try {
            if (bf != null) {
                bf.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            if (inputReader != null) {
                inputReader.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

String readprop(String file, String name2) {
    if (file == null || name2 == null) {
        traceLog("api_log.txt","readprop接收null参数: file=" + file + ", key=" + name2);
        return "";
    }
    
    String text = null;
    try {
        text = 读(file);
        if (text == null || text.trim().isEmpty()) {
            traceLog("api_log.txt","properties文件内容为空: " + file);
            return "";
        }
    } catch (Exception e) {
        traceLog("api_log.txt","读取properties文件失败: " + file + "    " + e);
        return "";
    }
    
    Properties props = new Properties();
    StringReader reader = null;
    try {
        reader = new StringReader(text);
        props.load(reader);
        String value = props.getProperty(name2);
        if (value == null) {
            traceLog("api_log.txt","properties键不存在: " + name2 + " in " + file);
            return "";
        }
        return value;
    } catch (IOException e) {
        traceLog("api_log.txt","Properties加载失败: " + file + "    " + e);
        return "";
    } catch (Exception e) {
        traceLog("api_log.txt","Properties解析异常: " + file + "    " + e);
        return "";
    } finally {
        // 资源释放保护
        if (reader != null) {
            try {
                reader.close();
            } catch (Exception e) {
                // 关闭异常不处理，避免掩盖主异常
            }
        }
    }
}


private void 写(String Path, String WriteData) {
    if (Path == null || Path.trim().isEmpty()) {
        traceLog("api_log.txt"," 【写入失败】路径为空");
        return;
    }
    
    FileOutputStream fos = null;
    OutputStreamWriter osw = null;
    
    try {
        File file = new File(Path);
        File parentDir = file.getParentFile();
        
        // 确保父目录存在
        if (parentDir != null && !parentDir.exists()) {
            if (!parentDir.mkdirs()) {
                traceLog("api_log.txt"," 【写入失败】创建目录失败: " + parentDir.getAbsolutePath());
                return;
            }
        }
        
        // 创建文件（如果不存在）
        if (!file.exists() && !file.createNewFile()) {
            traceLog("api_log.txt"," 【写入失败】创建文件失败: " + Path);
            return;
        }
        
        // 写入数据（使用UTF-8编码）
        fos = new FileOutputStream(file);
        osw = new OutputStreamWriter(fos, StandardCharsets.UTF_8);
        osw.write(WriteData);
        osw.flush();
        fos.flush();
        fos.getFD().sync(); // 确保数据持久化到磁盘
        
        traceLog("api_log.txt"," 【写入成功】 " + Path + " (" + WriteData.length() + "字节)");
        
    } catch (IOException e) {
        traceLog("api_log.txt"," 【写入异常】 " + Path + " - " + e.getMessage());
    } catch (Exception e) {
        traceLog("api_log.txt"," 【写入异常】 " + Path + " - " + e.getMessage());
    } finally {
        // 在finally中关闭流
        try {
            if (osw != null) {
                osw.close();
            }
        } catch (Exception e) {
            traceLog("api_log.txt"," 【关闭writer失败】 " + e.getMessage());
        }
        
        try {
            if (fos != null) {
                fos.close();
            }
        } catch (Exception e) {
            traceLog("api_log.txt"," 【关闭stream失败】 " + e.getMessage());
        }
    }
}


    private void 新建(String Path) {
        File dir = new File(Path);
        if (!dir.exists()) {
            dir.mkdirs();
        }
    }
    private String readFileContent(String filePath) throws Exception {
        File file = new File(filePath);
        if (!file.exists()) {
            return "文件不存在";
        }
        InputStreamReader inputReader = new InputStreamReader(new FileInputStream(file));
        BufferedReader bf = new BufferedReader(inputReader);
        StringBuilder sb = new StringBuilder();
        String str;
        while ((str = bf.readLine()) != null) {
            sb.append(str);
        }
        bf.close();
        inputReader.close();
        return sb.toString();
    }

public void log大小限制(String Path) {
    File targetFile = new File(Path);
    try {
        if (!targetFile.exists()) {
            traceLog("api_log.txt", "文件夹不存在: " + Path);
            return;
        }
        if (!targetFile.isDirectory()) {
            traceLog("api_log.txt", "目标路径不是文件夹: " + Path);
            return;
        }

        long 文件夹总大小 = getFolderSize(targetFile);
        long MB = 1024 * 1024;

        if (文件夹总大小 > MB) {
            traceLog("api_log.txt", "文件夹总大小超过1MB，准备删除: " + targetFile.getName() 
                    + " (" + 文件夹总大小 + " 字节)");
            
            boolean 删除成功 = 删除文件夹(targetFile);
            if (删除成功) {
                traceLog("api_log.txt", "成功删除文件夹: " + Path);
            } else {
                traceLog("api_log.txt", "删除文件夹失败: " + Path);
            }
        }
    } catch (Exception e) {
        traceLog("api_log.txt", "处理log文件夹时出错: " + e);
    }
}

void 菜单(Object data) {
    if (!延迟启动完成) {
        traceLog("api_log.txt","菜单调用时延迟启动未完成");
        return;
    }
    
    Activity activity = getNowActivity();
    if (activity == null) activity = 最后Activity;
    if (activity == null) {
        traceLog("api_log.txt","菜单调用时无法获取Activity");
        return;
    }
    
    final Activity finalActivity = activity;
    activity.runOnUiThread(new Runnable() {
        public void run() {
            if (finalActivity != null && !finalActivity.isFinishing()) {
                traceLog("api_log.txt","开始显示菜单");
                长按消息菜单(finalActivity,data);
            } else {
                traceLog("api_log.txt","菜单已显示或Activity无效");
            }
        }
    });
}
public void setTips(String title, String message) {
    Activity ThisActivity = getNowActivity();
    ThisActivity.runOnUiThread(new Runnable() {
        public void run() {
            boolean isDark = isThemeDark(ThisActivity);
            
            // TextView优化配置
            TextView textView = new TextView(ThisActivity);
            textView.setText(message);
            textView.setTextSize(17);
            textView.setTextColor(isDark ? UI_COLOR_TEXT_DARK : UI_COLOR_TEXT_LIGHT);
            textView.setTextIsSelectable(true);
            textView.setHorizontallyScrolling(false); // 禁用水平滚动，启用自动换行
            
            //  ScrollView包裹解决滑动性能问题
            ScrollView scrollView = new ScrollView(ThisActivity);
            scrollView.setFillViewport(true);
            scrollView.addView(textView);
            
            // 布局容器：遵循宪章3.3节尺寸约束（最大360dp宽度，左右20dp边距）
            LinearLayout layout = new LinearLayout(ThisActivity);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(dp(20), dp(20), dp(20), dp(20)); // 20dp边距
            
            // 设置布局参数：宽度360dp，高度自适应
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                dp转px(ThisActivity, 320), // 宽度320dp（360dp减去左右边距）
                LinearLayout.LayoutParams.WRAP_CONTENT
            );
            layout.setLayoutParams(layoutParams);
            layout.addView(scrollView);
            
            // 创建并显示弹窗
            AlertDialog.Builder builder = new AlertDialog.Builder(ThisActivity, 
                isDark ? AlertDialog.THEME_DEVICE_DEFAULT_DARK : AlertDialog.THEME_DEVICE_DEFAULT_LIGHT);
                
            builder.setTitle(title)
                .setView(layout)
                .setNegativeButton("关闭", null);
                
            AlertDialog dialog = builder.create();
            
            // 背景圆角
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(Color.parseColor(isDark ? UI_COLOR_BG_DARK : UI_COLOR_BG_LIGHT));
            bg.setCornerRadius(dp(ThisActivity, 16));
            dialog.getWindow().setBackgroundDrawable(bg);
            
            dialog.show();
        }
    });
}

public void showTitleDialog(final Activity activity, final String qun, final String uin) {
    activity.runOnUiThread(new Runnable() {
        public void run() {
            try {
                boolean isDark = isThemeDark(activity);
                
                // 主容器
                LinearLayout root = new LinearLayout(activity);
                root.setOrientation(LinearLayout.VERTICAL);
                root.setPadding(dp(activity, 12), dp(activity, 16), dp(activity, 12), dp(activity, 12));
                
                // 标题
                TextView titleView = new TextView(activity);
                titleView.setText("设置头衔");
                titleView.setTextSize(16);
                titleView.setTypeface(null, Typeface.BOLD);
                titleView.setTextColor(isDark ? UI_COLOR_TEXT_DARK : UI_COLOR_TEXT_LIGHT);
                titleView.setPadding(0, 0, 0, dp(activity, 12));
                root.addView(titleView);
                
                // 输入框
                final EditText input = new EditText(activity);
                input.setHint("请输入头衔名称");
                input.setHintTextColor(isDark ? UI_COLOR_SUBTEXT_DARK : UI_COLOR_SUBTEXT_LIGHT);
                input.setTextColor(isDark ? UI_COLOR_TEXT_DARK : UI_COLOR_TEXT_LIGHT);
                input.setTextSize(14);
                input.setPadding(dp(activity, 10), dp(activity, 8), dp(activity, 10), dp(activity, 8));
                
                GradientDrawable inputBg = new GradientDrawable();
                inputBg.setCornerRadius(dp(activity, 6));
                inputBg.setColor(isDark ? UI_COLOR_INPUT_BG_DARK : UI_COLOR_INPUT_BG_LIGHT);
                inputBg.setStroke(dp(activity, 1), isDark ? UI_COLOR_STROKE_DARK : UI_COLOR_STROKE_LIGHT);
                input.setBackground(inputBg);
                root.addView(input);
                
                // 按钮容器
                LinearLayout btnBox = new LinearLayout(activity);
                btnBox.setOrientation(LinearLayout.HORIZONTAL);
                btnBox.setPadding(0, dp(activity, 16), 0, 0);
                btnBox.setGravity(Gravity.RIGHT);
                
                // 取消按钮
                TextView cancel = new TextView(activity);
                cancel.setText("取消");
                cancel.setTextSize(14);
                cancel.setTextColor(isDark ? UI_COLOR_SUBTEXT_DARK : UI_COLOR_SUBTEXT_LIGHT);
                cancel.setPadding(dp(activity, 12), dp(activity, 8), dp(activity, 12), dp(activity, 8));
                cancel.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });
                
                // 确定按钮
                TextView confirm = new TextView(activity);
                confirm.setText("确定");
                confirm.setTextSize(14);
                confirm.setTextColor(isDark ? UI_COLOR_ACCENT_DARK : UI_COLOR_ACCENT_LIGHT);
                confirm.setPadding(dp(activity, 12), dp(activity, 8), dp(activity, 12), dp(activity, 8));
                confirm.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        String title = input.getText().toString().trim();
                        dialog.dismiss();
                        if (!title.equals("")) {
                            setGroupMemberTitle(qun, uin, title);
                            Toast("头衔设置成功");
                            vibrate(activity, 32);
                        }
                    }
                });
                
                btnBox.addView(cancel);
                btnBox.addView(confirm);
                root.addView(btnBox);
                
                // 构建对话框
                AlertDialog.Builder builder = new AlertDialog.Builder(activity, 
                    isDark ? AlertDialog.THEME_DEVICE_DEFAULT_DARK : AlertDialog.THEME_DEVICE_DEFAULT_LIGHT);
                builder.setView(root);
                final AlertDialog dialog = builder.create();
                
                // 样式设置
                dialog.getWindow().setBackgroundDrawable(new GradientDrawable() {{
                    setColor(Color.parseColor(isDark ? UI_COLOR_BG_DARK : UI_COLOR_BG_LIGHT));
                    setCornerRadius(dp(activity, 8));
                }});
                
                WindowManager.LayoutParams params = dialog.getWindow().getAttributes();
                params.width = Math.min(dp(activity, 280), 
                    activity.getResources().getDisplayMetrics().widthPixels - dp(activity, 40));
                dialog.getWindow().setAttributes(params);
                
                dialog.show();
                
            } catch (Exception e) {
                traceLog("api_log.txt", e.getMessage());
                Toast("弹窗显示失败");
            }
        }
    });
}
void 输入框提示开关() {
    Activity activity = getNowActivity();
    if (activity == null) activity = 最后Activity;
    final Activity finalActivity = activity;
    if (finalActivity == null) {
        return;
    }
    boolean 输入框开关 = !getBoolean("输入框", "输入框开关", false);
    putBoolean("输入框", "输入框开关", 输入框开关);
    vibrate(finalActivity, 48);
    
    if (输入框开关) {
        Toast("已开启输入框提示功能");
    } else {
        Toast("已关闭输入框提示功能");
    }
}
import me.yxp.qfun.utils.qq.HostInfo;

private Map getSendTypeMapping() {
    Map map = new HashMap();
    map.put("SendText", "文本");
    map.put("SendPic", "图片");
    map.put("SendFile", "文件");
    map.put("SendVideo", "视频");
    map.put("SendEmoji", "表情");
    map.put("SendAudio", "语音");
    map.put("SendCard", "卡片");
    map.put("SendCall", "通话");
    map.put("SendWordCount", "字数");
    map.put("Send", "总数"); // 添加总数匹配
    return map;
}

private Map getReceiveTypeMapping() {
    Map map = new HashMap();
    map.put("ReceiveText", "文本");
    map.put("ReceivePic", "图片");
    map.put("ReceiveFile", "文件");
    map.put("ReceiveVideo", "视频");
    map.put("ReceiveEmoji", "表情");
    map.put("ReceiveAudio", "语音");
    map.put("ReceiveCard", "卡片");
    map.put("ReceiveCall", "通话");
    map.put("ReceiveWordCount", "字数");
    map.put("Receive", "总数"); // 添加总数匹配
    return map;
}


private Map getAllVariablesMap(Object scriptScope) {
    Map map = new HashMap();

    // 自定义变量
    map.put("time", getTime());
    try { map.put("qq", String.valueOf(myUin)); } catch (Exception e) {}

    String rawTime = getTodayDateStr();
    String todayStr = "";
    if (rawTime.contains("-")) {
        todayStr = rawTime.split(" ")[0].replace("-", "");
    } else if (rawTime.contains("/")) {
        todayStr = rawTime.split(" ")[0].replace("/", "");
    } else {
        todayStr = rawTime.substring(0, 8);
    }
    
    Map SEND_TYPE_MAP = getSendTypeMapping();
    Map RECEIVE_TYPE_MAP = getReceiveTypeMapping();
    Enumeration keys = OP_STATS.keys();
    int matchCount = 0;
    int totalKeys = 0;
    
    while (keys.hasMoreElements()) {
        String key = (String) keys.nextElement();
        totalKeys++;
        Object val = OP_STATS.get(key);
        String valueStr = val != null ? String.valueOf(val) : "0";
        
        map.put(key, valueStr);
        String todayPrefix = "date_" + todayStr + "_";
        
        if (key.startsWith(todayPrefix)) {
            String suffix = key.substring(todayPrefix.length());
            
            if (SEND_TYPE_MAP.containsKey(suffix)) {
                String chineseType = (String) SEND_TYPE_MAP.get(suffix);
                String mappedKey = "今日发送" + chineseType;
                map.put(mappedKey, valueStr);
                matchCount++;
            }
            else if (RECEIVE_TYPE_MAP.containsKey(suffix)) {
                String chineseType = (String) RECEIVE_TYPE_MAP.get(suffix);
                String mappedKey = "今日接收" + chineseType;
                map.put(mappedKey, valueStr);
                matchCount++;
            }
        }
    }
    return map;
}

private String getVariableValue(Object scriptScope, String varName) {
    Map allVars = getAllVariablesMap(scriptScope);
    for (Object obj : allVars.entrySet()) {
        Entry entry = (Entry) obj;
        if (((String)entry.getKey()).equalsIgnoreCase(varName)) {
            return (String)entry.getValue();
        }
    }
    return null;
}

private String getVarDescription(String key, String value) {
    String desc = "变量值";

    if (key.equalsIgnoreCase("time")) {
        desc = "当前系统时间";
    } else if (key.equalsIgnoreCase("qq")) {
        desc = "宿主QQ号";
    } else if (key.startsWith("total")) {
        String type = key.substring(5);
        if (type.equals("Send")) desc = "累计发送总数";
        else if (type.equals("Receive")) desc = "累计接收总数";
        else if (type.equals("SendWordCount")) desc = "累计发送字数";
        else if (type.equals("ReceiveWordCount")) desc = "累计接收字数";
        else desc = "累计 " + type + " 数量";
    }
    else if (key.startsWith("今日发送")) {
        String type = key.substring(4);
        desc = "今日发送" + type + "数量";
    } else if (key.startsWith("今日接收")) {
        String type = key.substring(4);
        desc = "今日接收" + type + "数量";
    }
    
    return desc + ": " + value;
}

private List getSortedVariableList(Object scriptScope) {
    Map map = getAllVariablesMap(scriptScope);
    List list = new ArrayList(map.entrySet());
    Collections.sort(list, new Comparator() {
        public int compare(Object o1, Object o2) {
            Entry e1 = (Entry) o1;
            Entry e2 = (Entry) o2;
            int len1 = ((String)e1.getKey()).length();
            int len2 = ((String)e2.getKey()).length();
            if (len1 != len2) return len1 - len2;
            return ((String)e1.getKey()).compareToIgnoreCase((String)e2.getKey());
        }
    });
    return list;
}

private String 替换变量占位符(String template, Object scriptScope) {
    if (template == null || template.trim().isEmpty()) {
        return "";
    }
    
    String result = template;
    
    try {
        Pattern linkPattern = Pattern.compile("##(.*?)##");
        Matcher linkMatcher = linkPattern.matcher(result);
        StringBuffer linkSb = new StringBuffer();
        boolean hasPending = false;
        
        while (linkMatcher.find()) {
            String linkName = linkMatcher.group(1).trim();
            String linkValue = null;
            
            if (linkName.isEmpty()) {
                linkMatcher.appendReplacement(linkSb, "##");
                continue;
            }
            
            try {
                java.util.concurrent.FutureTask task = new java.util.concurrent.FutureTask(
                    new java.util.concurrent.Callable() {
                        public Object call() throws Exception {
                            return get(linkName);
                        }
                    }
                );
                
                ThreadPool.execute(task);
                linkValue = (String) task.get(500, java.util.concurrent.TimeUnit.MILLISECONDS);
                
                if (linkValue == null || linkValue.trim().isEmpty() || "null".equals(linkValue)) {
                    linkValue = null;
                }
                
            } catch (java.util.concurrent.TimeoutException e) {
                linkValue = null;
            } catch (Exception e) {
                linkValue = null;
            }
            
            String replacement = (linkValue != null) ? linkValue : "访问链接失败了哦～";
            linkMatcher.appendReplacement(linkSb, Matcher.quoteReplacement(replacement));
            hasPending = true;
        }
        
        if (hasPending) {
            linkMatcher.appendTail(linkSb);
            result = linkSb.toString();
        }
        
    } catch (Exception e) {
    }
    
    try {
        Pattern varPattern = Pattern.compile("#(.*?)#");
        Matcher varMatcher = varPattern.matcher(result);
        StringBuffer varSb = new StringBuffer();
        boolean hasPending = false;
        
        while (varMatcher.find()) {
            String varName = varMatcher.group(1).trim();
            
            if (varName.isEmpty()) {
                varMatcher.appendReplacement(varSb, "#");
                continue;
            }
            
            String val = getVariableValue(scriptScope, varName);
            String replacement = (val != null && !val.trim().isEmpty() && !"null".equals(val)) ? val : "变量" + varName + "不存在哦～";
            
            varMatcher.appendReplacement(varSb, Matcher.quoteReplacement(replacement));
            hasPending = true;
        }
        
        if (hasPending) {
            varMatcher.appendTail(varSb);
            result = varSb.toString();
        }
        
    } catch (Exception e) {
    }
    
    return result;
}

void chatInterface(int chatType, String peerUin, String peerName) {
    Activity activity = getNowActivity();
    if (activity == null) activity = 最后Activity;
    final Activity finalActivity = activity;
    if (finalActivity == null) return;
    
    final Object scriptScope = this;
    
    boolean 输入框开关 = getBoolean("输入框", "输入框开关", false);
    if (!输入框开关) return;
    
    String 提示词模板 = getString("输入框", "提示词", "");
    if (提示词模板 == null || 提示词模板.trim().isEmpty()) {
        提示词模板 = "我是一个输入框提示～";
    }
    
    final String final提示词 = 替换变量占位符(提示词模板, scriptScope);
    
    finalActivity.runOnUiThread(new Runnable() {
        public void run() {
            try {
                int inputId = finalActivity.getResources().getIdentifier("input", "id", HostInfo.INSTANCE.getPackageName());
                View targetView = finalActivity.findViewById(inputId);
                if (targetView != null) ((TextView) targetView).setHint(final提示词);
            } catch (Throwable e) {}
        }
    });
}

public void showInputDialog(final Activity activity) {
    final Object scriptScope = this;

    activity.runOnUiThread(new Runnable() {
        public void run() {
            try {
                boolean isDark = isThemeDark(activity);
                int textColor = isDark ? UI_COLOR_TEXT_DARK : UI_COLOR_TEXT_LIGHT;
                int subTextColor = isDark ? UI_COLOR_SUBTEXT_DARK : UI_COLOR_SUBTEXT_LIGHT;
                int accentColor = isDark ? UI_COLOR_ACCENT_DARK : UI_COLOR_ACCENT_LIGHT;

                LinearLayout root = new LinearLayout(activity);
                root.setOrientation(LinearLayout.VERTICAL);
                root.setPadding(dp(activity, 16), dp(activity, 20), dp(activity, 16), dp(activity, 16));
                
                TextView titleView = new TextView(activity);
                titleView.setText("设置输入框提示词");
                titleView.setTextSize(18);
                titleView.setTypeface(null, Typeface.BOLD);
                titleView.setTextColor(textColor);
                titleView.setPadding(0, 0, 0, dp(activity, 16));
                root.addView(titleView);
                
                final EditText input = new EditText(activity);
                String 内容 = getString("输入框", "提示词", "");
                if (内容 == null) 内容 = "";
                input.setText(内容);
                input.setHint("输入内容，支持 #变量# 或 ##链接##");
                input.setHintTextColor(subTextColor);
                input.setTextColor(textColor);
                input.setTextSize(15);
                input.setPadding(dp(activity, 12), dp(activity, 10), dp(activity, 12), dp(activity, 10));
                
                GradientDrawable inputBg = new GradientDrawable();
                inputBg.setCornerRadius(dp(activity, 8));
                inputBg.setColor(isDark ? UI_COLOR_INPUT_BG_DARK : UI_COLOR_INPUT_BG_LIGHT);
                inputBg.setStroke(dp(activity, 1), isDark ? UI_COLOR_STROKE_DARK : UI_COLOR_STROKE_LIGHT);
                input.setBackground(inputBg);
                root.addView(input);
                
                TextView previewLabel = new TextView(activity);
                previewLabel.setText("效果预览：");
                previewLabel.setTextSize(12);
                previewLabel.setTextColor(subTextColor);
                previewLabel.setPadding(dp(activity, 4), dp(activity, 8), 0, 0);
                root.addView(previewLabel);

                final TextView previewText = new TextView(activity);
                previewText.setText(替换变量占位符(内容, scriptScope));
                previewText.setTextSize(13);
                previewText.setTextColor(isDark ? Color.parseColor("#81C784") : Color.parseColor("#4CAF50"));
                previewText.setPadding(dp(activity, 4), dp(activity, 2), dp(activity, 4), dp(activity, 8));
                root.addView(previewText);

                final android.os.Handler debounceHandler = new android.os.Handler();
                final Runnable[] pendingRunnable = new Runnable[1];
                
                input.addTextChangedListener(new TextWatcher() {
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
                    
                    public void onTextChanged(CharSequence s, int start, int before, int count) {}
                    
                    public void afterTextChanged(android.text.Editable s) {
                        if (pendingRunnable[0] != null) {
                            debounceHandler.removeCallbacks(pendingRunnable[0]);
                        }
                        
                        pendingRunnable[0] = new Runnable() {
                            public void run() {
                                String raw = s.toString();
                                String preview = 替换变量占位符(raw, scriptScope);
                                previewText.setText(preview);
                            }
                        };
                        
                        debounceHandler.postDelayed(pendingRunnable[0], 500);
                    }
                });
                
                input.setText(input.getText()); 
                input.setSelection(input.getText().length());

                TextView tipsView = new TextView(activity);
                tipsView.setText("💡 使用 #变量# 或 ##链接## 引用\n如: #time# 或 ##api##\napi暂时只支持返回纯文本格式\n\n在api.java文件1552行可自定义变量\n\n\n\n保存既生效,切换界面可以更新输入框内容哦～");
                tipsView.setTextSize(12);
                tipsView.setTextColor(subTextColor);
                tipsView.setPadding(dp(activity, 4), dp(activity, 8), dp(activity, 4), 0);
                root.addView(tipsView);

                TextView viewAllBtn = new TextView(activity);
                viewAllBtn.setText("🔍 查看所有可用变量");
                viewAllBtn.setTextSize(13);
                viewAllBtn.setTextColor(accentColor);
                viewAllBtn.setTypeface(null, Typeface.BOLD);
                viewAllBtn.setPadding(dp(activity, 4), dp(activity, 12), 0, 0);
                viewAllBtn.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        showAllVariablesDialog(activity, scriptScope);
                    }
                });
                root.addView(viewAllBtn);

                LinearLayout btnBox = new LinearLayout(activity);
                btnBox.setOrientation(LinearLayout.HORIZONTAL);
                btnBox.setPadding(0, dp(activity, 20), 0, 0);
                btnBox.setGravity(Gravity.RIGHT);
                
                TextView cancel = new TextView(activity);
                cancel.setText("取消");
                cancel.setTextSize(14);
                cancel.setTextColor(subTextColor);
                cancel.setPadding(dp(activity, 16), dp(activity, 8), dp(activity, 16), dp(activity, 8));
                
                final AlertDialog[] dialogRef = new AlertDialog[1];
                
                cancel.setOnClickListener(new View.OnClickListener() { 
                    public void onClick(View v) { 
                        if (dialogRef[0] != null) dialogRef[0].dismiss(); 
                    } 
                });
                
                TextView confirm = new TextView(activity);
                confirm.setText("确定");
                confirm.setTextSize(14);
                confirm.setTextColor(accentColor);
                confirm.setTypeface(null, Typeface.BOLD);
                confirm.setPadding(dp(activity, 16), dp(activity, 8), dp(activity, 16), dp(activity, 8));
                confirm.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        String in = input.getText().toString().trim();
                        if (!in.equals("")) {
                            putString("输入框", "提示词", in);
                            Toast("提示词已保存并立即生效");
                        }
                        if (dialogRef[0] != null) dialogRef[0].dismiss();
                    }
                });
                
                btnBox.addView(cancel);
                btnBox.addView(confirm);
                root.addView(btnBox);
                
                AlertDialog.Builder builder = new AlertDialog.Builder(activity, 
                    isDark ? AlertDialog.THEME_DEVICE_DEFAULT_DARK : AlertDialog.THEME_DEVICE_DEFAULT_LIGHT);
                builder.setView(root);
                AlertDialog dialog = builder.create();
                dialogRef[0] = dialog;
                
                dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
                    public void onDismiss(DialogInterface dialog) {
                        if (pendingRunnable[0] != null) {
                            debounceHandler.removeCallbacks(pendingRunnable[0]);
                        }
                    }
                });
                
                dialog.getWindow().setBackgroundDrawable(new GradientDrawable() {{
                    setColor(Color.parseColor(isDark ? UI_COLOR_BG_DARK : UI_COLOR_BG_LIGHT));
                    setCornerRadius(dp(activity, 12));
                }});
                WindowManager.LayoutParams params = dialog.getWindow().getAttributes();
                params.width = Math.min(dp(activity, 320), activity.getResources().getDisplayMetrics().widthPixels - dp(activity, 40));
                dialog.getWindow().setAttributes(params);
                
                dialog.show();
            } catch (Exception e) {}
        }
    });
}

public void showAllVariablesDialog(final Activity activity, final Object scriptScope) {
    boolean isDark = isThemeDark(activity);
    int textColor = isDark ? UI_COLOR_TEXT_DARK : UI_COLOR_TEXT_LIGHT;
    int subTextColor = isDark ? UI_COLOR_SUBTEXT_DARK : UI_COLOR_SUBTEXT_LIGHT;
    int itemBgColor = isDark ? Color.parseColor("#33FFFFFF") : Color.parseColor("#F5F5F5");
    int accentColor = isDark ? UI_COLOR_ACCENT_DARK : UI_COLOR_ACCENT_LIGHT;

    LinearLayout root = new LinearLayout(activity);
    root.setOrientation(LinearLayout.VERTICAL);
    
    TextView title = new TextView(activity);
    title.setText("所有可用变量 (点击复制)");
    title.setTextSize(17);
    title.setTypeface(null, Typeface.BOLD);
    title.setTextColor(textColor);
    title.setPadding(dp(activity, 20), dp(activity, 20), dp(activity, 20), dp(activity, 10));
    root.addView(title);
    
    ScrollView scrollView = new ScrollView(activity);
    LinearLayout listLayout = new LinearLayout(activity);
    listLayout.setOrientation(LinearLayout.VERTICAL);
    listLayout.setPadding(dp(activity, 16), 0, dp(activity, 16), dp(activity, 16));
    
    List sortedVars = getSortedVariableList(scriptScope);
    
    for (int i = 0; i < sortedVars.size(); i++) {
        Entry entry = (Entry) sortedVars.get(i);
        String key = (String) entry.getKey();
        String val = (String) entry.getValue();
        
        if (key.startsWith("date_") && key.length() > 20) {
            continue; // 跳过原始键，已在映射变量中展示
        }
        
        String desc = getVarDescription(key, val);
        
        LinearLayout item = new LinearLayout(activity);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setPadding(dp(activity, 12), dp(activity, 10), dp(activity, 12), dp(activity, 10));
        item.setClickable(true);
        item.setFocusable(true);
        
        GradientDrawable itemBg = new GradientDrawable();
        itemBg.setColor(itemBgColor);
        itemBg.setCornerRadius(dp(activity, 8));
        item.setBackground(itemBg);
        
        item.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, android.view.MotionEvent event) {
                if (event.getAction() == android.view.MotionEvent.ACTION_DOWN) {
                    v.setBackgroundColor(Color.parseColor(isDark ? "#44FFFFFF" : "#E0E0E0"));
                } else if (event.getAction() == android.view.MotionEvent.ACTION_UP || 
                           event.getAction() == android.view.MotionEvent.ACTION_CANCEL) {
                    v.setBackground(itemBg);
                }
                return false;
            }
        });
        
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        params.setMargins(0, 0, 0, dp(activity, 8));
        item.setLayoutParams(params);
        
        TextView keyTv = new TextView(activity);
        keyTv.setText("#" + key + "#");
        keyTv.setTextSize(14);
        keyTv.setTypeface(null, Typeface.BOLD);
        keyTv.setTextColor(accentColor);
        item.addView(keyTv);
        
        TextView descTv = new TextView(activity);
        descTv.setText(desc);
        descTv.setTextSize(12);
        descTv.setTextColor(subTextColor);
        descTv.setPadding(0, dp(activity, 4), 0, 0);
        item.addView(descTv);
        
        final String copyText = "#" + key + "#";
        
        item.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                v.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP);
                
                try {
                    ClipboardManager cm = (ClipboardManager) activity.getApplicationContext()
                                                                        .getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cm != null) {
                        ClipData clip = ClipData.newPlainText("Var", copyText);
                        cm.setPrimaryClip(clip);
                        
                        Toast("已复制: " + copyText);
                        
                        keyTv.setTextColor(Color.GREEN);
                        android.os.Handler handler = new android.os.Handler();
                        handler.postDelayed(new Runnable() {
                            public void run() {
                                keyTv.setTextColor(accentColor);
                            }
                        }, 300);
                    } else {
                        Toast("系统剪贴板不可用");
                    }
                } catch (Exception e) {
                    Toast("复制失败: " + e.getMessage());
                }
            }
        });
        
        listLayout.addView(item);
    }
    
    if (sortedVars.isEmpty()) {
        TextView empty = new TextView(activity);
        empty.setText("暂无变量");
        empty.setTextColor(subTextColor);
        empty.setPadding(20, 20, 20, 20);
        listLayout.addView(empty);
    }

    scrollView.addView(listLayout);
    int maxHeight = activity.getResources().getDisplayMetrics().heightPixels / 2;
    root.addView(scrollView, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, maxHeight));
    
    TextView closeBtn = new TextView(activity);
    closeBtn.setText("关闭");
    closeBtn.setGravity(Gravity.CENTER);
    closeBtn.setPadding(0, dp(activity, 16), 0, dp(activity, 16));
    closeBtn.setTextColor(textColor);
    
    final AlertDialog[] varDialogRef = new AlertDialog[1];
    closeBtn.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) { 
            if (varDialogRef[0] != null) varDialogRef[0].dismiss(); 
        }
    });
    root.addView(closeBtn);

    AlertDialog.Builder builder = new AlertDialog.Builder(activity, 
        isDark ? AlertDialog.THEME_DEVICE_DEFAULT_DARK : AlertDialog.THEME_DEVICE_DEFAULT_LIGHT);
    builder.setView(root);
    AlertDialog varDialog = builder.create();
    varDialogRef[0] = varDialog;
    
    varDialog.getWindow().setBackgroundDrawable(new GradientDrawable() {{
        setColor(Color.parseColor(isDark ? UI_COLOR_BG_DARK : UI_COLOR_BG_LIGHT));
        setCornerRadius(dp(activity, 12));
    }});
    WindowManager.LayoutParams winParams = varDialog.getWindow().getAttributes();
    winParams.width = Math.min(dp(activity, 320), activity.getResources().getDisplayMetrics().widthPixels - dp(activity, 40));
    varDialog.getWindow().setAttributes(winParams);
    
    varDialog.show();
}






public void showShutUpDialog(final Activity activity, final String qun, final String uin) {
    activity.runOnUiThread(new Runnable() {
        public void run() {
            try {
                boolean isDark = isThemeDark(activity);

                // 主容器
                LinearLayout root = new LinearLayout(activity);
                root.setOrientation(LinearLayout.VERTICAL);
                root.setPadding(dp(activity, 12), dp(activity, 16), dp(activity, 12), dp(activity, 12));
                
                // 标题
                TextView titleView = new TextView(activity);
                titleView.setText("设置禁言时长");
                titleView.setTextSize(16);
                titleView.setTypeface(null, Typeface.BOLD);
                titleView.setTextColor(isDark ? UI_COLOR_TEXT_DARK : UI_COLOR_TEXT_LIGHT);
                titleView.setPadding(0, 0, 0, dp(activity, 12));
                root.addView(titleView);
                
                // 输入框 - 只允许数字
                final EditText input = new EditText(activity);
                input.setHint("请输入禁言时长(秒)");
                input.setHintTextColor(isDark ? UI_COLOR_SUBTEXT_DARK : UI_COLOR_SUBTEXT_LIGHT);
                input.setTextColor(isDark ? UI_COLOR_TEXT_DARK : UI_COLOR_TEXT_LIGHT);
                input.setTextSize(14);
                input.setPadding(dp(activity, 10), dp(activity, 8), dp(activity, 10), dp(activity, 8));
                input.setText("0"); // 默认值
                input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
                
                GradientDrawable inputBg = new GradientDrawable();
                inputBg.setCornerRadius(dp(activity, 6));
                inputBg.setColor(isDark ? UI_COLOR_INPUT_BG_DARK : UI_COLOR_INPUT_BG_LIGHT);
                inputBg.setStroke(dp(activity, 1), isDark ? UI_COLOR_STROKE_DARK : UI_COLOR_STROKE_LIGHT);
                input.setBackground(inputBg);
                root.addView(input);
                
                // 按钮容器
                LinearLayout btnBox = new LinearLayout(activity);
                btnBox.setOrientation(LinearLayout.HORIZONTAL);
                btnBox.setPadding(0, dp(activity, 16), 0, 0);
                btnBox.setGravity(Gravity.RIGHT);
                
                // 取消按钮
                TextView cancel = new TextView(activity);
                cancel.setText("取消");
                cancel.setTextSize(14);
                cancel.setTextColor(isDark ? UI_COLOR_SUBTEXT_DARK : UI_COLOR_SUBTEXT_LIGHT);
                cancel.setPadding(dp(activity, 12), dp(activity, 8), dp(activity, 12), dp(activity, 8));
                cancel.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });
                
                // 确定按钮
                TextView confirm = new TextView(activity);
                confirm.setText("确定");
                confirm.setTextSize(14);
                confirm.setTextColor(isDark ? UI_COLOR_ACCENT_DARK : UI_COLOR_ACCENT_LIGHT);
                confirm.setPadding(dp(activity, 12), dp(activity, 8), dp(activity, 12), dp(activity, 8));
                confirm.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        String inputText = input.getText().toString().trim();
                        int seconds = 0;
                        try {
                            seconds = Integer.parseInt(inputText);
                        } catch (NumberFormatException e) {
                            seconds = 0;
                        }
                        
                        dialog.dismiss();
                        shutUp(qun, uin, seconds);
                        Toast("禁言设置成功");
                        vibrate(activity, 32);
                        
                        traceLog("api_log.txt", "禁言设置: qun=" + qun + " uin=" + uin + " seconds=" + seconds);
                    }
                });
                
                btnBox.addView(cancel);
                btnBox.addView(confirm);
                root.addView(btnBox);
                
                // 构建对话框
                AlertDialog.Builder builder = new AlertDialog.Builder(activity, 
                    isDark ? AlertDialog.THEME_DEVICE_DEFAULT_DARK : AlertDialog.THEME_DEVICE_DEFAULT_LIGHT);
                builder.setView(root);
                final AlertDialog dialog = builder.create();
                
                // 样式设置
                dialog.getWindow().setBackgroundDrawable(new GradientDrawable() {{
                    setColor(Color.parseColor(isDark ? UI_COLOR_BG_DARK : UI_COLOR_BG_LIGHT));
                    setCornerRadius(dp(activity, 8));
                }});
                
                WindowManager.LayoutParams params = dialog.getWindow().getAttributes();
                params.width = Math.min(dp(activity, 280), 
                    activity.getResources().getDisplayMetrics().widthPixels - dp(activity, 40));
                dialog.getWindow().setAttributes(params);
                
                dialog.show();
                
            } catch (Exception e) {
                traceLog("api_log.txt", "禁言弹窗异常: " + e.getMessage());
                Toast("弹窗显示失败");
            }
        }
    });
}

// 值提取工具（移除引号 + null值替换）
String extractValue(String pair, String prefix) {
    try {
        // 移除前缀（如"uin"），保留等号后的值
        String value = pair.substring(prefix.length()).trim();
        
        // 移除开头的等号（如果存在）
        if (value.startsWith("=")) {
            value = value.substring(1).trim();
        }
        
        // 移除首尾单引号（如果存在）
        if (value.startsWith("'") && value.endsWith("'") && value.length() >= 2) {
            value = value.substring(1, value.length() - 1);
        }
        
        // 特殊值转换：null → 未设置
        return "null".equals(value) ? "未设置" : value;
    } catch (Exception e) {
        return "获取失败";
    }
}



// 角色转换（方法前置）
String convertRole(String role) {
    if ("OWNER".equals(role)) return "群主";
    if ("ADMIN".equals(role)) return "管理员";
    if ("MEMBER".equals(role)) return "普通成员";
    return role;
}

// 时间戳转换（方法前置）
String timestampToDate(long timestamp) {
    try {
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return sdf.format(new java.util.Date(timestamp));
    } catch (Exception e) {
        return "时间错误";
    }
}

/**
 * 判断禁言状态
 * @param timestamp 禁言结束时间戳（Unix秒级时间戳）
 * @return 禁言状态："永久禁言"、"禁言中"、"未禁言"、"未知"
 */
String getGagStatus(String timestamp) {
    try {
        
        long ts = Long.parseLong(timestamp);
        long currentTime = System.currentTimeMillis() / 1000; // 当前Unix时间戳（秒）
        
        // 特殊情况处理
        if (ts == 0) {
            return "未禁言";
        }
        
        // 如果是极大值，可能是永久禁言
        if (ts > 4102358400L) { // 2100年之后的某个时间
            return "永久禁言";
        }
        
        // 判断是否在禁言中
        if (ts > currentTime) {
            // 计算剩余时间
            long remainingSeconds = ts - currentTime;
            String timeStr = formatRemainingTime(remainingSeconds);
            return "禁言中，剩余: " + timeStr;
        } else {
            // 禁言已过期
            return "未禁言";
        }
        
    } catch (NumberFormatException e) {
        traceLog("api_log.txt", "转换异常: " + e.getMessage());
        return "未知";
    } catch (Exception e) {
        traceLog("api_log.txt", "其他异常: " + e.getMessage());
        return "未知";
    }
}

/**
 * 格式化剩余时间
 */
String formatRemainingTime(long seconds) {
    if (seconds < 60) {
        return seconds + "秒";
    } else if (seconds < 3600) {
        return (seconds / 60) + "分钟" + (seconds % 60) + "秒";
    } else if (seconds < 86400) {
        long hours = seconds / 3600;
        long minutes = (seconds % 3600) / 60;
        return hours + "小时" + minutes + "分钟";
    } else {
        long days = seconds / 86400;
        long hours = (seconds % 86400) / 3600;
        return days + "天" + hours + "小时";
    }
}

// VIP类型转换
String getVipType(String type) {
    try {
        int t = Integer.parseInt(type);
        return t == 0 ? "无" : "VIP" + t;
    } catch (Exception e) {
        return "未知";
    }
}

// 布尔值转换（方法前置）
String getBooleanDisplay(String value) {
    return "true".equalsIgnoreCase(value) ? "是" : "否";
}



String encryptBase64(String text) {
    try {
        return new String(android.util.Base64.encode(text.getBytes("UTF-8"), android.util.Base64.NO_WRAP), "UTF-8");
    } catch (Exception e) {
        traceLog("api_log.txt", e.getMessage());
        return null;
    }
}

String decryptBase64(String text) {
    try {
        return new String(android.util.Base64.decode(text.getBytes("UTF-8"), android.util.Base64.NO_WRAP), "UTF-8");
    } catch (Exception e) {
        traceLog("api_log.txt", e.getMessage());
        return null;
    }
}

String encryptUnicode(String text) {
    try {
        StringBuilder result = new StringBuilder();
        for (char c : text.toCharArray()) {
            result.append("\\u").append(String.format("%04x", (int)c));
        }
        return result.toString();
    } catch (Exception e) {
        traceLog("api_log.txt", e.getMessage());
        return null;
    }
}

String decryptUnicode(String text) {
    try {
        StringBuilder result = new StringBuilder();
        String[] parts = text.split("\\\\u");
        for (int i = 1; i < parts.length; i++) {
            if (parts[i].length() >= 4) {
                String hex = parts[i].substring(0, 4);
                int codePoint = Integer.parseInt(hex, 16);
                result.append((char)codePoint);
                if (parts[i].length() > 4) {
                    result.append(parts[i].substring(4));
                }
            }
        }
        return result.toString();
    } catch (Exception e) {
        traceLog("api_log.txt", e.getMessage());
        return null;
    }
}


String encryptBase64Safe(String text) {
    if (text == null || text.isEmpty()) return null;
    
    final int CHUNK_SIZE = 1024 * 16;
    
    // 小文本走快速路径
    if (text.length() <= CHUNK_SIZE) {
        return encryptBase64(text);
    }
    
    traceLog("api_log.txt", "文本过大，启用分块模式，总长度:" + text.length());
    
    StringBuilder result = new StringBuilder();
    int totalChunks = (int)Math.ceil(text.length() / (double)CHUNK_SIZE);
    
    for (int i = 0; i < totalChunks; i++) {
        int start = i * CHUNK_SIZE;
        int end = Math.min(start + CHUNK_SIZE, text.length());
        String chunk = text.substring(start, end);
        
        String encryptedChunk = encryptBase64(chunk);
        if (encryptedChunk == null) {
            traceLog("api_log.txt", "块索引:" + i + "/" + totalChunks);
            return null;
        }
        
        result.append(encryptedChunk);
        
        if (i % 5 == 0) {
            Thread.yield();
        }
    }
    
    traceLog("api_log.txt", "总块数:" + totalChunks + " 总长度:" + text.length());
    return result.toString();
}

String decryptBase64Safe(String text) {
    if (text == null || text.isEmpty()) return null;
    
    final int CHUNK_SIZE = 1024 * 16;
    
    if (text.length() <= CHUNK_SIZE) {
        return decryptBase64(text);
    }
    
    traceLog("api_log.txt", "base64解密启用分块模式，总长度:" + text.length());
    
    StringBuilder result = new StringBuilder();
    int totalChunks = (int)Math.ceil(text.length() / (double)CHUNK_SIZE);
    
    for (int i = 0; i < totalChunks; i++) {
        int start = i * CHUNK_SIZE;
        int end = Math.min(start + CHUNK_SIZE, text.length());
        String chunk = text.substring(start, end);
        
        String decryptedChunk = decryptBase64(chunk);
        if (decryptedChunk == null) {
            traceLog("api_log.txt", "块索引:" + i + "/" + totalChunks);
            return null;
        }
        
        result.append(decryptedChunk);
        
        if (i % 5 == 0) {
            Thread.yield();
        }
    }
    
    traceLog("api_log.txt", "总块数:" + totalChunks);
    return result.toString();
}

String encryptUnicodeSafe(String text) {
    if (text == null || text.isEmpty()) return null;
    
    // Unicode加密膨胀率极高（1字符→6字符），块大小需缩小
    final int CHUNK_SIZE = 1024 * 2; // 2KB
    
    if (text.length() <= CHUNK_SIZE) {
        return encryptUnicode(text);
    }
    
    traceLog("api_log.txt", "Unicode加密启用分块模式，总长度:" + text.length());
    
    StringBuilder result = new StringBuilder();
    int totalChunks = (int)Math.ceil(text.length() / (double)CHUNK_SIZE);
    
    for (int i = 0; i < totalChunks; i++) {
        int start = i * CHUNK_SIZE;
        int end = Math.min(start + CHUNK_SIZE, text.length());
        String chunk = text.substring(start, end);
        
        String encryptedChunk = encryptUnicode(chunk);
        if (encryptedChunk == null) {
            traceLog("api_log.txt", "块索引:" + i + "/" + totalChunks);
            return null;
        }
        
        result.append(encryptedChunk);
        
        // Unicode处理更耗时，每3块让一次
        if (i % 3 == 0) {
            Thread.yield();
        }
    }
    
    traceLog("api_log.txt", "总块数:" + totalChunks);
    return result.toString();
}

String decryptUnicodeSafe(String text) {
    if (text == null || text.isEmpty()) return null;
    
    final int CHUNK_SIZE = 1024 * 16; // 解密时块可稍大
    
    if (text.length() <= CHUNK_SIZE) {
        return decryptUnicode(text);
    }
    
    traceLog("api_log.txt", "Unicode解密启用分块模式，总长度:" + text.length());
    
    StringBuilder result = new StringBuilder();
    int totalChunks = (int)Math.ceil(text.length() / (double)CHUNK_SIZE);
    
    for (int i = 0; i < totalChunks; i++) {
        int start = i * CHUNK_SIZE;
        int end = Math.min(start + CHUNK_SIZE, text.length());
        String chunk = text.substring(start, end);
        
        String decryptedChunk = decryptUnicode(chunk);
        if (decryptedChunk == null) {
            traceLog("api_log.txt", "块索引:" + i + "/" + totalChunks);
            return null;
        }
        
        result.append(decryptedChunk);
        
        if (i % 5 == 0) {
            Thread.yield();
        }
    }
    
    traceLog("api_log.txt", "总块数:" + totalChunks);
    return result.toString();
}

public void showEncryptDecryptDialog(final Activity activity, final String originalText) {
    if (activity == null || activity.isFinishing()) {
        traceLog("api_log.txt", "Activity无效或正在关闭");
        return;
    }

    final int MAX_DISPLAY_LENGTH = 5000; // EditText安全显示阈值
    final String displayText;
    final boolean isTextTooLong = originalText.length() > MAX_DISPLAY_LENGTH;
    
    if (isTextTooLong) {
        displayText = originalText.substring(0, MAX_DISPLAY_LENGTH) + 
                      "\n\n【文本过长，仅显示前" + MAX_DISPLAY_LENGTH + "字符】\n" +
                      "完整文本长度: " + originalText.length() + " 字符";
        Toast("文本过长，处理可能需要数秒");
    } else {
        displayText = originalText;
    }

    activity.runOnUiThread(new Runnable() {
        public void run() {
            try {
                boolean isDark = isThemeDark(activity);

                LinearLayout root = new LinearLayout(activity);
                root.setOrientation(LinearLayout.VERTICAL);
                root.setPadding(dp(activity, 12), dp(activity, 16), dp(activity, 12), dp(activity, 12));
                
                TextView titleView = new TextView(activity);
                titleView.setText("加解密工具");
                titleView.setTextSize(16);
                titleView.setTypeface(null, Typeface.BOLD);
                titleView.setTextColor(isDark ? UI_COLOR_TEXT_DARK : UI_COLOR_TEXT_LIGHT);
                titleView.setPadding(0, 0, 0, dp(activity, 12));
                root.addView(titleView);
                
                final EditText input = new EditText(activity);
                input.setText(displayText);
                input.setHint("请输入要处理的文本");
                input.setHintTextColor(isDark ? UI_COLOR_SUBTEXT_DARK : UI_COLOR_SUBTEXT_LIGHT);
                input.setTextColor(isDark ? UI_COLOR_TEXT_DARK : UI_COLOR_TEXT_LIGHT);
                input.setTextSize(14);
                input.setPadding(dp(activity, 10), dp(activity, 8), dp(activity, 10), dp(activity, 8));
                input.setFocusable(true);
                input.setFocusableInTouchMode(true);
                
                if (isTextTooLong) {
                    input.setFocusable(false); // 只读模式
                    input.setFocusableInTouchMode(false);
                }
                
                // 动态高度计算（最大260dp）
                final int MAX_HEIGHT_DP = 260;
                final int MIN_HEIGHT_DP = 120;
                
                int estimatedLines = Math.max(1, displayText.split("\n").length);
                int initialHeightDp = Math.min(estimatedLines * 25 + 16, MAX_HEIGHT_DP);
                initialHeightDp = Math.max(initialHeightDp, MIN_HEIGHT_DP);
                
                final LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    dp(activity, initialHeightDp)
                );
                inputParams.setMargins(0, 0, 0, dp(activity, 8));
                input.setLayoutParams(inputParams);
                
                // 大文本时移除TextWatcher（避免频繁计算）
                if (!isTextTooLong) {
                    input.addTextChangedListener(new android.text.TextWatcher() {
                        public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
                        public void onTextChanged(CharSequence s, int start, int before, int count) {}
                        
                        public void afterTextChanged(android.text.Editable s) {
                            try {
                                int lineCount = input.getLineCount();
                                if (lineCount <= 0) return;
                                
                                int targetHeightDp = Math.min(lineCount * 25 + 16, MAX_HEIGHT_DP);
                                targetHeightDp = Math.max(targetHeightDp, MIN_HEIGHT_DP);
                                
                                if (inputParams.height != dp(activity, targetHeightDp)) {
                                    inputParams.height = dp(activity, targetHeightDp);
                                    input.setLayoutParams(inputParams);
                                }
                            } catch (Throwable e) {
                                traceLog("api_log.txt", "错误:" + e.getMessage());
                            }
                        }
                    });
                }
                
                // input.setVerticalScrollBarEnabled(true);
                // input.setScrollbarFadingEnabled(false);
                // input.setOverScrollMode(View.OVER_SCROLL_NEVER);
                
                GradientDrawable inputBg = new GradientDrawable();
                inputBg.setCornerRadius(dp(activity, 6));
                inputBg.setColor(isDark ? UI_COLOR_INPUT_BG_DARK : UI_COLOR_INPUT_BG_LIGHT);
                inputBg.setStroke(dp(activity, 1), isDark ? UI_COLOR_STROKE_DARK : UI_COLOR_STROKE_LIGHT);
                input.setBackground(inputBg);
                root.addView(input);
                
                GridLayout btnGrid = new GridLayout(activity);
                btnGrid.setColumnCount(2);
                btnGrid.setRowCount(2);
                btnGrid.setPadding(0, dp(activity, 12), 0, 0);
                btnGrid.setUseDefaultMargins(false);
                
                View.OnClickListener btnClickListener = new View.OnClickListener() {
                    public void onClick(View v) {
                        final String currentText = isTextTooLong ? originalText : input.getText().toString().trim();
                        
                        if (currentText.isEmpty()) {
                            Toast("请输入文本");
                            return;
                        }
                        
                        final String tag = (String) v.getTag();
                        
                        ThreadPool.execute(new Runnable() {
                            public void run() {
                                String result = null;
                                try {
                                    // 使用增强版安全方法（自动分块）
                                    if ("base64加密".equals(tag)) {
                                        result = encryptBase64Safe(currentText);
                                    } else if ("base64解密".equals(tag)) {
                                        result = decryptBase64Safe(currentText);
                                    } else if ("Unicode加密".equals(tag)) {
                                        result = encryptUnicodeSafe(currentText);
                                    } else if ("Unicode解密".equals(tag)) {
                                        result = decryptUnicodeSafe(currentText);
                                    }
                                } catch (OutOfMemoryError e) {
                                    traceLog("api_log.txt", "类型:" + tag + " 文本长度:" + currentText.length());
                                            Toast("内存不足，文本过大");
                                    return;
                                } catch (Throwable e) {
                                    traceLog("api_log.txt", "类型:" + tag + " 错误:" + e.getMessage());
                                }
                                
                                final String finalResult = result;
                                
                                // UI更新回到主线程
                                activity.runOnUiThread(new Runnable() {
                                    public void run() {
                                        if (finalResult != null) {
                                             {
                                                input.setText(finalResult);
                                                vibrate(activity, 28);
                                                Toast("处理完成");
                                            }
                                        } else {
                                            Toast("处理失败，请检查输入格式");
                                        }
                                    }
                                });
                            }
                        });
                    }
                };
                
                String[] btnLabels = {"base64加密", "base64解密", "Unicode加密", "Unicode解密"};
                for (int i = 0; i < btnLabels.length; i++) {
                    TextView btn = new TextView(activity);
                    btn.setText(btnLabels[i]);
                    btn.setTextSize(13);
                    btn.setTextColor(isDark ? UI_COLOR_TEXT_DARK : UI_COLOR_TEXT_LIGHT);
                    btn.setGravity(Gravity.CENTER);
                    btn.setPadding(dp(activity, 8), dp(activity, 10), dp(activity, 8), dp(activity, 10));
                    btn.setTag(btnLabels[i]);
                    btn.setOnClickListener(btnClickListener);
                    
                    GradientDrawable btnBg = new GradientDrawable();
                    btnBg.setCornerRadius(dp(activity, 6));
                    btnBg.setColor(isDark ? UI_COLOR_INPUT_BG_DARK : UI_COLOR_BG_LIGHT);
                    btnBg.setStroke(dp(activity, 1), isDark ? UI_COLOR_STROKE_DARK : UI_COLOR_STROKE_LIGHT);
                    btn.setBackground(btnBg);
                    
                    GridLayout.LayoutParams params = new GridLayout.LayoutParams();
                    params.width = 0;
                    params.height = GridLayout.LayoutParams.WRAP_CONTENT;
                    params.columnSpec = GridLayout.spec(i % 2, 1f);
                    params.rowSpec = GridLayout.spec(i / 2);
                    params.setMargins(dp(activity, 4), dp(activity, 6), dp(activity, 4), dp(activity, 6));
                    btn.setLayoutParams(params);
                    
                    btnGrid.addView(btn);
                }
                
                root.addView(btnGrid);
                
                LinearLayout btnBox = new LinearLayout(activity);
                btnBox.setOrientation(LinearLayout.HORIZONTAL);
                btnBox.setPadding(0, dp(activity, 8), 0, 0);
                btnBox.setGravity(Gravity.RIGHT);
                
                TextView cancel = new TextView(activity);
                cancel.setText("关闭");
                cancel.setTextSize(14);
                cancel.setTextColor(isDark ? UI_COLOR_SUBTEXT_DARK : UI_COLOR_SUBTEXT_LIGHT);
                cancel.setPadding(dp(activity, 12), dp(activity, 8), dp(activity, 12), dp(activity, 8));
                cancel.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });
                btnBox.addView(cancel);
                root.addView(btnBox);
                
                AlertDialog.Builder builder = new AlertDialog.Builder(activity, 
                    isDark ? AlertDialog.THEME_DEVICE_DEFAULT_DARK : AlertDialog.THEME_DEVICE_DEFAULT_LIGHT);
                builder.setView(root);
                final AlertDialog dialog = builder.create();
                
                dialog.getWindow().setBackgroundDrawable(new GradientDrawable() {{
                    setColor(Color.parseColor(isDark ? UI_COLOR_BG_DARK : UI_COLOR_BG_LIGHT));
                    setCornerRadius(dp(activity, 8));
                }});
                
                WindowManager.LayoutParams params = dialog.getWindow().getAttributes();
                params.width = Math.min(dp(activity, 300), 
                    activity.getResources().getDisplayMetrics().widthPixels - dp(activity, 40));
                dialog.getWindow().setAttributes(params);
                
                dialog.show();
                traceLog("api_log.txt", "显示成功，文本长度:" + originalText.length() + 
                         (isTextTooLong ? "（已截断显示）" : ""));
                
            } catch (Exception e) {
                traceLog("api_log.txt", e.getMessage());
                Toast("弹窗显示失败");
            }
        }
    });
}

public void showCodeConsoleDialog(final Activity activity, final Object data) {
    if (activity == null || activity.isFinishing()) {
        traceLog("api_log.txt", "Activity无效或正在关闭");
        return;
    }
    
    if (data == null) {
        traceLog("api_log.txt", "data对象为null");
        Toast("数据无效");
        return;
    }

    String initialCode = "";
    try {
        initialCode = data.msg != null ? data.msg : "";
        // traceLog("api_log.txt", "提取代码成功，长度:" + initialCode.length());
    } catch (Exception e) {
        traceLog("api_log.txt", "访问data.msg失败:" + e.getMessage());
        Toast("数据格式错误：缺少msg字段");
        return;
    }
    
    final String finalInitialCode = initialCode;

    activity.runOnUiThread(new Runnable() {
        public void run() {
            try {
                boolean isDark = isThemeDark(activity);

                LinearLayout root = new LinearLayout(activity);
                root.setOrientation(LinearLayout.VERTICAL);
                root.setPadding(dp(activity, 12), dp(activity, 16), dp(activity, 12), dp(activity, 12));
                
                TextView titleView = new TextView(activity);
                titleView.setText("代码控制台");
                titleView.setTextSize(16);
                titleView.setTypeface(null, Typeface.BOLD);
                titleView.setTextColor(isDark ? UI_COLOR_TEXT_DARK : UI_COLOR_TEXT_LIGHT);
                titleView.setPadding(0, 0, 0, dp(activity, 12));
                root.addView(titleView);
                
                final TextView resultView = new TextView(activity);
                resultView.setText("等待执行...");
                resultView.setTextSize(13);
                resultView.setTextColor(isDark ? UI_COLOR_TEXT_DARK : UI_COLOR_TEXT_LIGHT);
                resultView.setPadding(dp(activity, 10), dp(activity, 8), dp(activity, 10), dp(activity, 8));
                resultView.setBackground(new GradientDrawable() {{
                    setCornerRadius(dp(activity, 6));
                    setColor(isDark ? UI_COLOR_INPUT_BG_DARK : UI_COLOR_INPUT_BG_LIGHT);
                    setStroke(dp(activity, 1), isDark ? UI_COLOR_STROKE_DARK : UI_COLOR_STROKE_LIGHT);
                }});
                resultView.setTypeface(Typeface.MONOSPACE);
                
                ScrollView resultScroll = new ScrollView(activity);
                resultScroll.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    dp(activity, 120)
                ));
                ((LinearLayout.LayoutParams)resultScroll.getLayoutParams()).setMargins(0, 0, 0, dp(activity, 12));
                resultScroll.addView(resultView);
                root.addView(resultScroll);
                
                final EditText input = new EditText(activity);
                input.setText(finalInitialCode);
                input.setHint("请输入要执行的代码");
                input.setHintTextColor(isDark ? UI_COLOR_SUBTEXT_DARK : UI_COLOR_SUBTEXT_LIGHT);
                input.setTextColor(isDark ? UI_COLOR_TEXT_DARK : UI_COLOR_TEXT_LIGHT);
                input.setTextSize(13);
                input.setPadding(dp(activity, 10), dp(activity, 8), dp(activity, 10), dp(activity, 8));
                input.setTypeface(Typeface.MONOSPACE);
                
                LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    dp(activity, 120)
                );
                inputParams.setMargins(0, 0, 0, dp(activity, 16));
                input.setLayoutParams(inputParams);
                
                GradientDrawable inputBg = new GradientDrawable();
                inputBg.setCornerRadius(dp(activity, 6));
                inputBg.setColor(isDark ? UI_COLOR_INPUT_BG_DARK : UI_COLOR_INPUT_BG_LIGHT);
                inputBg.setStroke(dp(activity, 1), isDark ? UI_COLOR_STROKE_DARK : UI_COLOR_STROKE_LIGHT);
                input.setBackground(inputBg);
                root.addView(input);
                
                TextView execBtn = new TextView(activity);
                execBtn.setText("▶ 执行代码");
                execBtn.setTextSize(14);
                execBtn.setTextColor(Color.parseColor("#FFFFFFFF"));
                execBtn.setGravity(Gravity.CENTER);
                execBtn.setPadding(dp(activity, 24), dp(activity, 12), dp(activity, 24), dp(activity, 12));
                execBtn.setBackground(new GradientDrawable() {{
                    setColor(isDark ? UI_COLOR_ACCENT_DARK : UI_COLOR_ACCENT_LIGHT);
                    setCornerRadius(dp(activity, 6));
                }});
                
                LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                );
                btnParams.gravity = Gravity.CENTER_HORIZONTAL;
                btnParams.setMargins(0, 0, 0, dp(activity, 16));
                execBtn.setLayoutParams(btnParams);
                
                execBtn.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        final String codeToExecute = input.getText().toString().trim();
                        
                        if (codeToExecute.isEmpty()) {
                            Toast("请输入代码");
                            vibrate(activity, 20);
                            return;
                        }
                        
                        ThreadPool.execute(new Runnable() {
                            public void run() {
                                try {
                                    activity.runOnUiThread(new Runnable() {
                                        public void run() {
                                            resultView.setText("执行中...");
                                        }
                                    });
                                    
                                    this.interpreter.set("data", data);
                                    this.interpreter.set("msg", data.data);
                                    this.interpreter.set("qun", data.peerUin);
                                    this.interpreter.set("uin", data.userUin);
                                    this.interpreter.set("type", data.type);
                                    this.interpreter.set("msgtype", data.msgType);
                                    this.interpreter.set("qq", myUin);
                                    
                                    traceLog("api_log.txt", "开始执行代码，长度:" + codeToExecute.length());
                                    
                                    Object result = this.interpreter.eval(codeToExecute, "eval stream");
                                    
                                    activity.runOnUiThread(new Runnable() {
                                        public void run() {
                                            if (result != null) {
                                                String resultStr = result.toString();
                                                String displayStr = "执行结果:\n" + resultStr;
                                                
                                                if (resultStr.length() > 5000) {
                                                    displayStr = "执行结果(过长已截断):\n" + 
                                                                 resultStr.substring(0, 5000) + 
                                                                 "\n...（共" + resultStr.length() + "字符）";
                                                }
                                                
                                                resultView.setText(displayStr);
                                            } else {
                                                resultView.setText("执行成功\n（无返回值）");
                                            }
                                            
                                            vibrate(activity, 32);
                                            Toast("执行完成");
                                        }
                                    });
                                } catch (Throwable e) {
                                    final String errorMsg = e.getMessage();
                                    traceLog("api_log.txt", "代码执行错误:" + (errorMsg != null ? errorMsg : "未知错误"));
                                    activity.runOnUiThread(new Runnable() {
                                        public void run() {
                                            resultView.setText("执行失败:\n" + (errorMsg != null ? errorMsg : "未知错误"));
                                            vibrate(activity, 50);
                                        }
                                    });
                                }
                            }
                        });
                    }
                });
                root.addView(execBtn);
                
                LinearLayout btnBox = new LinearLayout(activity);
                btnBox.setOrientation(LinearLayout.HORIZONTAL);
                btnBox.setGravity(Gravity.RIGHT);
                
                TextView cancel = new TextView(activity);
                cancel.setText("关闭");
                cancel.setTextSize(14);
                cancel.setTextColor(isDark ? UI_COLOR_SUBTEXT_DARK : UI_COLOR_SUBTEXT_LIGHT);
                cancel.setPadding(dp(activity, 12), dp(activity, 8), dp(activity, 12), dp(activity, 8));
                cancel.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });
                btnBox.addView(cancel);
                root.addView(btnBox);
                
                AlertDialog.Builder builder = new AlertDialog.Builder(activity, 
                    isDark ? AlertDialog.THEME_DEVICE_DEFAULT_DARK : AlertDialog.THEME_DEVICE_DEFAULT_LIGHT);
                builder.setView(root);
                final AlertDialog dialog = builder.create();
                
                dialog.getWindow().setBackgroundDrawable(new GradientDrawable() {{
                    setColor(Color.parseColor(isDark ? UI_COLOR_BG_DARK : UI_COLOR_BG_LIGHT));
                    setCornerRadius(dp(activity, 8));
                }});
                
                WindowManager.LayoutParams params = dialog.getWindow().getAttributes();
                params.width = Math.min(dp(activity, 340), 
                    activity.getResources().getDisplayMetrics().widthPixels - dp(activity, 40));
                dialog.getWindow().setAttributes(params);
                
                dialog.show();
                traceLog("api_log.txt", "控制台显示成功");
                
            } catch (Exception e) {
                traceLog("api_log.txt", "显示控制台异常:" + e.getMessage());
                Toast("弹窗显示失败");
            }
        }
    });
}



void handleCloneAvatar(final String uin) {
			ThreadPool.execute(new Runnable() {
			public void run() {
            final String avatarUrl = "http://q2.qlogo.cn/headimg_dl?dst_uin=" + uin + "&spec=640";
            final String avatarPath = pluginPath + "/cache/avatar_" + getTime() + ".png";
            
            try {
                traceLog("api_log.txt", "开始下载头像: " + avatarUrl);
                // Bitmap bmp = getbitmap(avatarUrl);
                urltofile(avatarUrl, avatarPath);
                
                Thread.sleep(50); // 等待文件写入完成
                File file = new File(avatarPath);
                if (!file.exists() || file.length() == 0) {
                    throw new IOException("头像下载失败");
                }
                
                traceLog("api_log.txt", "开始上传: " + avatarPath);
                Toast("在上传啦！耐心等一下哦～");
               if (上传头像(avatarPath)){
                
                Thread.sleep(80); // 等待上传完成
                // file.delete();
                删除(avatarPath);
                Toast("克隆头像成功");
                traceLog("api_log.txt", "克隆流程完成");
                }
            } catch (Throwable e) {
                traceLog("api_log.txt", "克隆失败: " + e.getMessage());
                Toast("克隆头像失败: " + e.getMessage());
            }
            }
            });
}

void handleUploadAvatar(final String quntext) {
			ThreadPool.execute(new Runnable() {
			public void run() {
            try {
                if (!quntext.contains("pic")) {
                    Toast("非图片消息！");
                    return;
                }
                
                String picUrl = quntext.replace("[pic=", "").replace("]", "");
                String picPath = pluginPath + "/cache/pic_" + getTime() + ".png";
                
                traceLog("api_log.txt", "开始下载图片: " + picUrl);
                // Bitmap bmp = getbitmap(picUrl);
                urltofile(picUrl, picPath);
                
                Thread.sleep(50);
                File file = new File(picPath);
                if (!file.exists() || file.length() == 0) {
                    throw new IOException("图片下载失败");
                }
                
                traceLog("api_log.txt", "开始上传: " + picPath);
                Toast("在上传啦！耐心等一下哦～");
                if (上传头像(picPath)){
                Thread.sleep(80);
                // file.delete();
                删除(picPath);
                
                Toast("上传头像成功");
                traceLog("api_log.txt", "上传流程完成");
                }
            } catch (Throwable e) {
                traceLog("api_log.txt", "上传失败: " + e.getMessage());
                Toast("上传头像失败: " + e.getMessage());
            }
            }
            });
}



public void 长按消息菜单(Activity activity, Object data) {
    if (activity == null || activity.isFinishing()) {
        traceLog("api_log.txt", "Activity无效或正在关闭");
        return;
    }

    try {
        final boolean isDark = isThemeDark(activity);
        
        final String[] itemTexts = {
            "复制内容", "复读加一", "禁言此人", "踢出此人", "撤回消息", 
            "克隆头像", "成员信息", "设置头衔", "加解密工具", 
            "艾特列表", "上传头像", "为Ta点赞", "查看原始消息", 
            "艾特全体", "群打卡", "抽群字符", "回应表情", "执行代码"
        };
        
        final String[] itemIcons = {
            "📋", "🔁", "🔇", "🚫", "↩️", "👤", "📋", "⚜️", "🔐", 
            "👥", "🖼️", "👍", "📜", "📢", "✅", "🎰", "😀", "🎭"
        };

        final String quntext = data.msg;
        final String qun = data.peerUin;
        final String uin = data.userUin;
        final int msgtype = data.msgType;
        final long msgid = data.msgId;
        final int type = data.type;

        // 配色逻辑
        final int colorInt;
        if (isDark) {
            colorInt = UI_COLOR_ACCENT_DARK;
        } else {
            final String[] COLOR_POOL = {
                "#2196F3", "#4CAF50", "#9C27B0", "#E91E63", "#FF9800", 
                "#00BCD4", "#3F51B5", "#8BC34A", "#FFC107", "#795548"
            };
            colorInt = Color.parseColor(COLOR_POOL[new Random().nextInt(COLOR_POOL.length)]);
        }

        int adjustAlpha(int color, float factor) {
            int alpha = Math.round(Color.alpha(color) * factor);
            return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color));
        }

        LinearLayout rootLayout = new LinearLayout(activity);
        rootLayout.setOrientation(LinearLayout.VERTICAL);
        rootLayout.setPadding(0, dp(activity, 8), 0, dp(activity, 4));

        TextView titleView = new TextView(activity);
        titleView.setText("消息功能");
        titleView.setTextSize(16);
        titleView.setTypeface(null, Typeface.BOLD);
        titleView.setLetterSpacing(0.02f);
        titleView.setTextColor(isDark ? UI_COLOR_TEXT_DARK : UI_COLOR_TEXT_LIGHT);
        titleView.setPadding(dp(activity, 12), dp(activity, 6), dp(activity, 12), dp(activity, 8));
        titleView.setGravity(Gravity.CENTER_VERTICAL);
        rootLayout.addView(titleView);

        LinearLayout itemsContainer = new LinearLayout(activity);
        itemsContainer.setOrientation(LinearLayout.VERTICAL);
        itemsContainer.setPadding(dp(activity, 6), dp(activity, 4), dp(activity, 6), dp(activity, 4));

        final AlertDialog.Builder builder = new AlertDialog.Builder(activity, 
            isDark ? AlertDialog.THEME_DEVICE_DEFAULT_DARK : AlertDialog.THEME_DEVICE_DEFAULT_LIGHT);
        builder.setView(rootLayout);
        builder.setCancelable(true);
        builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                vibrate(activity, 32);
            }
        });
        builder.setOnDismissListener(new DialogInterface.OnDismissListener() {
            public void onDismiss(DialogInterface dialog) {
                traceLog("api_log.txt", "消息功能菜单已关闭");
            }
        });
        
        final AlertDialog customDialog = builder.create();

        for (int i = 0; i < itemTexts.length; i++) {
            final int index = i;

            final FrameLayout itemWrapper = new FrameLayout(activity);
            itemWrapper.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 
                LinearLayout.LayoutParams.WRAP_CONTENT));

            LinearLayout itemLayout = new LinearLayout(activity);
            itemLayout.setOrientation(LinearLayout.HORIZONTAL);
            itemLayout.setGravity(Gravity.CENTER_VERTICAL);
            itemLayout.setPadding(dp(activity, 10), dp(activity, 11), dp(activity, 10), dp(activity, 11));
            itemLayout.setClickable(false);

            final GradientDrawable glassBg = new GradientDrawable();
            glassBg.setShape(GradientDrawable.RECTANGLE);
            glassBg.setCornerRadius(dp(activity, 6));
            if (isDark) {
                glassBg.setColor(Color.parseColor("#FF2D2D2D"));
                glassBg.setStroke(dp(activity, 1), UI_COLOR_STROKE_DARK);
            } else {
                glassBg.setColor(adjustAlpha(colorInt, 0.05f));
                glassBg.setStroke(dp(activity, 1), UI_COLOR_STROKE_LIGHT);
            }
            
            itemLayout.setBackground(glassBg);

            TextView iconView = new TextView(activity);
            iconView.setText(itemIcons[i]);
            iconView.setTextSize(16);
            iconView.setTextColor(colorInt);
            LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(dp(activity, 18), dp(activity, 18));
            iconParams.gravity = Gravity.CENTER_VERTICAL;
            iconView.setLayoutParams(iconParams);
            iconView.setGravity(Gravity.CENTER);

            TextView textView = new TextView(activity);
            textView.setText(itemTexts[i]);
            textView.setTextSize(14);
            textView.setLetterSpacing(0.01f);
            textView.setTypeface(android.graphics.Typeface.create("sans-serif-medium", Typeface.NORMAL));
            textView.setTextColor(isDark ? UI_COLOR_TEXT_DARK : UI_COLOR_TEXT_LIGHT);
            textView.setPadding(dp(activity, 8), 0, 0, 0);
            textView.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f));

            TextView arrowView = new TextView(activity);
            arrowView.setText("›");
            arrowView.setTextSize(18);
            if (isDark) {
                arrowView.setTextColor(Color.parseColor("#FF888888"));
            } else {
                arrowView.setTextColor(adjustAlpha(colorInt, 0.3f));
            }
            arrowView.setGravity(Gravity.CENTER);

            final FrameLayout rippleOverlay = new FrameLayout(activity);
            rippleOverlay.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

            itemLayout.addView(iconView);
            itemLayout.addView(textView);
            itemLayout.addView(arrowView);
            itemWrapper.addView(itemLayout);
            itemWrapper.addView(rippleOverlay);

            itemWrapper.setTag(customDialog);

            itemWrapper.setOnTouchListener(new View.OnTouchListener() {
                private float touchX, touchY;
                private View rippleView = null;
                private android.animation.ValueAnimator syncAnimator = null;
                private Runnable cleanupTask = null;
                private boolean isMovedOut = false;

                private void resetBackgroundState() {
                    activity.runOnUiThread(new Runnable() {
                        public void run() {
                            if (isDark) {
                                glassBg.setColor(Color.parseColor("#FF2D2D2D"));
                            } else {
                                glassBg.setColor(adjustAlpha(colorInt, 0.05f));
                            }
                            itemLayout.setBackground(glassBg);
                        }
                    });
                }

                public boolean onTouch(View v, MotionEvent event) {
                    switch (event.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            isMovedOut = false;
                            touchX = event.getX();
                            touchY = event.getY();

                            if (rippleView == null) {
                                rippleView = new View(activity);
                                int rippleSize = dp(activity, 8);
                                FrameLayout.LayoutParams rippleParams = new FrameLayout.LayoutParams(rippleSize, rippleSize);
                                rippleParams.leftMargin = (int)touchX - rippleSize/2;
                                rippleParams.topMargin = (int)touchY - rippleSize/2;
                                rippleView.setLayoutParams(rippleParams);

                                GradientDrawable rippleDrawable = new GradientDrawable();
                                rippleDrawable.setShape(GradientDrawable.OVAL);
                                if (isDark) {
                                    rippleDrawable.setColor(Color.parseColor("#268AB4F8"));
                                } else {
                                    rippleDrawable.setColor(adjustAlpha(colorInt, 0.25f));
                                }
                                rippleView.setBackground(rippleDrawable);

                                rippleOverlay.addView(rippleView);
                            }

                            syncAnimator = android.animation.ValueAnimator.ofFloat(0f, 1f);
                            syncAnimator.setDuration(600);
                            syncAnimator.setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator());
                            syncAnimator.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener() {
                                public void onAnimationUpdate(android.animation.ValueAnimator animation) {
                                    float progress = (Float) animation.getAnimatedValue();
                                    rippleView.setScaleX(1f + progress * 9f);
                                    rippleView.setScaleY(1f + progress * 9f);
                                    rippleView.setAlpha(1f - progress);
                                    if (isDark) {
                                        glassBg.setColor(Color.parseColor("#FF383838"));
                                    } else {
                                        glassBg.setColor(adjustAlpha(colorInt, 0.05f + progress * 0.08f));
                                    }
                                    itemLayout.setBackground(glassBg);
                                }
                            });
                            syncAnimator.addListener(new android.animation.Animator.AnimatorListener() {
                                public void onAnimationEnd(android.animation.Animator animator) {
                                    if (rippleView != null && rippleView.getParent() != null) {
                                        rippleOverlay.removeView(rippleView);
                                        rippleView = null;
                                    }
                                    resetBackgroundState();
                                }
                                public void onAnimationStart(android.animation.Animator animator) {}
                                public void onAnimationCancel(android.animation.Animator animator) {}
                                public void onAnimationRepeat(android.animation.Animator animator) {}
                            });
                            syncAnimator.start();

                            cleanupTask = new Runnable() {
                                public void run() {
                                    if (rippleView != null && rippleView.getParent() != null) {
                                        rippleOverlay.removeView(rippleView);
                                        rippleView = null;
                                    }
                                }
                            };

                            return true;

                        case MotionEvent.ACTION_MOVE:
                            if (event.getX() < 0 || event.getX() > v.getWidth() || 
                                event.getY() < 0 || event.getY() > v.getHeight()) {
                                if (!isMovedOut) {
                                    isMovedOut = true;
                                }
                                if (syncAnimator != null) {
                                    syncAnimator.cancel();
                                }
                                if (cleanupTask != null) {
                                    cleanupTask.run();
                                }
                                resetBackgroundState();
                            }
                            return true;

                        case MotionEvent.ACTION_UP:
                            if (!isMovedOut && 
                                event.getX() >= 0 && event.getX() <= v.getWidth() && 
                                event.getY() >= 0 && event.getY() <= v.getHeight()) {
                                v.performClick();
                            }
                            
                            if (syncAnimator != null) {
                                syncAnimator.cancel();
                            }
                            if (cleanupTask != null) {
                                cleanupTask.run();
                            }
                            resetBackgroundState();
                            return true;

                        case MotionEvent.ACTION_CANCEL:
                            isMovedOut = true;
                            
                            if (syncAnimator != null) {
                                syncAnimator.cancel();
                            }
                            if (cleanupTask != null) {
                                cleanupTask.run();
                            }
                            resetBackgroundState();
                            return true;

                        default:
                            return false;
                    }
                }
            });

            itemWrapper.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    AlertDialog dialog = (AlertDialog) v.getTag();
                    if (dialog != null && dialog.isShowing()) {
                        dialog.dismiss();
                    }
                    OK = false;
                    // ThreadPool.execute(new Runnable() {
                        // public void run() {
                            try {
                                switch (index) {
							    case 0: // 复制内容
							        ((ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE)).setText(quntext.trim());
							        Toast("已复制内容");
							        break;
							        
							    case 1: // 复读加一
							        try {
							            if (data == null || data.data == null) {
							                Toast("消息数据无效");
							                return;
							            }
							            MsgRecord originalRecord = (MsgRecord) data.data;
							            ArrayList repeatElements = new ArrayList();
							            List originalElements = originalRecord.elements;
							            for (int i = 0; i < originalElements.size(); i++) {
							                repeatElements.add(originalElements.get(i));
							            }
							            String targetUid = (type == 1) ? getUidFromUin(qun) : qun;
							            Contact contact = new Contact(type, targetUid, "");
							            ((IMsgService) QRoute.api(IMsgService.class)).sendMsg(contact, repeatElements, null);
							            Toast("复读成功");
							            traceLog("api_log.txt", "目标:" + qun + " 元素数:" + repeatElements.size());
							        } catch (Throwable e) {
							            traceLog("api_log.txt","" + e.getMessage());
							            Toast("复读失败:" + e.getMessage());
							        }
							        break;
							
							    case 2: // 禁言此人
							        showShutUpDialog(activity, qun, uin);
							        // Toast("禁言操作已执行");
							        break;
							        
								case 3: // 踢出此人
								    try {
								        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
								        builder.setTitle("确认踢出成员");
								        builder.setMessage("QQ: " + uin + "\n请选择踢出方式");
								        
								        builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
								            public void onClick(DialogInterface dialog, int which) {
								                dialog.dismiss();
								            }
								        });
								        
								        builder.setNeutralButton("永久踢出", new DialogInterface.OnClickListener() {
								            public void onClick(DialogInterface dialog, int which) {
								                kickGroup(qun, uin, true);
								                Toast("永久踢出操作已执行");
								                dialog.dismiss();
								            }
								        });
								        
								        builder.setPositiveButton("确认踢出", new DialogInterface.OnClickListener() {
								            public void onClick(DialogInterface dialog, int which) {
								                kickGroup(qun, uin, false);
								                Toast("踢出操作已执行");
								                dialog.dismiss();
								            }
								        });
								        
								        builder.show();
								    } catch (Throwable e) {
								        traceLog("api_log.txt", "踢出弹窗异常: " + e.getMessage());
								        Toast("弹窗显示失败: " + e.getMessage());
								    }
								    break;
								
							    case 4: // 撤回消息
							        recallMsg(type, qun, msgid);
							        Toast("撤回操作已执行");
							        break;
							        
							    case 5: // 克隆头像
							    handleCloneAvatar(uin);
							        break;
							
							    case 6: // 成员信息
							        try {
							            StringBuilder infoBuilder = new StringBuilder();
							            Card card = null;
							            
							            try {
							                card = (Card) GetCard(uin);
							            } catch (Throwable e) {
							                traceLog("api_log.txt", "QQ:" + uin + " 错误:" + e.getMessage());
							                card = null;
							            }
							            
							            if (type == 2) {
							                Object memberInfoRaw = getMemberInfo(qun, uin);
							                String infoStr = memberInfoRaw.toString()
							                    .replace("\"", "").replace("MemberInfo(", "").replace("})}", "}");
							                
							                String[] pairs = infoStr.split(",");
							                String uinStr = "获取失败", name = "获取失败", uinLevel = "0", role = "UNKNOWN", 
							                       joinTime = "0", lastTime = "0", troopNick = "未设置";
							                
							                for (String pair : pairs) {
							                    pair = pair.trim();
							                    if (pair.startsWith("uin=")) uinStr = extractValue(pair, "uin");
							                    else if (pair.startsWith("uinName=")) name = extractValue(pair, "uinName");
							                    else if (pair.startsWith("uinLevel=")) uinLevel = extractValue(pair, "uinLevel");
							                    else if (pair.startsWith("role=")) role = extractValue(pair, "role");
							                    else if (pair.startsWith("joinGroupTime=")) joinTime = extractValue(pair, "joinGroupTime");
							                    else if (pair.startsWith("lastActiveTime=")) lastTime = extractValue(pair, "lastActiveTime");
							                    else if (pair.startsWith("troopnick=")) troopNick = extractValue(pair, "troopnick");
							                }
							                
							                if (card != null && card.strNick != null && !card.strNick.isEmpty()) {
							                    name = card.strNick;
							                }
							                
							                infoBuilder.append("QQ: ").append(uinStr).append("\n\n");
							                infoBuilder.append("昵称: ").append(name).append("\n\n");
							                infoBuilder.append("群昵称: ").append(troopNick).append("\n\n");
							                infoBuilder.append("群等级: Lv.").append(uinLevel).append("\n\n");
							                
							                String qqLevel = (card != null && card.iQQLevel != null) ? 
							                    String.valueOf(card.iQQLevel) : uinLevel;
							                infoBuilder.append("QQ等级: Lv.").append(qqLevel).append("\n\n");
							                
							                infoBuilder.append("角色: ").append(convertRole(role)).append("\n\n");
							                infoBuilder.append("入群时间: ").append(timestampToDate(Long.parseLong(joinTime) * 1000)).append("\n\n");
							                infoBuilder.append("最后活跃: ").append(timestampToDate(Long.parseLong(lastTime) * 1000)).append("\n\n");
							                
							                if (card != null) {
							                    if (card.iQQVipLevel != null && card.iQQVipLevel > 0) {
							                        infoBuilder.append("QQ会员: Lv.").append(card.iQQVipLevel).append("\n\n");
							                    }
							                    if (card.iSuperVipLevel != null && card.iSuperVipLevel > 0) {
							                        infoBuilder.append("超级会员: Lv.").append(card.iSuperVipLevel).append("\n\n");
							                    }
							                    infoBuilder.append("名片赞: ").append(card.lVoteCount != null ? card.lVoteCount : 0).append("\n\n");
							                    infoBuilder.append("登录天数: ").append(card.lLoginDays != null ? card.lLoginDays : 0).append("\n\n");
							                    if (card.qid != null && !card.qid.isEmpty()) {
							                        infoBuilder.append("QID: ").append(card.qid).append("\n\n");
							                    }
							                }
							                
							                for (String pair : infoStr.split(",")) {
							                    if (pair.trim().startsWith("gagTimeStamp=")) {
							                        String ts = extractValue(pair.trim(), "gagTimeStamp");
							                        infoBuilder.append("禁言状态: ").append(getGagStatus(ts));
							                        break;
							                    }
							                }
							            } else {
							                if (card != null) {
							                    infoBuilder.append("QQ: ").append(uin).append("\n\n");
							                    infoBuilder.append("昵称: ").append(card.strNick != null ? card.strNick : "未设置").append("\n\n");
							                    infoBuilder.append("QQ等级: Lv.").append(card.iQQLevel != null ? card.iQQLevel : 0).append("\n\n");
							                    
							                    if (card.iQQVipLevel != null && card.iQQVipLevel > 0) {
							                        infoBuilder.append("QQ会员: Lv.").append(card.iQQVipLevel).append("\n\n");
							                    }
							                    if (card.iSuperVipLevel != null && card.iSuperVipLevel > 0) {
							                        infoBuilder.append("超级会员: Lv.").append(card.iSuperVipLevel).append("\n\n");
							                    }
							                    
							                    infoBuilder.append("名片赞: ").append(card.lVoteCount != null ? card.lVoteCount : 0).append("\n\n");
							                    infoBuilder.append("登录天数: ").append(card.lLoginDays != null ? card.lLoginDays : 0).append("\n\n");
							                    
							                    if (card.qid != null && !card.qid.isEmpty()) {
							                        infoBuilder.append("QID: ").append(card.qid).append("\n\n");
							                    }
							                } else {
							                    infoBuilder.append("Card对象获取失败");
							                }
							            }
							            
							            setTips("成员信息", infoBuilder.toString());
							        } catch (Throwable e) {
							            traceLog("api_log.txt", "" + e.getMessage());
							            Toast("获取失败:" + e.getMessage());
							        }
							        break;
							
							    case 7: // 设置头衔
							        showTitleDialog(activity, qun, uin);
							        break;
							        
							    case 8: // 加解密工具
							        showEncryptDecryptDialog(activity, quntext);
							        break;
							        
							    case 9: // 艾特列表
							        if (msgtype == 2 && data.atList != null && data.atList.size() > 0) {
							            StringBuilder atStr = new StringBuilder();
							            boolean hasValidData = false;
							            
							            for (int i = 0; i < data.atList.size(); i++) {
							                String atUin = data.atList.get(i);
							                String nickName = "获取失败";
							                
							                try {
							                    Card card = (Card) GetCard(atUin);
							                    if (card != null && card.strNick != null) {
							                        nickName = card.strNick;
							                    } else {
							                        nickName = "缓存缺失";
							                    }
							                } catch (Throwable e) {
							                    traceLog("api_log.txt", "QQ:" + atUin + " 错误:" + e.getMessage());
							                }
							                
							                if (i > 0) atStr.append("\n");
							                atStr.append(nickName).append(" (").append(atUin).append(")");
							                hasValidData = true;
							            }
							            
							            if (hasValidData) {
							                setTips("艾特列表", atStr.toString());
							            } else {
							                Toast("此消息无有效艾特数据");
							            }
							        } else {
							            Toast("此消息无艾特列表");
							        }
							        break;
							
							    case 10: // 上传头像
							        if (msgtype == 2 && quntext.contains("pic")) {
							        handleUploadAvatar(quntext);
							        } else {
							            Toast("非图片消息！");
							        }
							        break;
							        
							    case 11: // 为Ta点赞
							        sendZan(uin, 20);
							        Toast("为Ta点赞成功");
							        break;
							        
							    case 12:
							        try {
							            String rawData = data.data.toString();
							            String formatted = formatObjectString(rawData);
							            setTips("原始消息内容", formatted);
							        } catch (Throwable e) {
							            traceLog("api_log.txt", e.getMessage() + " 长度:" + data.data.toString().length());
							            setTips("原始消息内容", data.data.toString() + "\n\n【格式化失败】\n错误:" + e.getMessage());
							        }
							        break;
							        
							    case 13: // 
							        // String allAtCode = "@everyone";
							        sendMsg(qun, "[atUin=0]",type);
							        break;
							        
							    case 14: // 群打卡
							    boolean sign = CheckSign(qun, qq);
							    if(sign){
							        Toast("群："+qun+"打卡成功");
							        } else {
							        Toast("群："+qun+"打卡失败");
							        }
							        break;
							        
							    case 15: // 抽群字符
							        Toast("抽屁还没实现呢");
							        break;
							        
							    case 16: // 
							        Toast("空壳");
							        break;
							        
							    case 17: //执行代码
							        showCodeConsoleDialog(activity,data);
							        break;
							        
								}
                            } catch (Exception e) {
                                traceLog("api_log.txt", "索引" + index + " 错误:" + e.getMessage());
                                Toast("操作失败:" + e.getMessage());
                                OK = false ;
                            }
                        // }
                    // }).start();
                }
            });

            if (i > 0) {
                View topHighlight = new View(activity);
                LinearLayout.LayoutParams hlParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, dp(activity, 3));
                topHighlight.setLayoutParams(hlParams);
                topHighlight.setBackgroundColor(Color.parseColor("#0DFFFFFF"));
                itemsContainer.addView(topHighlight);
            }

            itemWrapper.setAlpha(0f);
            itemWrapper.setTranslationY(dp(activity, 10));
            new android.os.Handler().postDelayed(new Runnable() {
                public void run() {
                    itemWrapper.animate()
                        .alpha(1f)
                        .translationY(0f)
                        .setDuration(200)
                        .setInterpolator(new android.view.animation.DecelerateInterpolator());
                }
            }, i * 30);

            itemsContainer.addView(itemWrapper);
        }

        ScrollView scrollContainer = new ScrollView(activity);
        scrollContainer.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(activity, 500)));
        scrollContainer.setFillViewport(true);
        scrollContainer.setVerticalScrollBarEnabled(true);
        scrollContainer.setScrollbarFadingEnabled(false);
        scrollContainer.setOverScrollMode(View.OVER_SCROLL_NEVER);
        scrollContainer.addView(itemsContainer);
        rootLayout.addView(scrollContainer);

        customDialog.show();

        GradientDrawable dialogBg = new GradientDrawable();
        dialogBg.setColor(Color.parseColor(isDark ? UI_COLOR_BG_DARK : UI_COLOR_BG_LIGHT));
        dialogBg.setCornerRadius(dp(activity, 8));
        customDialog.getWindow().setBackgroundDrawable(dialogBg);

        WindowManager.LayoutParams windowParams = customDialog.getWindow().getAttributes();
        windowParams.width = Math.min(dp(activity, 240), 
            activity.getResources().getDisplayMetrics().widthPixels - dp(activity, 30));
        customDialog.getWindow().setAttributes(windowParams);

        traceLog("api_log.txt", "消息功能菜单显示成功");

    } catch (Exception e) {
        traceLog("api_log.txt", "显示消息功能菜单异常: " + e.getMessage());
        Toast("菜单显示失败:" + e.getMessage());
    }
}


boolean isFilePickerHooked = false;

void 显示菜单(final Activity activity) {
    if (activity == null || activity.isFinishing()) {
        traceLog("api_log.txt", "显示菜单异常: Activity无效或正在关闭");
        OK = false;
        return;
    }

    try {
        final String[] itemTexts = {
            "Java脚本", "设置界面", "开/关模拟定位", "设置经纬度", "开/关输入框提示", "设置输入框提示词",
            "消息统计", "更新日志", "取消/重载", "运行状态", "HTML浏览器"
        };
        final String[] itemIcons = {
        	
        	"📜", "⚙️", "📍", "🌍", "🕹", "🍭", "📊", "📝", "🔄", "📈", "🌐"
        
        };

        final boolean isDarkMode = isThemeDark(activity);

        // 配色定义
        final String COLOR_PRIMARY;
        final String COLOR_SURFACE;
        final String COLOR_ON_SURFACE;
        final String COLOR_OUTLINE;
        final String COLOR_RIPPLE;

        if (isDarkMode) {
            COLOR_PRIMARY = "#FF8AB4F8";
            COLOR_SURFACE = "#FF121212";
            COLOR_ON_SURFACE = "#FFEFEFEF";
            COLOR_OUTLINE = "#FF333333";
            COLOR_RIPPLE = "#268AB4F8";
        } else {
            final String[] COLOR_POOL = {
                "#2196F3", "#4CAF50", "#9C27B0", "#E91E63", "#FF9800", "#00BCD4", "#3F51B5", "#8BC34A", "#FFC107"
            };
            COLOR_PRIMARY = COLOR_POOL[new java.util.Random().nextInt(COLOR_POOL.length)];
            COLOR_SURFACE = "#FFFFFFFF";
            COLOR_ON_SURFACE = "#FF000000";
            COLOR_OUTLINE = "#1AFFFFFF";
            COLOR_RIPPLE = "#26" + COLOR_PRIMARY.substring(2);
        }
        final int colorInt = android.graphics.Color.parseColor(COLOR_PRIMARY);

        int adjustAlpha(int color, float factor) {
            int alpha = Math.round(android.graphics.Color.alpha(color) * factor);
            return android.graphics.Color.argb(alpha, android.graphics.Color.red(color), android.graphics.Color.green(color), android.graphics.Color.blue(color));
        }

        // 尺寸参数
        final int BASE_ITEM_HEIGHT = dp(activity, 40);
        final int ITEM_HEIGHT = (int) (BASE_ITEM_HEIGHT * 1.15f);
        final int ITEM_MARGIN = dp(activity, 4) + 1;
        final int COMPACT_PADDING_MID = dp(activity, 12);
        final int COMPACT_PADDING_TINY = dp(activity, 2);
        final int COMPACT_ICON_SIZE = dp(activity, 28);
        final int COMPACT_CORNER = dp(activity, 16);
        final int COMPACT_WINDOW_MAX_WIDTH = dp(activity, 260);
        final int ITEM_SHADOW = dp(activity, 2);
        final int BTN_MIN_HEIGHT = dp(activity, 20);
        final int BTN_BOTTOM_MARGIN = dp(activity, 4);
        final int BTN_HORIZONTAL_PADDING = dp(activity, 12);
        final int BASE_PUSH_DISTANCE = dp(activity, 6);
        final int MAX_PUSH_DISTANCE = dp(activity, 12);
        final float CLICK_SCALE = 1.15f;

        final java.util.List itemList = new java.util.ArrayList();

        activity.runOnUiThread(new Runnable() {
            public void run() {
                try {
                    // 根布局
                    LinearLayout rootLayout = new LinearLayout(activity);
                    rootLayout.setOrientation(LinearLayout.VERTICAL);
                    rootLayout.setPadding(0, COMPACT_PADDING_MID, 0, COMPACT_PADDING_TINY);
                    rootLayout.setBackgroundColor(android.graphics.Color.parseColor(COLOR_SURFACE));

                    // 标题栏容器
                    LinearLayout titleBarLayout = new LinearLayout(activity);
                    titleBarLayout.setLayoutParams(new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT));
                    titleBarLayout.setOrientation(LinearLayout.HORIZONTAL);
                    titleBarLayout.setGravity(Gravity.CENTER_VERTICAL);
                    titleBarLayout.setPadding(COMPACT_PADDING_MID + 8, COMPACT_PADDING_MID, COMPACT_PADDING_MID, COMPACT_PADDING_MID);

                    // 标题文字
                    TextView titleView = new TextView(activity);
                    titleView.setText("功能菜单");
                    titleView.setTextSize(17);
                    titleView.setTypeface(null, android.graphics.Typeface.BOLD);
                    titleView.setLetterSpacing(0.01f);
                    titleView.setTextColor(android.graphics.Color.parseColor(COLOR_ON_SURFACE));
                    titleView.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f));

                    View themeToggle;
                    boolean imageLoaded = false;
                    int tintColor = isDarkMode ? android.graphics.Color.parseColor("#E0E0E0") : android.graphics.Color.parseColor("#333333");
                    // 尝试加载图片文件（PNG/JPG）
                    ImageView imgToggle = new ImageView(activity);
                    try {
                        String imgName = isDarkMode ? "黑.png" : "白.png";
                        String imgPath = rootPath + imgName;
                        java.io.File imgFile = new java.io.File(imgPath);
                        
                        if (imgFile.exists()) {
                            android.graphics.Bitmap bmp = android.graphics.BitmapFactory.decodeFile(imgPath);
                            if (bmp != null) {
                                // 设置tint颜色实现主题切换
                                imgToggle.setColorFilter(tintColor);
                                
                                imgToggle.setImageBitmap(bmp);
                                imgToggle.setScaleType(ImageView.ScaleType.FIT_CENTER);
                                imageLoaded = true;
                                traceLog("api_log.txt", "主题图标加载成功: " + imgName);
                            }
                        }
                    } catch (Throwable e) {
                        // traceLog("api_log.txt", "主题图标加载失败: " + e.getMessage());
                        // 图片加载失败，忽略，走降级流程
                    }

                    if (imageLoaded) {
                        themeToggle = imgToggle;
                    } else {
                        // 降级为文字图标 (简约黑色线条风格)
                        TextView txtToggle = new TextView(activity);
                        txtToggle.setText(isDarkMode ? "☾" : "☀"); 
                        txtToggle.setTextSize(22); 
                        // 亮色模式黑色，暗色模式浅灰（单色简约）
                        txtToggle.setTextColor(isDarkMode ? android.graphics.Color.parseColor("#E0E0E0") : android.graphics.Color.parseColor("#333333"));
                        txtToggle.setGravity(Gravity.CENTER);
                        themeToggle = txtToggle;
                    }

                    // 通用布局参数
                    LinearLayout.LayoutParams themeParams = new LinearLayout.LayoutParams(COMPACT_ICON_SIZE, COMPACT_ICON_SIZE);
                    themeParams.rightMargin = dp(activity, 15);
                    themeToggle.setLayoutParams(themeParams);
                    themeToggle.setClickable(true);
                    themeToggle.setBackground(null); // 无背景，简约风格
                    
                    themeToggle.setOnClickListener(new View.OnClickListener() {
                        public void onClick(View v) {
                            try {
                                vibrate(activity, 32);
                                boolean current = getBoolean("settings", "黑白", false);
                                putBoolean("settings", "黑白", !current);
                                Toast("主题已切换");
                                // 强制关闭弹窗
                                Object tag = v.getTag();
                                if(tag instanceof AlertDialog) {
                                    ((AlertDialog)tag).dismiss();
                                }
                            } catch (Exception e) {
                                Toast("切换失败: " + e.getMessage());
                            }
                        }
                    });

                    // 设置图标
                    final ImageView settingsIcon = new ImageView(activity);
                    LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(COMPACT_ICON_SIZE, COMPACT_ICON_SIZE);
                    iconParams.leftMargin = COMPACT_PADDING_MID;
                    settingsIcon.setLayoutParams(iconParams);
                    settingsIcon.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    settingsIcon.setClickable(true);
                    settingsIcon.setFocusable(true);

                    // 加载设置图标（PNG/JPG）
                    try {
                        String iconPathStr = null;
                        try { iconPathStr = settingiconPath; } catch(Exception e) {}
                        
                        if (iconPathStr != null && new java.io.File(iconPathStr).exists()) {
                            android.graphics.Bitmap bitmap = android.graphics.BitmapFactory.decodeFile(iconPathStr);
                            if (bitmap != null) {
                                settingsIcon.setImageBitmap(bitmap);
                                settingsIcon.setColorFilter(tintColor); // 动态tint
                                traceLog("api_log.txt", "设置图标加载成功");
                            } else throw new Exception("Bitmap解码失败");
                        } else throw new Exception("文件不存在: " + iconPathStr);
                    } catch (Throwable loadError) {
                        traceLog("api_log.txt", "设置图标加载失败: " + loadError.getMessage());
                        // 降级为绘制文字
                        android.graphics.Bitmap.Config conf = android.graphics.Bitmap.Config.ARGB_8888;
                        android.graphics.Bitmap bmp = android.graphics.Bitmap.createBitmap(COMPACT_ICON_SIZE, COMPACT_ICON_SIZE, conf);
                        android.graphics.Canvas canvas = new android.graphics.Canvas(bmp);
                        android.graphics.Paint paint = new android.graphics.Paint();
                        paint.setColor(colorInt);
                        paint.setTextSize(dp(activity, 12));
                        paint.setAntiAlias(true);
                        paint.setTextAlign(android.graphics.Paint.Align.CENTER);
                        canvas.drawText("设置", COMPACT_ICON_SIZE / 2, COMPACT_ICON_SIZE / 2 + COMPACT_PADDING_TINY, paint);
                        settingsIcon.setImageBitmap(bmp);
                    }

                    if (!isFilePickerHooked) {
                        final int REQUEST_CODE_ICON = 1005;
                        try {
                            Class activityClass = Class.forName("android.app.Activity");
                            java.lang.reflect.Method onResultMethod = activityClass.getDeclaredMethod(
                                "onActivityResult",
                                int.class,
                                int.class,
                                Intent.class
                            );
                            onResultMethod.setAccessible(true);

                            XposedBridge.hookMethod(onResultMethod, new XC_MethodHook() {
                                protected void afterHookedMethod(XC_MethodHook.MethodHookParam param) {
                                    try {
                                        Activity targetActivity = (Activity) param.thisObject;
                                        int requestCode = ((Integer) param.args[0]).intValue();
                                        int resultCode = ((Integer) param.args[1]).intValue();
                                        Intent data = (Intent) param.args[2];

                                        if (requestCode == REQUEST_CODE_ICON && targetActivity.equals(activity)) {
                                            if (resultCode == Activity.RESULT_OK && data != null) {
                                                final Intent finalData = data;
                                                ThreadPool.execute(new Runnable() {
                                                    public void run() {
                                                        java.io.FileOutputStream fos = null;
                                                        java.io.InputStream is = null;
                                                        try {
                                                            android.net.Uri uri = finalData.getData();
                                                            String targetPath = null;
                                                            try { targetPath = iconPath; } catch(Exception e) {}

                                                            if (uri != null && targetPath != null) {
                                                                traceLog("api_log.txt", "开始处理文件: " + uri.toString()); 
                                                                is = activity.getContentResolver().openInputStream(uri);
                                                                java.io.File dest = new java.io.File(targetPath);
                                                                java.io.File parent = dest.getParentFile();
                                                                if (parent != null && !parent.exists()) {
                                                                    parent.mkdirs();
                                                                }

                                                                fos = new java.io.FileOutputStream(dest);
                                                                byte[] buffer = new byte[8192];
                                                                int bytesRead;
                                                                while ((bytesRead = is.read(buffer)) != -1) {
                                                                    fos.write(buffer, 0, bytesRead);
                                                                }
                                                                fos.flush();
                                                                Toast("图标已保存，重启后生效");
                                                            }
                                                        } catch (Throwable e) {
                                                            traceLog("api_log.txt", "文件处理失败: " + e.getMessage());
                                                            Toast("处理失败");
                                                        } finally {
                                                            try { if (fos != null) fos.close(); } catch(Exception e){}
                                                            try { if (is != null) is.close(); } catch(Exception e){}
                                                        }
                                                    }
                                                });
                                            }
                                        }
                                    } catch (Throwable callbackError) {
                                        traceLog("api_log.txt", "回调异常: " + callbackError.getMessage());
                                    }
                                }
                            });
                            isFilePickerHooked = true; 
                            traceLog("api_log.txt", "Hook注册成功");
                        } catch (Throwable hookError) {
                            traceLog("api_log.txt", "Hook注册失败: " + hookError.getMessage());
                        }
                    }

                    settingsIcon.setOnClickListener(new View.OnClickListener() {
                        public void onClick(View v) {
                            vibrate(activity, 48);
                            new android.os.Handler().postDelayed(new Runnable() {
                                public void run() {
                                    try {
                                        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                                        intent.setType("image/*");
                                        intent.addCategory(Intent.CATEGORY_OPENABLE);
                                        activity.startActivityForResult(intent, 1005);
                                    } catch (Throwable e) {
                                        traceLog("api_log.txt", "打开文件选择器失败: " + e.getMessage());
                                    }
                                }
                            }, 100);
                        }
                    });

                    titleBarLayout.addView(titleView);
                    titleBarLayout.addView(themeToggle); 
                    titleBarLayout.addView(settingsIcon); 
                    rootLayout.addView(titleBarLayout);

                    // 菜单列表容器
                    LinearLayout itemsContainer = new LinearLayout(activity);
                    itemsContainer.setLayoutParams(new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, 0, 1.0f));
                    itemsContainer.setOrientation(LinearLayout.VERTICAL);
                    itemsContainer.setPadding(COMPACT_PADDING_MID, COMPACT_PADDING_TINY, COMPACT_PADDING_MID, COMPACT_PADDING_TINY);
                    itemsContainer.setBackgroundColor(android.graphics.Color.parseColor(COLOR_SURFACE));

                    // 构建 Dialog
                    final AlertDialog.Builder builder = new AlertDialog.Builder(activity, isDarkMode ? AlertDialog.THEME_DEVICE_DEFAULT_DARK : AlertDialog.THEME_DEVICE_DEFAULT_LIGHT);
                    builder.setView(rootLayout);
                    builder.setCancelable(true);
                    builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                            OK = false;
                            vibrate(activity, 48);
                        }
                    });
                    builder.setOnDismissListener(new DialogInterface.OnDismissListener() {
                        public void onDismiss(DialogInterface dialog) { OK = false; }
                    });
                    final AlertDialog customDialog = builder.create();
                    
                    themeToggle.setTag(customDialog);

                    // 生成菜单项 (动画逻辑)
                    for (int i = 0; i < itemTexts.length; i++) {
                        final int index = i;
                        final FrameLayout itemWrapper = new FrameLayout(activity);
                        LinearLayout.LayoutParams wrapperParams = new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT, ITEM_HEIGHT);
                        wrapperParams.bottomMargin = ITEM_MARGIN;
                        itemWrapper.setLayoutParams(wrapperParams);

                        final LinearLayout itemLayout = new LinearLayout(activity);
                        itemLayout.setOrientation(LinearLayout.HORIZONTAL);
                        itemLayout.setGravity(Gravity.CENTER_VERTICAL);
                        itemLayout.setPadding(COMPACT_PADDING_MID, COMPACT_PADDING_TINY, COMPACT_PADDING_MID, COMPACT_PADDING_TINY);
                        itemLayout.setClickable(false);
                        
                        if (isDarkMode) {
                            itemLayout.setElevation(dp(activity, 1));
                            itemLayout.setTranslationZ(dp(activity, 1));
                        } else {
                            itemLayout.setElevation(ITEM_SHADOW);
                            itemLayout.setTranslationZ(ITEM_SHADOW);
                        }

                        // 背景 Drawable
                        final android.graphics.drawable.GradientDrawable glassBg = new android.graphics.drawable.GradientDrawable();
                        glassBg.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
                        glassBg.setCornerRadius(COMPACT_CORNER);
                        glassBg.setColor(isDarkMode ? android.graphics.Color.parseColor("#FF2D2D2D") : adjustAlpha(colorInt, 0.05f));
                        glassBg.setStroke(dp(activity, 1), android.graphics.Color.parseColor(isDarkMode ? COLOR_OUTLINE : COLOR_OUTLINE));
                        itemLayout.setBackground(glassBg);

                        TextView iconView = new TextView(activity);
                        iconView.setText(itemIcons[i]);
                        iconView.setTextSize(18);
                        iconView.setTextColor(colorInt);
                        LinearLayout.LayoutParams iconParamsItem = new LinearLayout.LayoutParams(COMPACT_ICON_SIZE, COMPACT_ICON_SIZE);
                        iconParamsItem.gravity = Gravity.CENTER_VERTICAL;
                        iconView.setLayoutParams(iconParamsItem);
                        iconView.setGravity(Gravity.CENTER);

                        TextView textView = new TextView(activity);
                        textView.setText(itemTexts[i]);
                        textView.setTextSize(14);
                        textView.setTypeface(android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL));
                        textView.setTextColor(android.graphics.Color.parseColor(COLOR_ON_SURFACE));
                        textView.setPadding(COMPACT_PADDING_MID, 0, 0, 0);
                        textView.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f));

                        TextView arrowView = new TextView(activity);
                        arrowView.setText("›");
                        arrowView.setTextSize(20);
                        arrowView.setTextColor(isDarkMode ? android.graphics.Color.parseColor("#FF888888") : adjustAlpha(colorInt, 0.3f));
                        LinearLayout.LayoutParams arrowParams = new LinearLayout.LayoutParams(
                            COMPACT_ICON_SIZE - dp(activity, 8), LinearLayout.LayoutParams.MATCH_PARENT);
                        arrowParams.gravity = Gravity.CENTER;
                        arrowView.setLayoutParams(arrowParams);
                        arrowView.setGravity(Gravity.CENTER);

                        final FrameLayout rippleOverlay = new FrameLayout(activity);
                        rippleOverlay.setLayoutParams(new FrameLayout.LayoutParams(
                            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

                        itemLayout.addView(iconView);
                        itemLayout.addView(textView);
                        itemLayout.addView(arrowView);
                        itemWrapper.addView(itemLayout);
                        itemWrapper.addView(rippleOverlay);
                        itemWrapper.setTag(customDialog);

                        // 触摸反馈
                        itemWrapper.setOnTouchListener(new View.OnTouchListener() {
                            private float touchX, touchY;
                            private View rippleView = null;
                            private android.animation.ValueAnimator syncAnimator = null;
                            private Runnable cleanupTask = null;
                            private boolean isMovedOut = false;

                            private void resetBackgroundState() {
                                activity.runOnUiThread(new Runnable() {
                                    public void run() {
                                        glassBg.setColor(isDarkMode ? android.graphics.Color.parseColor("#FF2D2D2D") : adjustAlpha(colorInt, 0.05f));
                                        itemLayout.setBackground(glassBg);
                                    }
                                });
                            }

                            public boolean onTouch(View v, MotionEvent event) {
                                try {
                                    switch (event.getAction()) {
                                        case MotionEvent.ACTION_DOWN:
                                            isMovedOut = false;
                                            touchX = event.getX();
                                            touchY = event.getY();

                                            if (rippleView == null) {
                                                rippleView = new View(activity);
                                                int rippleSize = dp(activity, 8); // 初始大小
                                                FrameLayout.LayoutParams rippleParams = new FrameLayout.LayoutParams(rippleSize, rippleSize);
                                                rippleParams.leftMargin = (int)touchX - rippleSize/2;
                                                rippleParams.topMargin = (int)touchY - rippleSize/2;
                                                rippleView.setLayoutParams(rippleParams);

                                                android.graphics.drawable.GradientDrawable rippleDrawable = new android.graphics.drawable.GradientDrawable();
                                                rippleDrawable.setShape(android.graphics.drawable.GradientDrawable.OVAL);
                                                rippleDrawable.setColor(isDarkMode ? android.graphics.Color.parseColor(COLOR_RIPPLE) : adjustAlpha(colorInt, 0.25f));
                                                rippleView.setBackground(rippleDrawable);

                                                rippleOverlay.addView(rippleView);
                                            }

                                            syncAnimator = android.animation.ValueAnimator.ofFloat(0f, 1f);
                                            syncAnimator.setDuration(600);
                                            syncAnimator.setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator());
                                            syncAnimator.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener() {
                                                public void onAnimationUpdate(android.animation.ValueAnimator animation) {
                                                    float progress = (Float) animation.getAnimatedValue();
                                                    rippleView.setScaleX(1f + progress * 9f);
                                                    rippleView.setScaleY(1f + progress * 9f);
                                                    rippleView.setAlpha(1f - progress);
                                                    
                                                    if (isDarkMode) {
                                                        glassBg.setColor(android.graphics.Color.parseColor("#FF383838"));
                                                    } else {
                                                        glassBg.setColor(adjustAlpha(colorInt, 0.05f + progress * 0.08f));
                                                    }
                                                    itemLayout.setBackground(glassBg);
                                                }
                                            });
                                            syncAnimator.addListener(new android.animation.Animator.AnimatorListener() {
                                                public void onAnimationEnd(android.animation.Animator animator) {
                                                    if (rippleView != null && rippleView.getParent() != null) {
                                                        rippleOverlay.removeView(rippleView);
                                                        rippleView = null;
                                                    }
                                                    resetBackgroundState();
                                                }
                                                public void onAnimationStart(android.animation.Animator animator) {}
                                                public void onAnimationCancel(android.animation.Animator animator) {}
                                                public void onAnimationRepeat(android.animation.Animator animator) {}
                                            });
                                            syncAnimator.start();

                                            cleanupTask = new Runnable() {
                                                public void run() {
                                                    if (rippleView != null && rippleView.getParent() != null) {
                                                        rippleOverlay.removeView(rippleView);
                                                        rippleView = null;
                                                    }
                                                }
                                            };
                                            return true;

                                        case MotionEvent.ACTION_MOVE:
                                            if (event.getX() < 0 || event.getX() > v.getWidth() || 
                                                event.getY() < 0 || event.getY() > v.getHeight()) {
                                                if (!isMovedOut) {
                                                    isMovedOut = true;
                                                }
                                                if (syncAnimator != null) syncAnimator.cancel();
                                                if (cleanupTask != null) cleanupTask.run();
                                                resetBackgroundState();
                                            }
                                            return true;

                                        case MotionEvent.ACTION_UP:
                                            if (!isMovedOut && 
                                                event.getX() >= 0 && event.getX() <= v.getWidth() && 
                                                event.getY() >= 0 && event.getY() <= v.getHeight()) {
                                                v.performClick();
                                            }
                                            if (syncAnimator != null) syncAnimator.cancel();
                                            if (cleanupTask != null) cleanupTask.run();
                                            resetBackgroundState();
                                            return true;

                                        case MotionEvent.ACTION_CANCEL:
                                            isMovedOut = true;
                                            if (syncAnimator != null) syncAnimator.cancel();
                                            if (cleanupTask != null) cleanupTask.run();
                                            resetBackgroundState();
                                            return true;

                                        default:
                                            return false;
                                    }
                                } catch(Throwable t) { return false; }
                            }
                        });

                        itemWrapper.setOnClickListener(new View.OnClickListener() {
                            public void onClick(View v) {
                                try {
                                    // 联动挤开动画
                                    for (int j = 0; j < itemList.size(); j++) {
                                        final FrameLayout item = (FrameLayout) itemList.get(j);
                                        int indexDiff = Math.abs(j - index);
                                        int pushDistance = BASE_PUSH_DISTANCE + (indexDiff * 2);
                                        if(pushDistance > MAX_PUSH_DISTANCE) pushDistance = MAX_PUSH_DISTANCE;
                                        
                                        final float targetTransY = (j == index) ? 0f : (j < index ? -pushDistance : pushDistance);
                                        final float targetScale = (j == index) ? CLICK_SCALE : 1.0f;

                                        android.animation.ValueAnimator animator = android.animation.ValueAnimator.ofFloat(0f, 1f);
                                        animator.setDuration(180);
                                        animator.setInterpolator(new android.view.animation.DecelerateInterpolator());
                                        animator.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener() {
                                            public void onAnimationUpdate(android.animation.ValueAnimator animation) {
                                                float progress = (Float) animation.getAnimatedValue();
                                                if(j == index){
                                                    item.setScaleX(1f + (targetScale - 1f) * progress);
                                                    item.setScaleY(1f + (targetScale - 1f) * progress);
                                                }
                                                item.setTranslationY(targetTransY * progress);
                                            }
                                        });
                                        animator.start();
                                    }

                                    // 延迟执行
                                    new android.os.Handler().postDelayed(new Runnable() {
                                        public void run() {
                                            for (int j = 0; j < itemList.size(); j++) {
                                                final FrameLayout item = (FrameLayout) itemList.get(j);
                                                int indexDiff = Math.abs(j - index);
                                                int pushDistance = BASE_PUSH_DISTANCE + (indexDiff * 2);
                                                if(pushDistance > MAX_PUSH_DISTANCE) pushDistance = MAX_PUSH_DISTANCE;
                                                
                                                final float targetTransY = (j == index) ? 0f : (j < index ? -pushDistance : pushDistance);
                                                final float targetScale = (j == index) ? CLICK_SCALE : 1.0f;

                                                android.animation.ValueAnimator resetAnim = android.animation.ValueAnimator.ofFloat(1f, 0f);
                                                resetAnim.setDuration(150);
                                                resetAnim.setInterpolator(new android.view.animation.AccelerateInterpolator());
                                                resetAnim.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener() {
                                                    public void onAnimationUpdate(android.animation.ValueAnimator animation) {
                                                        float progress = (Float) animation.getAnimatedValue();
                                                        if(j == index){
                                                            item.setScaleX(1f + (targetScale - 1f) * progress);
                                                            item.setScaleY(1f + (targetScale - 1f) * progress);
                                                        }
                                                        item.setTranslationY(targetTransY * progress);
                                                    }
                                                });
                                                resetAnim.start();
                                            }

                                            AlertDialog dialog = (AlertDialog) v.getTag();
                                            if (dialog != null && dialog.isShowing()) dialog.dismiss();
                                            
                                            switch (index) {
                                                case 0: 跳转到页面("me.yxp.qfun.activity.PluginActivity"); break;
                                                case 1: 跳转到页面("me.yxp.qfun.activity.SettingActivity"); break;
                                                case 2: 模拟定位开关(); break;
                                                case 3: showLocationDialog(activity); break;
                                                case 4: 输入框提示开关(); break;
                                                case 5: showInputDialog(activity); break;
                                                case 6: showStatsDialog(activity); break;
                                                case 7: mkts(activity, "更新日志", 读(pluginPath + "/更新日志.txt")); break;
                                                case 8: vibrate(activity, 48); showSelectionDialog(activity, "你想选哪个呢？", "取消加载脚本", "重新加载脚本"); break;
                                                case 9: 运行状态Dialog(activity); break;
                                               
                                                case 10: showHtmlOptionDialog(activity); break;
                                            }
                                            OK = false;
                                        }
                                    }, 220);
                                } catch (Throwable clickError) {
                                    traceLog("api_log.txt", "点击事件异常: " + clickError.getMessage());
                                }
                            }
                        });

                        // 入场动画
                        itemWrapper.setAlpha(0f);
                        itemWrapper.setTranslationY(dp(activity, 12));
                        new android.os.Handler().postDelayed(new Runnable() {
                            public void run() {
                                itemWrapper.animate().alpha(1f).translationY(0f).setDuration(200).setInterpolator(new android.view.animation.DecelerateInterpolator());
                            }
                        }, i * 40);

                        itemsContainer.addView(itemWrapper);
                    }

                    rootLayout.addView(itemsContainer);
                    customDialog.show();

                    // 弹窗样式
                    android.graphics.drawable.GradientDrawable dialogBg = new android.graphics.drawable.GradientDrawable();
                    dialogBg.setColor(android.graphics.Color.parseColor(COLOR_SURFACE));
                    dialogBg.setCornerRadius(dp(activity, 16));
                    customDialog.getWindow().setBackgroundDrawable(dialogBg);

                    WindowManager.LayoutParams windowParams = customDialog.getWindow().getAttributes();
                    windowParams.width = Math.min(COMPACT_WINDOW_MAX_WIDTH,
                        activity.getResources().getDisplayMetrics().widthPixels - COMPACT_PADDING_MID * 2);
                    windowParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
                    customDialog.getWindow().setAttributes(windowParams);

                    Button cancelBtn = customDialog.getButton(DialogInterface.BUTTON_NEGATIVE);
                    if (cancelBtn != null) {
                        cancelBtn.setMinHeight(BTN_MIN_HEIGHT);
                        cancelBtn.setMinWidth(0);
                        cancelBtn.setPadding(BTN_HORIZONTAL_PADDING, COMPACT_PADDING_TINY, BTN_HORIZONTAL_PADDING, COMPACT_PADDING_TINY);
                        cancelBtn.setTextColor(android.graphics.Color.parseColor(isDarkMode ? COLOR_PRIMARY : "#FF2196F3"));
                        
                        ViewGroup.MarginLayoutParams btnLayoutParams = (ViewGroup.MarginLayoutParams) cancelBtn.getLayoutParams();
                        btnLayoutParams.bottomMargin = BTN_BOTTOM_MARGIN;
                        btnLayoutParams.topMargin = 0;
                        btnLayoutParams.leftMargin = 0;
                        btnLayoutParams.rightMargin = 0;
                        cancelBtn.setLayoutParams(btnLayoutParams);

                        customDialog.getWindow().setLayout(windowParams.width, WindowManager.LayoutParams.WRAP_CONTENT);
                    }

                    traceLog("api_log.txt", "菜单显示成功");
                } catch (Throwable uiError) {
                    traceLog("api_log.txt", "UI构建异常: " + uiError.getMessage());
                    OK = false;
                }
            }
        });
    } catch (Exception e) {
        OK = false;
        traceLog("api_log.txt", "显示菜单异常: " + e.getMessage());
    }
}







public int dp(Activity activity, int d) {
    return (int) (d * activity.getResources().getDisplayMetrics().density);
}
public int dp(int d) {
    return (int) (d * context.getResources().getDisplayMetrics().density);
}
int dp转px(Activity activity, int dp) {
    try {
        float density = activity.getResources().getDisplayMetrics().density;
        return (int) (dp * density);
    } catch (Exception e) {
        return dp * 2;
    }
}
void vibrate(Activity activity, int milliseconds) {

    if (activity == null) activity = getNowActivity();
    if (activity == null) activity = 最后Activity;
    if (activity == null) return;
    
    try {
        Vibrator vibrator;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            VibratorManager vibratorManager = (VibratorManager) activity.getSystemService(Context.VIBRATOR_MANAGER_SERVICE);
            vibrator = vibratorManager.getDefaultVibrator();
        } else {
            vibrator = (Vibrator) activity.getSystemService(Context.VIBRATOR_SERVICE);
        }
        
        if (vibrator == null || !vibrator.hasVibrator()) {
            return;
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            VibrationEffect effect = VibrationEffect.createOneShot(milliseconds, VibrationEffect.DEFAULT_AMPLITUDE);
            vibrator.vibrate(effect);
        } else {
            vibrator.vibrate(milliseconds);
        }
    } catch (Exception e) {
        traceLog("api_log.txt","震动异常: " + e);
    }
}

public String getLocationData() {
    try {
        String loc = getString("经纬度","经纬度", "");
        if (!TextUtils.isEmpty(loc) && loc.contains(",")) {
            return loc;
        } else {
            putString("经纬度","经纬度",默认经纬度);
            return 默认经纬度;
        }
    } catch (Exception e) {
        putString("经纬度","经纬度",默认经纬度);
        return 默认经纬度;
    }
}

public Double[] splitLocation(String locStr) {
    String location = TextUtils.isEmpty(locStr) ? getLocationData() : locStr;
    try {
        String[] locArray = location.split(",");
        if (locArray.length == 2) {
            double lng = Double.parseDouble(locArray[0].trim());
            double lat = Double.parseDouble(locArray[1].trim());
            if (lng >= -180 && lng <= 180 && lat >= -90 && lat <= 90) {
                return new Double[]{lng, lat};
            }
        }
    } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
        toast( "经纬度格式错误，使用默认值");
    }
    return new Double[]{默认经度, 默认纬度};
}
// 默认经纬度（天安门）
private static final String 默认经纬度 = "116.397128,39.907500";
private static final double 默认经度 = 116.397128;
private static final double 默认纬度 = 39.907500;
String locStr = getLocationData();
Double[] loc = splitLocation(locStr);
double longitude = loc[0];
double latitude = loc[1];

private void showLocationDialog(Activity activity) {
    vibrate(activity, 48);
    boolean isDark = isThemeDark(activity);
    
    LinearLayout layout = new LinearLayout(activity);
    layout.setOrientation(LinearLayout.VERTICAL);
    layout.setPadding(dp(activity, 20), dp(activity, 15), dp(activity, 20), dp(activity, 15));
    layout.setGravity(Gravity.CENTER);

    final EditText etLocation = new EditText(activity);
    etLocation.setHint("请输入格式：经度,纬度");
    etLocation.setText(getLocationData());
    etLocation.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | 
                            android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL | 
                            android.text.InputType.TYPE_NUMBER_FLAG_SIGNED);
                            
    // 输入框背景色适配
    etLocation.setBackgroundColor(isDark ? UI_COLOR_INPUT_BG_DARK : Color.parseColor("#EFEFEF"));
    etLocation.setTextColor(isDark ? UI_COLOR_TEXT_DARK : UI_COLOR_TEXT_LIGHT);
    etLocation.setPadding(dp(activity, 10), dp(activity, 10), dp(activity, 10), dp(activity, 10));
    etLocation.setHintTextColor(isDark ? UI_COLOR_SUBTEXT_DARK : Color.GRAY);
    layout.addView(etLocation, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(activity, 45)));

    layout.addView(new Space(activity), new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(activity, 10)));

    Button btnSave = new Button(activity);
    btnSave.setText("保存");
    btnSave.setBackgroundColor(Color.parseColor("#007AFF")); // 保持原有蓝色
    btnSave.setTextColor(Color.WHITE);
    layout.addView(btnSave, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(activity, 40)));

    AlertDialog.Builder builder = new AlertDialog.Builder(activity, 
        isDark ? AlertDialog.THEME_DEVICE_DEFAULT_DARK : AlertDialog.THEME_DEVICE_DEFAULT_LIGHT);
    builder.setTitle("设置经纬度")
           .setView(layout)
           .setNegativeButton("关闭", new DialogInterface.OnClickListener() {
               public void onClick(DialogInterface dialog, int which) {
                   dialog.dismiss();
               }
           });
    final AlertDialog dialog = builder.create();
    dialog.show();

    GradientDrawable bg = new GradientDrawable();
    bg.setColor(Color.parseColor(isDark ? UI_COLOR_BG_DARK : UI_COLOR_BG_LIGHT));
    bg.setCornerRadius(dp(activity, 16));
    dialog.getWindow().setBackgroundDrawable(bg);

    btnSave.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
            String input = etLocation.getText().toString().trim();
            if (input.contains(",")) {
                putString("经纬度", "经纬度", input);
                Toast("保存成功：" + input);
                dialog.dismiss();
            } else {
                Toast("格式错误！请输入 经度,纬度");
            }
        }
    });
}

//控件打开动画
private void startDialogShowAnimation(View view) {
    ScaleAnimation scaleAnim = new ScaleAnimation(
        0.7f, 1.0f,    // X轴：起始0.7倍 → 目标1倍
        0.7f, 1.0f,    // Y轴：起始0.7倍 → 目标1倍
        Animation.RELATIVE_TO_SELF, 0.5f,  // 缩放中心：视图中心X
        Animation.RELATIVE_TO_SELF, 0.5f   // 缩放中心：视图中心Y
    );
    scaleAnim.setDuration(333); // 动画时长，单位ms
    scaleAnim.setInterpolator(new AccelerateDecelerateInterpolator()); // 先加速后减速，更顺滑

    // 透明度动画：从完全透明到不透明
    AlphaAnimation alphaAnim = new AlphaAnimation(0.0f, 1.0f);
    alphaAnim.setDuration(400);
    alphaAnim.setInterpolator(new AccelerateDecelerateInterpolator());

    AnimationSet set = new AnimationSet(true);
    set.addAnimation(scaleAnim);
    set.addAnimation(alphaAnim);
    set.setFillAfter(true); // 动画结束后保持最终状态

    view.startAnimation(set);
}
/**
 * 控件关闭动画：缩放缩小 + 透明度淡出
 * @param view 弹窗的根视图（如 alertDialog.getWindow().getDecorView()）
 * @param dialog 要关闭的弹窗，动画结束后自动dismiss
 */
private void startDialogDismissAnimation(View view, DialogInterface dialog) {
    if (view == null || dialog == null) return;
    //  缩放动画：从1倍缩小到0.7倍，中心缩放
    ScaleAnimation scaleAnim = new ScaleAnimation(
        1.0f, 0.7f,               // X轴：1倍 → 0.7倍
        1.0f, 0.7f,               // Y轴：1倍 → 0.7倍
        Animation.RELATIVE_TO_SELF, 0.5f,  // 缩放中心X：视图中心
        Animation.RELATIVE_TO_SELF, 0.5f   // 缩放中心Y：视图中心
    );
    scaleAnim.setDuration(250); // 关闭动画时长
    scaleAnim.setInterpolator(new AccelerateDecelerateInterpolator());
    AlphaAnimation alphaAnim = new AlphaAnimation(1.0f, 0.0f);
    alphaAnim.setDuration(300);
    alphaAnim.setInterpolator(new AccelerateDecelerateInterpolator());
    AnimationSet set = new AnimationSet(true);
    set.addAnimation(scaleAnim);
    set.addAnimation(alphaAnim);
    set.setFillAfter(true); // 保持动画结束状态
    set.setAnimationListener(new Animation.AnimationListener() {
        public void onAnimationStart(Animation animation) {}
        public void onAnimationEnd(Animation animation) {
            dialog.dismiss(); // 动画播放完再关闭，效果更自然
        }
        public void onAnimationRepeat(Animation animation) {}
    });

    view.startAnimation(set);
}
private void showSelectionDialog(final Activity activity, final String title, final String btn1Text, final String btn2Text) {
    activity.runOnUiThread(new Runnable() {
        public void run() {
            try {
                // vibrate(activity, 48);
                boolean isDark = isThemeDark(activity);
                
                // 主布局容器（垂直排列）
                LinearLayout mainLayout = new LinearLayout(activity);
                mainLayout.setOrientation(LinearLayout.VERTICAL);
                mainLayout.setPadding(dp(activity, 24), dp(activity, 20), dp(activity, 24), dp(activity, 8));
                
                // 标题（Material风格：18sp，87%不透明度黑色）
                TextView titleView = new TextView(activity);
                titleView.setText(title);
                titleView.setTextColor(isDark ? Color.parseColor("#DEEFEFEF") : Color.parseColor("#DE000000"));
                titleView.setTextSize(18);
                titleView.setPadding(0, dp(activity, 8), 0, dp(activity, 24)); // 底部24dp间距
                
                // 选项容器（垂直排列，符合Material Actions规范）
                LinearLayout optionsContainer = new LinearLayout(activity);
                optionsContainer.setOrientation(LinearLayout.VERTICAL);
                
                // 按钮1（Material Actions风格：红色文字，透明背景，48dp高度）
                Button btn1 = new Button(activity);
                btn1.setText(btn1Text.toUpperCase()); // Material风格：大写文字
                btn1.setTextColor(Color.parseColor("#FFFF0000")); // 红色强调色
                btn1.setTextSize(14);
                btn1.setBackgroundColor(Color.parseColor("#00FFFFFF")); // 完全透明背景
                btn1.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT); // 左对齐
                LinearLayout.LayoutParams btn1Params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, dp(activity, 48)
                );
                btn1.setLayoutParams(btn1Params);
                
                // 按钮2（相同风格）
                Button btn2 = new Button(activity);
                btn2.setText(btn2Text.toUpperCase());
                btn2.setTextColor(Color.parseColor("#FFFF0000"));
                btn2.setTextSize(14);
                btn2.setBackgroundColor(Color.parseColor("#00FFFFFF"));
                btn2.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
                LinearLayout.LayoutParams btn2Params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, dp(activity, 48)
                );
                btn2.setLayoutParams(btn2Params);
                
                // 分割线（12%透明度，分隔选项和取消）
                View divider = new View(activity);
                divider.setBackgroundColor(isDark ? Color.parseColor("#1EFFFFFF") : Color.parseColor("#1E000000")); // Material分割线颜色
                LinearLayout.LayoutParams divParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, dp(activity, 1)
                );
                divParams.topMargin = dp(activity, 8);
                divParams.bottomMargin = dp(activity, 8);
                
                // 取消按钮（Material风格：黑色文字，透明背景）
                Button cancelBtn = new Button(activity);
                cancelBtn.setText("取消");
                cancelBtn.setTextColor(isDark ? Color.parseColor("#DEEFEFEF") : Color.parseColor("#DE000000")); // 87%不透明度黑色
                cancelBtn.setTextSize(14);
                cancelBtn.setBackgroundColor(Color.parseColor("#00FFFFFF"));
                cancelBtn.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
                LinearLayout.LayoutParams cancelParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, dp(activity, 48)
                );
                cancelBtn.setLayoutParams(cancelParams);
                
                mainLayout.addView(titleView);
                optionsContainer.addView(btn1);
                optionsContainer.addView(btn2);
                mainLayout.addView(optionsContainer);
                mainLayout.addView(divider, divParams);
                mainLayout.addView(cancelBtn);
                
                AlertDialog.Builder builder = new AlertDialog.Builder(activity, 
                    isDark ? AlertDialog.THEME_DEVICE_DEFAULT_DARK : AlertDialog.THEME_DEVICE_DEFAULT_LIGHT);
                builder.setView(mainLayout);
                
                final AlertDialog dialog = builder.create();
                dialog.show();
                
                GradientDrawable bg = new GradientDrawable();
                bg.setColor(Color.parseColor(isDark ? UI_COLOR_BG_DARK : UI_COLOR_BG_LIGHT)); // 纯白/深灰背景
                bg.setCornerRadius(dp(activity, 16)); // 16dp圆角
                dialog.getWindow().setBackgroundDrawable(bg);
                
                btn1.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        try {
                            vibrate(activity, 50);
                            取消加载脚本();
                            dialog.dismiss();
                        } catch (Throwable e) {
                            traceLog("api_log.txt", "按钮1异常: " + e.getMessage());
                        }
                    }
                });
                
                btn2.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        try {
                            vibrate(activity, 50);
                            重新加载脚本();
                            dialog.dismiss();
                        } catch (Throwable e) {
                            traceLog("api_log.txt", "按钮2异常: " + e.getMessage());
                        }
                    }
                });
                
                cancelBtn.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        try {
                            vibrate(activity, 50);
                            dialog.dismiss();
                        } catch (Throwable e) {
                            traceLog("api_log.txt", "取消按钮异常: " + e.getMessage());
                        }
                    }
                });
                
                traceLog("api_log.txt", "Material选择对话框已显示: " + title);
                
            } catch (Throwable e) {
                traceLog("api_log.txt", "对话框创建失败: " + e.getMessage());
            }
        }
    });
}

//非常花里胡哨的toast 提示，随机文本颜色，弹出动画消失动画
public void Toast(String text) {
    if (Looper.myLooper() == Looper.getMainLooper()) {
        xToast(text);
        return;
    }
    
    try {
        if (uiHandler != null && uiHandler.getLooper() != null) {
            uiHandler.post(new Runnable() {
                public void run() {
                    xToast(text);
                }
            });
            return;
        }
    } catch (Exception e) {
    }
    
    try {
        if (mainHandler != null && mainHandler.getLooper() != null) {
            mainHandler.post(new Runnable() {
                public void run() {
                    xToast(text);
                }
            });
            return;
        }
    } catch (Exception e) {
    }
    
    try {
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            public void run() {
                xToast(text);
            }
        });
    } catch (Exception e) {
        try {
            xToast(text);
        } catch (Exception fatal) {
            toast(text);
        }
    }
}

private void xToast(String text) {
    try {
        boolean isDark = isThemeDark(context instanceof Activity ? (Activity)context : null);
        
        LinearLayout root = new LinearLayout(context);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(12), dp(16), dp(12));
        root.setGravity(Gravity.CENTER);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor(isDark ? "#D9333333" : "#8CE0E0E0")); // 暗色模式背景更深
        bg.setCornerRadius(dp(16));
        root.setBackground(bg);

        TextView tv = new TextView(context);
        tv.setText(text);
        tv.setTextSize(17);  //toast的大小

        int[] TOAST_TEXT_COLORS;
        if (isDark) {
            // 暗色模式下的Toast文字颜色 (更明亮)
            TOAST_TEXT_COLORS = new int[]{
                Color.parseColor("#FF5252"),   // 亮红
                Color.parseColor("#4DB6AC"),   // 亮青
                Color.parseColor("#448AFF"),   // 亮蓝
                Color.parseColor("#66BB6A"),   // 亮绿
                Color.parseColor("#AB47BC"),   // 亮紫
                Color.parseColor("#FF9800"),   // 亮橙
                Color.parseColor("#FFEE58")    // 亮黄
            };
        } else {
            TOAST_TEXT_COLORS = new int[]{
                Color.parseColor("#C62828"),   // 深红
                Color.parseColor("#00695C"),   // 深青
                Color.parseColor("#1565C0"),   // 深蓝
                Color.parseColor("#2E7D32"),   // 深绿
                Color.parseColor("#6A1B9A"),   // 深紫
                Color.parseColor("#E65100"),   // 深橙
                Color.parseColor("#F57F17")    // 深黄
            };
        }
        
        Random random = new Random();
        int randomColorIndex = random.nextInt(TOAST_TEXT_COLORS.length);
        tv.setTextColor(TOAST_TEXT_COLORS[randomColorIndex]);
        root.addView(tv);

        AnimationSet showAnim = new AnimationSet(true);
        ScaleAnimation scaleShow = new ScaleAnimation(
            0.8f, 1.0f,
            0.8f, 1.0f,
            Animation.RELATIVE_TO_SELF, 0.5f,
            Animation.RELATIVE_TO_SELF, 0.5f
        );
        AlphaAnimation alphaShow = new AlphaAnimation(0.0f, 1.0f);
        scaleShow.setDuration(300);
        alphaShow.setDuration(250);
        scaleShow.setInterpolator(new AccelerateDecelerateInterpolator());
        alphaShow.setInterpolator(new AccelerateDecelerateInterpolator());
        showAnim.addAnimation(scaleShow);
        showAnim.addAnimation(alphaShow);
        showAnim.setFillAfter(true);

        AnimationSet dismissAnim = new AnimationSet(true);
        ScaleAnimation scaleDismiss = new ScaleAnimation(
            1.0f, 0.8f,
            1.0f, 0.8f,
            Animation.RELATIVE_TO_SELF, 0.5f,
            Animation.RELATIVE_TO_SELF, 0.5f
        );
        AlphaAnimation alphaDismiss = new AlphaAnimation(1.0f, 0.0f);
        scaleDismiss.setDuration(250);
        alphaDismiss.setDuration(200);
        scaleDismiss.setInterpolator(new AccelerateDecelerateInterpolator());
        alphaDismiss.setInterpolator(new AccelerateDecelerateInterpolator());
        dismissAnim.addAnimation(scaleDismiss);
        dismissAnim.addAnimation(alphaDismiss);
        dismissAnim.setFillAfter(true);

        root.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
            public void onViewAttachedToWindow(View v) {
                // Toast显示时，启动弹出动画
                v.startAnimation(showAnim);
            }

            public void onViewDetachedFromWindow(View v) {
                // Toast消失时，启动消失动画
                v.startAnimation(dismissAnim);
            }
        });

        Toast toast = new Toast(context);
        toast.setView(root);
        toast.setDuration(Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.BOTTOM, 0, dp(64));
        toast.show();
    } catch (e) {
        toast(""+text);
        traceLog("api_log.txt",""+e);
    }
}






boolean 应用状态() {
    long 检测开始时间 = System.currentTimeMillis();
    try {
        Activity activity = getNowActivity();
        if (activity == null) activity = 最后Activity;
        if (activity == null) {
            // traceLog("api_log.txt","应用状态检测 - 无Activity，耗时: " + (System.currentTimeMillis() - 检测开始时间) + "ms");
            return false;
        }
        
        ActivityManager activityManager = (ActivityManager) activity.getSystemService(Context.ACTIVITY_SERVICE);
        if (activityManager == null) {
            // traceLog("api_log.txt","应用状态检测 - ActivityManager为空，耗时: " + (System.currentTimeMillis() - 检测开始时间) + "ms");
            return false;
        }
        
        List<ActivityManager.RunningAppProcessInfo> appProcesses = activityManager.getRunningAppProcesses();
        
        if (appProcesses == null) {
            // traceLog("api_log.txt","应用状态检测 - 进程列表为空，耗时: " + (System.currentTimeMillis() - 检测开始时间) + "ms");
            return false;
        }
        
        for (ActivityManager.RunningAppProcessInfo appProcess : appProcesses) {
            if (appProcess.processName.equals(currentPackageName)) {
                boolean isForeground = appProcess.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND;
                // traceLog("api_log.txt","应用状态检测 - 找到进程，状态: " + isForeground + "，耗时: " + (System.currentTimeMillis() - 检测开始时间) + "ms");
                return isForeground;
            }
        }
        
        // traceLog("api_log.txt","应用状态检测 - 未找到进程，耗时: " + (System.currentTimeMillis() - 检测开始时间) + "ms");
        return false;
    } catch (Exception e) {
        traceLog("api_log.txt","应用状态检测异常: " + e + "，耗时: " + (System.currentTimeMillis() - 检测开始时间) + "ms");
        return false;
    }
}

//非常花里胡哨的tips弹窗
public void ts(Activity activity, String title, String content) {
    if (activity == null || activity.isFinishing()) {
        traceLog("api_log.txt","Activity无效，无法显示弹窗");
        return;
    }
    boolean isDark = isThemeDark(activity);
    
    final String finalContent = content == null ? "" : content;
    // 多颜色高亮数组（含#的行循环使用）
    final int[] HIGHLIGHT_COLORS = {
        Color.parseColor("#FF6B6B"),   // 红色
        // Color.parseColor("#4ECDC4"),   // 青色 太淡了不要了
        Color.parseColor("#45B7D1"),   // 蓝色
        // Color.parseColor("#96CEB4"),   // 绿色 不好看也不要了
        Color.parseColor("#DDA0DD")    // 紫色
    };
    // 普通行颜色
    final int NORMAL_LINE_COLOR = isDark ? Color.parseColor("#AAAAAA") : Color.parseColor("#666666");

    activity.runOnUiThread(new Runnable() {
        public void run() {
            try {
                vibrate(activity, 48);
            } catch (Exception e) {
                traceLog("api_log.txt","震动执行异常: " + e.getMessage());
            }
            /* 根布局：圆角 + 55% 透明 */
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(Color.parseColor(isDark ? UI_COLOR_BG_DARK : "#BFFFFFFF"));
            bg.setCornerRadius(dp(activity, 16));

            LinearLayout layout = new LinearLayout(activity);
            layout.setPadding(dp(activity, 20), dp(activity, 20), dp(activity, 20), dp(activity, 20));
            layout.setOrientation(LinearLayout.VERTICAL);

            TextView textView = new TextView(activity);
            textView.setTextSize(17);
            textView.setTextIsSelectable(true);
            textView.setSingleLine(false);
            textView.setMaxLines(Integer.MAX_VALUE);
            textView.setEllipsize(null);
            // 默认文字颜色
            textView.setTextColor(isDark ? UI_COLOR_TEXT_DARK : UI_COLOR_TEXT_LIGHT);

            try {
                if (!finalContent.isEmpty()) {
                    SpannableStringBuilder ssb = new SpannableStringBuilder();
                    String[] lines = finalContent.split("\n");
                    int highlightIndex = 0; // 仅计数含#的行

                    for (int i = 0; i < lines.length; i++) {
                        String line = lines[i];
                        SpannableString spannable = new SpannableString(line);
                        int targetColor = line.contains("#") 
                            ? HIGHLIGHT_COLORS[highlightIndex++ % HIGHLIGHT_COLORS.length] 
                            : NORMAL_LINE_COLOR;

                        spannable.setSpan(
                            new ForegroundColorSpan(targetColor),
                            0,
                            line.length(),
                            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
                        );

                        ssb.append(spannable);
                        if (i != lines.length - 1) {
                            ssb.append("\n");
                        }
                    }
                    textView.setText(ssb);
                } else {
                    textView.setTextColor(NORMAL_LINE_COLOR);
                    textView.setText(finalContent);
                }
            } catch (Throwable e) {
                traceLog("api_log.txt","文本高亮处理异常: " + e.getMessage());
                textView.setTextColor(NORMAL_LINE_COLOR);
                textView.setText(finalContent);
            }

            layout.addView(textView);
            ScrollView scrollView = new ScrollView(activity);
            scrollView.addView(layout);

            AlertDialog.Builder builder = new AlertDialog.Builder(activity,
                    isDark ? AlertDialog.THEME_DEVICE_DEFAULT_DARK : AlertDialog.THEME_DEVICE_DEFAULT_LIGHT);
            builder.setTitle(title);
            builder.setView(scrollView);
            builder.setPositiveButton("我知道了", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    try {
                        Toast("你知道啥了");
                        vibrate(activity, 48);
                    } catch (Exception e) {
                        traceLog("api_log.txt","按钮点击异常: " + e.getMessage());
                    }
                }
            });
            builder.setCancelable(false);

            AlertDialog alertDialog = builder.create();
            alertDialog.show();
            alertDialog.getWindow().setBackgroundDrawable(bg);

            TextView titleView = (TextView) alertDialog.findViewById(android.R.id.title);
            if (titleView != null) {
                titleView.setTextSize(22);
            }

            Window window = alertDialog.getWindow();
            if (window != null) {
                WindowManager.LayoutParams params = window.getAttributes();
                params.width = Math.min(dp(activity, 360), activity.getResources().getDisplayMetrics().widthPixels - dp(activity, 40));
                window.setAttributes(params);
            }
        }
    });
}

loadJar(rootPath + "commonmark-0.21.0.jar");

import org.commonmark.node.Node;
import org.commonmark.parser.Parser;
import org.commonmark.renderer.html.HtmlRenderer;


public void mkts(Activity activity, String title, String markdownContent) {
    if (activity == null || activity.isFinishing()) {
        traceLog("api_log.txt", "Activity无效");
        return;
    }
    
    final String finalMarkdown = markdownContent == null ? "" : markdownContent;
    final boolean isDark = isThemeDark(activity);
    
    ThreadPool.execute(new Runnable() {
        public void run() {
            try {
                traceLog("api_log.txt", "开始解析，长度: " + finalMarkdown.length());
                
                Parser parser = Parser.builder().build();
                Node document = parser.parse(finalMarkdown);
                HtmlRenderer renderer = HtmlRenderer.builder().build();
                String htmlContent = renderer.render(document);
                
                traceLog("api_log.txt", "解析成功，输出长度: " + htmlContent.length());
                
                final String finalHtml = htmlContent;
                
                traceLog("api_log.txt", "HTML片段: " + finalHtml.substring(0, Math.min(500, finalHtml.length())));
                
                activity.runOnUiThread(new Runnable() {
                    public void run() {
                        createMarkdownDialog(activity, title, finalHtml, true, isDark);
                    }
                });
                
            } catch (Throwable e) {
                traceLog("api_log.txt", "解析失败: " + e.getClass().getSimpleName() + " - " + e.getMessage());
                
                final String fallbackHtml = generateFallbackHtml(finalMarkdown, isDark);
                
                activity.runOnUiThread(new Runnable() {
                    public void run() {
                        createMarkdownDialog(activity, title, fallbackHtml, false, isDark);
                    }
                });
            }
        }
    });
}

private void createMarkdownDialog(final Activity activity, String title, String html, boolean parseSuccess, boolean isDark) {
    try {
        vibrate(activity, 48);
    } catch (Exception e) {
        traceLog("api_log.txt", "震动执行异常: " + e.getMessage());
    }

    GradientDrawable bg = new GradientDrawable();
    bg.setColor(Color.parseColor(isDark ? UI_COLOR_BG_DARK : "#BFFFFFFF"));
    bg.setCornerRadius(dp(activity, 16));

    final String wrappedHtml = wrapHtmlWithCss(html, isDark);
    
    WebView webView = new WebView(activity);
    
    LinearLayout.LayoutParams webParams = new LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        dp(activity, 800)
    );
    webView.setLayoutParams(webParams);

    // 启用WebView原生滚动
    webView.setVerticalScrollBarEnabled(true);
    webView.setHorizontalScrollBarEnabled(true);
    webView.setScrollContainer(true);
    
    // webView.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    
    // 透明背景
    webView.setBackgroundColor(Color.TRANSPARENT);

    webView.getSettings().setJavaScriptEnabled(false);
    webView.getSettings().setDefaultTextEncodingName("UTF-8");
    
    webView.setWebViewClient(new WebViewClient() {
        public void onPageFinished(WebView view, String url) {
            traceLog("api_log.txt", "页面加载完成，内容高度: " + view.getContentHeight());
            
            view.post(new Runnable() {
                public void run() {
                    view.requestLayout();
                    view.invalidate();
                }
            });
        }
        
        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
            traceLog("api_log.txt", "加载失败: " + errorCode + " - " + description);
        }
    });
    
    webView.loadDataWithBaseURL(null, wrappedHtml, "text/html", "UTF-8", null);

    AlertDialog.Builder builder = new AlertDialog.Builder(activity, 
        isDark ? AlertDialog.THEME_DEVICE_DEFAULT_DARK : AlertDialog.THEME_DEVICE_DEFAULT_LIGHT);
    builder.setTitle(parseSuccess ? title : title + " (显示异常)");
    builder.setView(webView);
    
    builder.setPositiveButton("我知道了", new DialogInterface.OnClickListener() {
        public void onClick(DialogInterface dialog, int which) {
            try {
                Toast("你知道啥了");
                vibrate(activity, 48);
            } catch (Exception e) {
                traceLog("api_log.txt", "按钮点击异常: " + e.getMessage());
            }
        }
    });
    builder.setCancelable(false);

    AlertDialog alertDialog = builder.create();
    alertDialog.show();
    alertDialog.getWindow().setBackgroundDrawable(bg);

    TextView titleView = (TextView) alertDialog.findViewById(android.R.id.title);
    if (titleView != null) {
        titleView.setTextSize(22);
    }

    Window window = alertDialog.getWindow();
    if (window != null) {
        WindowManager.LayoutParams params = window.getAttributes();
        params.width = Math.min(dp(activity, 320), activity.getResources().getDisplayMetrics().widthPixels - dp(activity, 60));
        window.setAttributes(params);
    }
    
    traceLog("api_log.txt", "Dialog显示成功，解析状态: " + parseSuccess);
}

//CSS
private String wrapHtmlWithCss(String htmlContent, boolean isDark) {
    String textColor = isDark ? "#EFEFEF" : "#333";
    String bgColor = isDark ? "#2D2D2D" : "#f4f4f4";
    
    return "<html><head>" +
           "<meta charset='UTF-8'><style>" +
           // 强制所有元素继承
           "*{color:" + textColor + " !important;}" +
           // body
           "body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;padding:8px;line-height:1.4;background:transparent;font-size:14px;}" +
           // 块级元素样式
           "pre{background:" + bgColor + " !important;padding:6px !important;border-radius:3px !important;overflow-x:auto !important;font-size:13px !important;}" +
           "code{background:" + bgColor + " !important;padding:1px 3px !important;border-radius:2px !important;font-family:monospace !important;font-size:13px !important;}" +
           "h1,h2,h3{margin:8px 0 4px 0 !important;font-weight:600 !important;}" +
           "h1{font-size:18px !important;}h2{font-size:16px !important;}h3{font-size:15px !important;}" +
           "p{margin:4px 0 !important;}" +
           "ul,ol{padding-left:16px !important;margin:4px 0 !important;}" +
           "li{margin:2px 0 !important;}" +
           "</style></head><body>" + htmlContent + "</body></html>";
}

private String generateFallbackHtml(String markdown, boolean isDark) {
    String escaped = escapeHtml(markdown);
    String bgColor = isDark ? "#2D2D2D" : "#f4f4f4";
    String textColor = isDark ? "#EFEFEF" : "#333";
    return "<pre style='background:" + bgColor + ";padding:6px;border-radius:3px;overflow-x:auto;font-family:monospace;font-size:13px;color:" + textColor + ";'>" + escaped + "</pre>";
}

private String escapeHtml(String text) {
    if (text == null) return "";
    return text.replace("&", "&amp;")
               .replace("<", "&lt;")
               .replace(">", "&gt;")
               .replace("\"", "&quot;")
               .replace("'", "&#39;");
}


// // 辅助方法：圆角drawable方法
// private GradientDrawable createRoundRectDrawable(Activity activity, int color, int radius) {
    // GradientDrawable drawable = new GradientDrawable();
    // drawable.setColor(color);
    // drawable.setCornerRadius(dp(activity, radius));
    // return drawable;
// }




import me.yxp.qfun.plugin.loader.PluginManager;
import me.yxp.qfun.plugin.bean.PluginInfo;

volatile boolean isUnloading = false;
volatile Thread 卸载线程引用 = null;
volatile CountDownLatch 卸载完成信号 = null;

void 清理Handler(Handler handler) {
    if (handler == null) return;
    try {
        handler.removeCallbacksAndMessages(null);
    } catch (Throwable e) {}
}

void 关闭线程池() {
    if (ThreadPool == null) return;
    try {
        ThreadPool.shutdownNow();
    } catch (Throwable e) {}
    ThreadPool = null;
}

void performDataCleanup() {
    if (writeLock == null) return;
    synchronized (writeLock) {
        try {
            if (OP_STATS != null) OP_STATS.clear();
            if (messageBatchQueue != null) messageBatchQueue.clear();
            if (CHANGED_KEYS != null) CHANGED_KEYS.clear();
            if (cardExpandStatus != null) cardExpandStatus.clear();
            if (statsTextViewCache != null) statsTextViewCache.clear();
            if (weekDatesCache != null) weekDatesCache.clear();
            if (monthDatesCache != null) monthDatesCache.clear();
        } catch (Throwable e) {}
    }
    todayDateStr = null;
}

void performUiCleanup() {
    final android.app.Dialog dialog = statsDialog;
    final Handler handle = msgHandle;
    try {
        if (dialog != null) {
            try { if (dialog.isShowing()) dialog.dismiss(); } catch (Throwable e) {}
            statsDialog = null;
        }
        if (handle != null) {
            handle.removeCallbacksAndMessages(null);
            msgHandle = null;
        }
        dialogVisible = false;
    } catch (Throwable e) {}
}

void onUnMsgload() {
    traceLog("api_log.txt", "====== api3卸载开始 ======");
    
    synchronized (this) {
        if (isUnloading) return;
        isUnloading = true;
        卸载线程引用 = Thread.currentThread();
        卸载完成信号 = new CountDownLatch(1);
    }
    
    try {
        stopWriteThread();
        performDataCleanup();
        
        Activity activity = getNowActivity();
        if (activity != null && !activity.isFinishing() && !activity.isDestroyed()) {
            final CountDownLatch 信号 = new CountDownLatch(1);
            activity.runOnUiThread(new Runnable() {
                public void run() {
                    performUiCleanup();
                    信号.countDown();
                }
            });
            try { 信号.await(3, TimeUnit.SECONDS); } catch (Throwable e) {}
        }
        
    } catch (Throwable e) {
        traceLog("api_log.txt", "卸载异常: " + e.toString());
    }
    traceLog("api_log.txt", "====== api3卸载完成 ======");
}

void a卸载悬浮窗() {
    Activity activity = getNowActivity();
    if (activity == null) activity = 最后Activity;
    
    if (activity != null && !activity.isFinishing() && !activity.isDestroyed()) {
        final CountDownLatch 信号 = new CountDownLatch(1);
        activity.runOnUiThread(new Runnable() {
            public void run() {
                try {
                     卸载悬浮窗();
                 } catch (Throwable e) {}
                信号.countDown();
            }
        });
        try { 信号.await(2, TimeUnit.SECONDS); } catch (InterruptedException e) {}
    } else {
        try { 卸载悬浮窗(); } catch (Throwable e) {}
    }
}

void 卸载脚本() {
    traceLog("api_log.txt", "卸载脚本入口 - 线程: " + Thread.currentThread().getName());
    
    initThreadPool();
    
    // ThreadPool.execute(new Runnable() {
        // public void run() {
            boolean isUIThread = "main".equals(Thread.currentThread().getName());
            
            if (!isUIThread && getNowActivity() != null) {
                final CountDownLatch 信号 = new CountDownLatch(1);
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    public void run() {
                        try { 执行卸载核心逻辑(); } catch (Throwable e) {}
                        信号.countDown();
                    }
                });
                try { 信号.await(5, TimeUnit.SECONDS); } catch (InterruptedException e) {}
            } else {
                执行卸载核心逻辑();
            }
        // }
    // });
    异步关闭线程池();
}

void 执行卸载核心逻辑() {
    traceLog("api_log.txt", "====== 完整卸载开始 ======");
    
    try {
        停止监控();
        if (isRunning != null) isRunning.set(false);
        
        boolean 模拟定位开关 = getBoolean("模拟定位开关", "模拟定位开关", false);
        if (模拟定位开关) {
            关模拟定位();
            Toast("正在关闭模拟定位...");
        }
        
        onUnMsgload();
        putBoolean("settings", "开关", false);
        a卸载悬浮窗();
        
        清理Handler(uiHandler);
        清理Handler(mainHandler);
        清理Handler(监控Handler);
        uiHandler = null;
        mainHandler = null;
        监控Handler = null;
        
        
        延迟启动完成 = false;
        OK = false;
        悬浮窗显示状态 = false;
        应用前台状态 = false;
        监控线程运行 = false;
        
        Toast("脚本卸载完成，欢迎下次使用");
        
    } catch (Throwable e) {
        traceLog("api_log.txt", "卸载失败: " + e.toString());
        Toast("卸载失败：" + e.getMessage());
    }
}

void 异步关闭线程池() {
    new Thread(new Runnable() {
        public void run() {
            try {
                Thread.sleep(500);
                关闭线程池();
            } catch (Throwable e) {}
        }
    }).start();
}

void 重新加载脚本() {
    OK = false;
    
    if (uiHandler != null) {
        uiHandler.postDelayed(new Runnable() {
            public void run() {
                Activity activity = getNowActivity();
                if (activity == null || activity.isFinishing()) activity = 最后Activity;
                if (activity != null && !activity.isFinishing()) 重新加载操作(activity);
            }
        }, 300);
    } else {
        Activity activity = getNowActivity();
        if (activity == null || activity.isFinishing()) activity = 最后Activity;
        if (activity != null && !activity.isFinishing()) 重新加载操作(activity);
    }
}

void 取消加载脚本() {
    OK = false;
    
    if (uiHandler != null) {
        uiHandler.postDelayed(new Runnable() {
            public void run() {
                Activity activity = getNowActivity();
                if (activity == null || activity.isFinishing()) activity = 最后Activity;
                if (activity != null && !activity.isFinishing()) 取消加载操作(activity);
            }
        }, 300);
    } else {
        Activity activity = getNowActivity();
        if (activity == null || activity.isFinishing()) activity = 最后Activity;
        if (activity != null && !activity.isFinishing()) 取消加载操作(activity);
    }
}

void 重新加载操作(Activity activity) {
    try {
        PluginManager pm = PluginManager.INSTANCE;
        if (pm == null) return;
        
        List list = pm.getPlugins();
        if (list == null) return;
        
        PluginInfo target = null;
        int n = list.size();
        
        for (int i = 0; i < n; i++) {
            try {
                Object obj = list.get(i);
                if (obj == null || !"me.yxp.qfun.plugin.bean.PluginInfo".equals(obj.getClass().getName())) continue;
                
                PluginInfo p = (PluginInfo) obj;
                if ("QFloatingX".equals(p.getId()) && p.isRunning()) {
                    target = p;
                    break;
                }
            } catch (Throwable e) {
                continue;
            }
        }
        
        if (target != null) pm.reloadPlugin(target);
    } catch (Throwable e) {
        OK = false;
    }
}

void 取消加载操作(Activity activity) {
    try {
        PluginManager pm = PluginManager.INSTANCE;
        if (pm == null) return;
        
        List list = pm.getPlugins();
        if (list == null) return;
        
        PluginInfo target = null;
        int n = list.size();
        
        for (int i = 0; i < n; i++) {
            try {
                Object obj = list.get(i);
                if (obj == null || !"me.yxp.qfun.plugin.bean.PluginInfo".equals(obj.getClass().getName())) continue;
                
                PluginInfo p = (PluginInfo) obj;
                if ("QFloatingX".equals(p.getId()) && p.isRunning()) {
                    target = p;
                    break;
                }
            } catch (Throwable e) {
                continue;
            }
        }
        
        if (target != null) pm.stopPlugin(target);
    } catch (Throwable e) {
        OK = false;
    }
}

void unLoadPlugin() {
    try {
        if (ThreadPool == null || ThreadPool.isShutdown()) initThreadPool();
        if (isUnloading) isUnloading = false;
        if (卸载完成信号 != null) {
            卸载完成信号.countDown();
            卸载完成信号 = null;
        }
    } catch (Throwable e) {}
    
    卸载脚本();
    
}














Boolean copyFilefolder(String 原路径, String 目标路径) {
    traceLog("api_log.txt", "开始复制: " + 原路径 + " -> " + 目标路径);
    try {
        File 源文件 = new File(原路径);
        File 目标文件 = new File(目标路径);
        
        if (!源文件.exists() || !源文件.isDirectory()) {
            traceLog("api_log.txt", "源路径无效: " + 原路径);
            return false;
        }
        
        目标文件.getParentFile().mkdirs();
        return 递归复制文件夹(源文件, 目标文件);
    } catch (Throwable e) {
        traceLog("api_log.txt", "致命错误: " + e.getMessage());
        return false;
    }
}

Boolean 递归复制文件夹(File 源, File 目标) {
    FileInputStream 输入流 = null;
    FileOutputStream 输出流 = null;
    
    try {
        if (源.isDirectory()) {
            if (!目标.exists() && !目标.mkdirs()) {
                traceLog("api_log.txt", "创建目录失败: " + 目标);
                return false;
            }
            
            File[] 子文件 = 源.listFiles();
            if (子文件 != null) {
                for (int i = 0; i < 子文件.length; i++) {
                    if (!递归复制文件夹(子文件[i], new File(目标, 子文件[i].getName()))) {
                        return false;
                    }
                }
            }
        } else {
            try {
                输入流 = new FileInputStream(源);
                输出流 = new FileOutputStream(目标);
                
                // 增大缓冲区到4KB，提升复制效率
                byte[] 缓冲区 = new byte[4096];
                int 长度;
                while ((长度 = 输入流.read(缓冲区)) > 0) {
                    输出流.write(缓冲区, 0, 长度);
                }
                
                输出流.flush();
                
                traceLog("api_log.txt", "成功: " + 源.getName() + " (" + 源.length() + " bytes)");
            } catch (Throwable ioError) {
                traceLog("api_log.txt", "IO异常: " + ioError.getMessage());
                return false;
            } finally {
                if (输入流 != null) {
                    try {
                        输入流.close();
                    } catch (Throwable e) {
                        traceLog("api_log.txt", e.getMessage());
                    }
                }
                if (输出流 != null) {
                    try {
                        输出流.close();
                    } catch (Throwable e) {
                        traceLog("api_log.txt", e.getMessage());
                    }
                }
            }
        }
        return true;
    } catch (Throwable e) {
        traceLog("api_log.txt", e.getMessage());
        return false;
    }
}




Boolean 文件夹迁移弹窗() {
    String 不再提示状态 = getString("迁移", "不再提示", "false");
    if (不再提示状态.equals("true")) {
        return false;
    }
    
    Activity activity = getNowActivity();
    if (activity == null) {
        traceLog("api_log.txt", "Activity获取失败");
        return false;
    }
    boolean isDark = isThemeDark(activity);
    
    String 源基础路径 = "/storage/emulated/0/Android/media/com.tencent.mobileqq/QFun/" + qq + "/plugin/";
    String 源数据路径 = "/storage/emulated/0/Android/media/com.tencent.mobileqq/QFun/" + qq + "/plugin/QFloatingX/config/";
    if (!源基础路径.endsWith("/")) 源基础路径 += "/";
    if (!源数据路径.endsWith("/")) 源数据路径 += "/";
    
    String 目标基础路径 = pluginPath.replace("QFloatingX", "");
    if (!目标基础路径.endsWith("/")) 目标基础路径 += "/";
    
    traceLog("api_log.txt", "源基础路径: " + 源基础路径);
    traceLog("api_log.txt", "目标基础路径: " + 目标基础路径);
    
    final HashMap 选择状态映射 = new HashMap();
    
    activity.runOnUiThread(new Runnable() {
        public void run() {
            try {
                LinearLayout 根布局 = new LinearLayout(activity);
                根布局.setOrientation(LinearLayout.VERTICAL);
                根布局.setPadding(dp(activity, 20), dp(activity, 15), dp(activity, 20), dp(activity, 15));
                
                ScrollView 滚动容器 = new ScrollView(activity);
                LinearLayout.LayoutParams 滚动参数 = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 
                    0, 
                    1.0f  // 权重1，占满除按钮外的所有空间
                );
                滚动容器.setLayoutParams(滚动参数);
                
                LinearLayout 列表容器 = new LinearLayout(activity);
                列表容器.setOrientation(LinearLayout.VERTICAL);
                列表容器.setId(10001);
                
                滚动容器.addView(列表容器); // 列表放入ScrollView
                
                Button 确认按钮 = new Button(activity);
                确认按钮.setText("确认迁移");
                确认按钮.setTextColor(Color.parseColor("#FFFFFFFF"));
                确认按钮.setTextSize(16);
                确认按钮.setBackgroundColor(isDark ? UI_COLOR_ACCENT_DARK : UI_COLOR_ACCENT_LIGHT);
                LinearLayout.LayoutParams 按钮参数 = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 
                    dp(activity, 45)
                );
                按钮参数.setMargins(0, dp(activity, 15), 0, 0); // 与ScrollView间距15dp
                确认按钮.setLayoutParams(按钮参数);
                
                // 布局组装：先ScrollView（带列表），后按钮
                根布局.addView(滚动容器);
                根布局.addView(确认按钮);
                
                添加列表项(activity, 列表容器, 源数据路径, "本脚本数据", false, 选择状态映射);
                
                ThreadPool.execute(new Runnable() {
                    public void run() {
                        try {
                            File 基础目录 = new File(源基础路径);
                            File[] 所有文件 = 基础目录.listFiles();
                            if (所有文件 != null) {
                                for (int i = 0; i < 所有文件.length; i++) {
                                    final File 文件 = 所有文件[i];
                                    if (文件.isDirectory() && !文件.getAbsolutePath().equals(源数据路径)) {
                                        activity.runOnUiThread(new Runnable() {
                                            public void run() {
                                                添加列表项(activity, 列表容器, 文件.getAbsolutePath(), 文件.getName(), false, 选择状态映射);
                                            }
                                        });
                                    }
                                }
                            }
                        } catch (Throwable e) {
                            traceLog("api_log.txt", e.getMessage());
                        }
                    }
                });
                
                确认按钮.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        执行迁移操作(activity, 选择状态映射, 目标基础路径);
                    }
                });
                
                AlertDialog 弹窗 = new AlertDialog.Builder(activity, 
                    isDark ? AlertDialog.THEME_DEVICE_DEFAULT_DARK : AlertDialog.THEME_DEVICE_DEFAULT_LIGHT)
                    .setTitle("选择要迁移的文件夹")
                    .setView(根布局)
                    .setPositiveButton("不再提示", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            putString("迁移", "不再提示", "true");
                            Toast("已设置不再提示");
                            dialog.dismiss();
                        }
                    })
                    .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    })
                    .setCancelable(false)
                    .create();
                
                // 背景适配
                GradientDrawable bg = new GradientDrawable();
                bg.setColor(Color.parseColor(isDark ? UI_COLOR_BG_DARK : UI_COLOR_BG_LIGHT));
                bg.setCornerRadius(dp(activity, 16));
                弹窗.getWindow().setBackgroundDrawable(bg);
                
                弹窗.show();
                
                弹窗.getButton(DialogInterface.BUTTON_POSITIVE).setTextColor(isDark ? UI_COLOR_TEXT_DARK : UI_COLOR_TEXT_LIGHT);
                弹窗.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(isDark ? UI_COLOR_SUBTEXT_DARK : UI_COLOR_SUBTEXT_LIGHT);
                
            } catch (Throwable e) {
                traceLog("api_log.txt", "UI构建失败: " + e.getMessage());
            }
        }
    });
    
    return true;
}

void 添加列表项(Activity activity, LinearLayout 容器, String 路径, String 名称, boolean 初始状态, HashMap 状态映射) {
    activity.runOnUiThread(new Runnable() {
        public void run() {
            try {
                boolean isDark = isThemeDark(activity);
                
                LinearLayout 行 = new LinearLayout(activity);
                行.setOrientation(LinearLayout.HORIZONTAL);
                行.setPadding(0, dp(activity, 10), 0, dp(activity, 10));
                行.setGravity(Gravity.CENTER_VERTICAL);
                
                TextView 文本 = new TextView(activity);
                文本.setText(名称);
                文本.setTextSize(16);
                文本.setTextColor(isDark ? UI_COLOR_TEXT_DARK : UI_COLOR_TEXT_LIGHT);
                LinearLayout.LayoutParams 文本参数 = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f);
                文本.setLayoutParams(文本参数);
                
                final TextView 勾选视觉 = new TextView(activity);
                勾选视觉.setText("✓");
                勾选视觉.setTextSize(18);
                勾选视觉.setGravity(Gravity.CENTER);
                LinearLayout.LayoutParams 勾选参数 = new LinearLayout.LayoutParams(dp(activity, 30), dp(activity, 30));
                勾选参数.setMargins(0, 0, dp(activity, 10), 0);
                勾选视觉.setLayoutParams(勾选参数);
                
                状态映射.put(路径, 初始状态);
                勾选视觉.setTextColor(初始状态 ? Color.parseColor("#FF4CAF50") : Color.parseColor("#00FFFFFF"));
                
                行.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        boolean 当前状态 = (Boolean) 状态映射.get(路径);
                        boolean 新状态 = !当前状态;
                        状态映射.put(路径, 新状态);
                        勾选视觉.setTextColor(新状态 ? Color.parseColor("#FF4CAF50") : Color.parseColor("#00FFFFFF"));
                        traceLog("api_log.txt", 名称 + ": " + 新状态);
                    }
                });
                
                行.setOnTouchListener(new View.OnTouchListener() {
                    public boolean onTouch(View v, MotionEvent event) {
                        if (event.getAction() == MotionEvent.ACTION_DOWN) {
                            行.setAlpha(0.7f);
                        } else if (event.getAction() == MotionEvent.ACTION_UP || event.getAction() == MotionEvent.ACTION_CANCEL) {
                            行.setAlpha(1.0f);
                        }
                        return false;
                    }
                });
                
                行.addView(文本);
                行.addView(勾选视觉);
                容器.addView(行);
                
            } catch (Throwable e) {
                traceLog("api_log.txt", e.getMessage());
            }
        }
    });
}

void 执行迁移操作(Activity activity, HashMap 状态映射, String 目标基础路径) {
    int 选中数量 = 0;
    ArrayList 选中路径列表 = new ArrayList();
    
    Iterator 迭代器 = 状态映射.keySet().iterator();
    while (迭代器.hasNext()) {
        String 路径 = (String) 迭代器.next();
        boolean 是否选中 = (Boolean) 状态映射.get(路径);
        if (是否选中) {
            选中数量++;
            选中路径列表.add(路径);
        }
    }
    
    if (选中数量 == 0) {
        Toast("请至少选择一个文件夹");
        return;
    }
    
ThreadPool.execute(new Runnable() {
    public void run() {
        try {
            String configPathDir = configPath;
            if (configPathDir != null && !configPathDir.isEmpty() && !configPathDir.endsWith("/")) {
                configPathDir += "/";
            }
            
            traceLog("api_log.txt", "configPath标准化: " + configPathDir);
            traceLog("api_log.txt", "目标基础路径: " + 目标基础路径);
            
                    Toast("开始迁移" + 选中数量 + "个文件夹...");
            
            for (int i = 0; i < 选中路径列表.size(); i++) {
                String 源路径 = (String) 选中路径列表.get(i);
                String 文件夹名 = new File(源路径).getName();
                
                String 目标路径;
                if (源路径.contains("QFloatingX/config/")) {
                    if (configPathDir == null || configPathDir.isEmpty()) {
                        traceLog("api_log.txt", "configPath为空，跳过: " + 源路径);
                        continue; // 跳过无效项，继续迁移其他
                    }
                    目标路径 = configPathDir;
                    traceLog("api_log.txt", "config规则 | 源: " + 源路径 + " -> 目标: " + 目标路径);
                } else {
                    目标路径 = 目标基础路径 + 文件夹名;
                    traceLog("api_log.txt", "标准规则 | 源: " + 源路径 + " -> 目标: " + 目标路径);
                }
                
                Boolean 结果 = copyFilefolder(源路径, 目标路径);
                traceLog("api_log.txt", (i+1) + "/" + 选中数量 + " | " + 文件夹名 + " -> " + (结果 ? "成功" : "失败"));
            }
                Toast("迁移完成，共迁移" + 选中数量 + "个文件夹");
        } catch (Throwable e) {
            traceLog("api_log.txt", "迁移线程致命错误: " + e.getMessage());
                Toast("迁移出错: " + e.getMessage());
        }
    }
});
}

try{
String 版本 =context.getPackageManager().getPackageInfo("me.yxp.qfun", 0).versionName;
if (版本.indexOf("1.2.5") != -1) {
    文件夹迁移弹窗();
}
} catch (e) { }